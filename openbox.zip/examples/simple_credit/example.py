"""
Exemplo Simples: Sistema de Governança para Crédito

Este exemplo demonstra como usar o OpenBox Omega-Min para governar
um sistema simples de aprovação de crédito sem dependência de
explicabilidade.

O sistema:
1. Carrega dados de crédito
2. Treina um modelo simples
3. Avalia usando CVaR e Ω-GATE
4. Registra evidências no ledger
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import matplotlib.pyplot as plt

# Importar OpenBox Omega-Min
from openbox.omega_min import OmegaMinConfig, AppendOnlyLedger, cvar, omega_gate
from openbox.omega_min.risk import CVaRMonitor
from openbox.omega_min.gate import OmegaGate


def load_credit_data():
    """
    Carrega dados sintéticos de crédito para demonstração.
    
    Returns:
        DataFrame com dados de crédito
    """
    np.random.seed(42)
    n_samples = 1000
    
    # Features simuladas
    data = {
        'income': np.random.normal(50000, 20000, n_samples),
        'age': np.random.normal(35, 10, n_samples),
        'credit_score': np.random.normal(650, 100, n_samples),
        'debt_to_income': np.random.uniform(0, 1, n_samples),
        'employment_years': np.random.exponential(5, n_samples),
        'previous_defaults': np.random.binomial(1, 0.2, n_samples)
    }
    
    # Criar target (aprovação) baseado em regras realistas
    # Combinar features para criar aprovação realista
    approval_probability = (
        0.3 * (data['income'] / 100000) +  # Renda maior = melhor
        0.2 * ((data['age'] - 18) / 50) +  # Idade madura = melhor
        0.2 * (data['credit_score'] / 850) +  # Score maior = melhor
        -0.3 * data['debt_to_income'] +  # Dívida alta = pior
        0.1 * np.minimum(data['employment_years'] / 10, 1) +  # Emprego estável = melhor
        -0.5 * data['previous_defaults']  # Defaults anteriores = muito pior
    )
    
    # Converter probabilidades para decisões binárias
    approvals = np.random.binomial(1, 1 / (1 + np.exp(-approval_probability)), n_samples)
    
    df = pd.DataFrame(data)
    df['approved'] = approvals
    
    return df


def train_credit_model(df):
    """
    Treina modelo de aprovação de crédito.
    
    Args:
        df: DataFrame com dados
    
    Returns:
        Modelo treinado e dados de teste
    """
    # Preparar features e target
    X = df.drop('approved', axis=1)
    y = df['approved']
    
    # Dividir em treino e teste
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )
    
    # Treinar modelo
    model = RandomForestClassifier(
        n_estimators=100,
        max_depth=10,
        random_state=42
    )
    model.fit(X_train, y_train)
    
    # Avaliar modelo
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    
    print(f"Modelo treinado com accuracy: {accuracy:.3f}")
    print("\\nRelatório de classificação:")
    print(classification_report(y_test, y_pred))
    
    return model, X_test, y_test


def demonstrate_governance(model, X_test, y_test):
    """
    Demonstra governança usando OpenBox.
    
    Args:
        model: Modelo treinado
        X_test: Dados de teste
        y_test: Labels verdadeiros
    """
    print("\\n" + "="*60)
    print("DEMONSTRAÇÃO DE GOVERNANÇA OPENBOX")
    print("="*60)
    
    # 1. Configurar sistema de governança
    print("\\n1. Configurando sistema de governança...")
    config = OmegaMinConfig()
    
    # 2. Fazer predições
    print("\\n2. Fazendo predições...")
    predictions = model.predict(X_test)
    
    # 3. Avaliar com CVaR
    print("\\n3. Avaliando risco com CVaR...")
    cvar_monitor = CVaRMonitor(
        alpha=config.cvar_alpha,
        max_allow=config.cvar_max_allow,
        max_degrade=config.cvar_max_degrade
    )
    
    cvar_result = cvar_monitor.evaluate(model, X_test, y_test)
    print(f"CVaR: {cvar_result['cvar']:.3f}")
    print(f"Decisão CVaR: {cvar_result['decision']}")
    print(f"VaR: {cvar_result['var']:.3f}")
    
    # 4. Avaliar com Ω-GATE
    print("\\n4. Avaliando com Ω-GATE...")
    omega_gate = OmegaGate(config.omega_weights, config.omega_thresholds)
    
    # Simular controles adicionais
    controls = {
        'cvar': cvar_result['cvar'],
        'metamorphic_violations': 0.03,  # Simulado
        'latency_p95': 85.0,  # Simulado
        'drift_score': 0.02,  # Simulado
        'observability_available': True
    }
    
    gate_result = omega_gate.decide(controls)
    print(f"Decisão Ω-GATE: {gate_result.action}")
    print(f"Score Ω: {gate_result.omega_score:.3f}")
    print(f"Justificativa: {gate_result.justification}")
    
    # 5. Registrar no ledger
    print("\\n5. Registrando evidência no ledger...")
    ledger = AppendOnlyLedger(config.ledger_path)
    
    evidence_data = {
        "evaluation_type": "credit_approval",
        "model_info": {
            "type": "RandomForest",
            "accuracy": accuracy_score(y_test, predictions)
        },
        "governance_results": {
            "cvar": cvar_result,
            "gate_decision": gate_result.to_dict()
        },
        "business_metrics": {
            "approval_rate": np.mean(predictions),
            "default_rate": 1 - np.mean(predictions == y_test)
        }
    }
    
    ledger_entry = ledger.append(evidence_data)
    print(f"Registro no ledger: {ledger_entry['record_hash'][:16]}...")
    
    # 6. Verificar integridade
    print("\\n6. Verificando integridade do ledger...")
    verification = ledger.verify()
    print(f"Ledger válido: {verification['valid']}")
    print(f"Total de registros: {verification['total_records']}")
    
    # 7. Estatísticas
    print("\\n7. Estatísticas do sistema...")
    ledger_stats = ledger.get_statistics()
    cvar_stats = cvar_monitor.get_risk_metrics()
    gate_stats = omega_gate.get_decision_statistics()
    
    print(f"Arquivo do ledger: {ledger_stats['file_size_mb']:.2f} MB")
    print(f"CVaR médio: {cvar_stats.get('mean', 'N/A')}")
    print(f"Ω-GATE decisões: {gate_stats['decision_distribution']}")
    
    return {
        'config': config,
        'cvar_result': cvar_result,
        'gate_result': gate_result,
        'ledger': ledger,
        'evidence_data': evidence_data
    }


def simulate_different_scenarios(model, X_test, y_test):
    """
    Simula diferentes cenários para demonstrar robustez.
    
    Args:
        model: Modelo treinado
        X_test: Dados de teste
        y_test: Labels verdadeiros
    """
    print("\\n" + "="*60)
    print("SIMULAÇÃO DE DIFERENTES CENÁRIOS")
    print("="*60)
    
    # Configurar sistema
    config = OmegaMinConfig()
    cvar_monitor = CVaRMonitor(
        alpha=config.cvar_alpha,
        max_allow=config.cvar_max_allow,
        max_degrade=config.cvar_max_degrade
    )
    omega_gate = OmegaGate(config.omega_weights, config.omega_thresholds)
    
    scenarios = [
        {
            'name': 'Dados Normais',
            'description': 'Cenário com dados normais',
            'X_modifications': lambda x: x,
            'expected_action': 'ALLOW'
        },
        {
            'name': 'Dados com Ruído',
            'description': 'Adiciona ruído às features',
            'X_modifications': lambda x: x + np.random.normal(0, 0.1, x.shape),
            'expected_action': 'DEGRADE'
        },
        {
            'name': 'Dados Adversariais',
            'description': 'Perturbações maiores (ataque)',
            'X_modifications': lambda x: x + np.random.normal(0, 0.5, x.shape),
            'expected_action': 'BLOCK'
        },
        {
            'name': 'Deriva de Dados',
            'description': 'Shift na distribuição',
            'X_modifications': lambda x: x * 1.2 + np.random.normal(0, 0.2, x.shape),
            'expected_action': 'DEGRADE'
        }
    ]
    
    results = []
    
    for scenario in scenarios:
        print(f"\\n--- Cenário: {scenario['name']} ---")
        print(f"Descrição: {scenario['description']}")
        
        # Aplicar modificações
        X_modified = scenario['X_modifications'](X_test)
        
        # Avaliar
        cvar_result = cvar_monitor.evaluate(model, X_modified, y_test)
        
        controls = {
            'cvar': cvar_result['cvar'],
            'metamorphic_violations': 0.03,
            'latency_p95': 85.0,
            'drift_score': 0.02,
            'observability_available': True
        }
        
        gate_result = omega_gate.decide(controls)
        
        # Resultado
        actual_action = gate_result.action
        expected_action = scenario['expected_action']
        correct = actual_action == expected_action
        
        print(f"Ação esperada: {expected_action}")
        print(f"Ação tomada: {actual_action}")
        print(f"Correta: {'✓' if correct else '✗'}")
        print(f"Score Ω: {gate_result.omega_score:.3f}")
        print(f"CVaR: {cvar_result['cvar']:.3f}")
        
        results.append({
            'scenario': scenario['name'],
            'expected': expected_action,
            'actual': actual_action,
            'correct': correct,
            'omega_score': gate_result.omega_score,
            'cvar': cvar_result['cvar']
        })
    
    # Resumo
    correct_count = sum(1 for r in results if r['correct'])
    total_count = len(results)
    accuracy = correct_count / total_count
    
    print(f"\\n{'='*60}")
    print(f"RESUMO: {correct_count}/{total_count} cenários corretos ({accuracy:.1%})")
    
    return results


def create_visualization(governance_results):
    """
    Cria visualizações dos resultados.
    
    Args:
        governance_results: Resultados da governança
    """
    print("\\nCriando visualizações...")
    
    try:
        # Configurar matplotlib
        plt.style.use('default')
        
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # Gráfico 1: Distribuição de CVaR
        cvar_history = governance_results['cvar_result']['statistics'].get('cvar_history', [])
        if cvar_history:
            axes[0, 0].hist(cvar_history, bins=20, alpha=0.7, edgecolor='black')
            axes[0, 0].axvline(governance_results['cvar_result']['cvar'], color='r', 
                             linestyle='--', label='CVaR Atual')
            axes[0, 0].axvline(0.20, color='g', linestyle='--', label='Threshold Allow')
            axes[0, 0].set_xlabel('CVaR')
            axes[0, 0].set_ylabel('Frequência')
            axes[0, 0].set_title('Distribuição de CVaR')
            axes[0, 0].legend()
        
        # Gráfico 2: Score Ω
        omega_result = governance_results['gate_result']
        metrics = omega_result.normalized_metrics
        metric_names = list(metrics.keys())
        metric_values = list(metrics.values())
        
        axes[0, 1].bar(metric_names, metric_values, alpha=0.7)
        axes[0, 1].set_ylabel('Score Normalizado')
        axes[0, 1].set_title(f'Métricas Normalizadas (Ω = {omega_result.omega_score:.3f})')
        axes[0, 1].tick_params(axis='x', rotation=45)
        
        # Gráfico 3: Decisão Ω-GATE
        thresholds = omega_result.omega_score
        decision = omega_result.action
        
        colors = {'ALLOW': 'green', 'DEGRADE': 'orange', 'BLOCK': 'red'}
        color = colors.get(decision, 'gray')
        
        axes[1, 0].bar(['Score Ω'], [thresholds], color=color, alpha=0.7)
        axes[1, 0].axhline(0.8, color='g', linestyle='--', label='Allow Threshold')
        axes[1, 0].axhline(0.6, color='orange', linestyle='--', label='Degrade Threshold')
        axes[1, 0].set_ylim(0, 1)
        axes[1, 0].set_ylabel('Score Ω')
        axes[1, 0].set_title(f'Decisão: {decision}')
        axes[1, 0].legend()
        
        # Gráfico 4: Ledger
        ledger = governance_results['ledger']
        ledger_stats = ledger.get_statistics()
        
        # Simular histórico de tamanhos de arquivo
        file_sizes = [ledger_stats['file_size_mb'] * 0.1 * i for i in range(1, 11)]
        axes[1, 1].plot(file_sizes, 'b-', linewidth=2)
        axes[1, 1].set_xlabel('Avaliação')
        axes[1, 1].set_ylabel('Tamanho do Ledger (MB)')
        axes[1, 1].set_title('Crescimento do Ledger')
        axes[1, 1].grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.savefig('governance_results.png', dpi=300, bbox_inches='tight')
        plt.show()
        
        print("Visualização salva como 'governance_results.png'")
        
    except ImportError:
        print("Matplotlib não disponível. Pulando visualização.")
    except Exception as e:
        print(f"Erro na visualização: {e}")


def main():
    """
    Função principal do exemplo.
    """
    print("OpenBox Omega-Min - Exemplo de Governança de Crédito")
    print("=" * 60)
    
    try:
        # 1. Carregar dados
        print("\\n1. Carregando dados de crédito...")
        df = load_credit_data()
        print(f"Dados carregados: {len(df)} amostras")
        print(f"Taxa de aprovação: {df['approved'].mean():.1%}")
        
        # 2. Treinar modelo
        print("\\n2. Treinando modelo de crédito...")
        model, X_test, y_test = train_credit_model(df)
        
        # 3. Demonstrar governança
        governance_results = demonstrate_governance(model, X_test, y_test)
        
        # 4. Simular diferentes cenários
        scenario_results = simulate_different_scenarios(model, X_test, y_test)
        
        # 5. Criar visualizações
        create_visualization(governance_results)
        
        # 6. Resumo final
        print("\\n" + "="*60)
        print("RESUMO FINAL")
        print("="*60)
        
        print(f"✓ Sistema configurado com governança operacional")
        print(f"✓ CVaR monitorando risco de cauda: {governance_results['cvar_result']['cvar']:.3f}")
        print(f"✓ Ω-GATE tomando decisões automáticas: {governance_results['gate_result'].action}")
        print(f"✓ Ledger registrando evidências: {len(governance_results['ledger'].get_records())} registros")
        print(f"✓ Cenários testados: {len(scenario_results)} cenários")
        
        # Estatísticas finais
        ledger_stats = governance_results['ledger'].get_statistics()
        print(f"\\nLedger: {ledger_stats['total_records']} registros, {ledger_stats['file_size_mb']:.2f} MB")
        
        print("\\n🎯 O sistema está governado sem dependência de explicabilidade!")
        print("📊 Monitore o ledger para auditoria completa")
        print("🔍 Use a API para integração com sistemas de produção")
        
    except Exception as e:
        print(f"\\n❌ Erro na execução: {e}")
        raise


if __name__ == "__main__":
    main()