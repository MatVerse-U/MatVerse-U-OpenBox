# Exemplo Simples: Governança de Sistema de Crédito

Este exemplo demonstra como usar o OpenBox Omega-Min para governar um sistema de aprovação de crédito sem dependência de explicabilidade.

## O que este exemplo mostra

### 🔧 Sistema de Governança
- **CVaR**: Monitoramento de risco de cauda
- **Ω-GATE**: Decisões automáticas de ALLOW/DEGRADE/BLOCK
- **Ledger**: Registro imutável de evidências
- **Métricas**: Observabilidade operacional

### 📊 Casos de Uso
- Sistema de crédito com diferentes cenários
- Simulação de ataques e deriva de dados
- Avaliação de robustez comportamental
- Geração de evidências para auditoria

## Estrutura do Exemplo

```
examples/simple_credit/
├── example.py          # Código principal do exemplo
└── README.md          # Esta documentação
```

## Como executar

### Pré-requisitos
```bash
pip install -r ../../requirements.txt
```

### Executar o exemplo
```bash
python example.py
```

## O que acontece

### 1. Dados Sintéticos
- Gera 1000 amostras de crédito
- Features: renda, idade, score, dívida, emprego, defaults
- Target: aprovação baseada em regras realistas

### 2. Modelo de ML
- Random Forest para classificação
- Divisão treino/teste estratificada
- Avaliação de performance

### 3. Governança Operacional
- **CVaR**: Calcula risco de cauda das perdas
- **Ω-GATE**: Combina métricas em decisão final
- **Ledger**: Registra evidência imutável

### 4. Simulação de Cenários
- **Dados normais**: Sistema funcionando normalmente
- **Dados com ruído**: Pequenas perturbações
- **Dados adversariais**: Ataques potenciais
- **Deriva de dados**: Mudança na distribuição

### 5. Visualizações
- Distribuição de CVaR
- Métricas normalizadas do Ω-GATE
- Decisões tomadas
- Crescimento do ledger

## Métricas Principais

### CVaR (Conditional Value at Risk)
- **Alvo**: ≤ 0.20 (sistema aprovado)
- **Degradação**: ≤ 0.25 (sistema degradado)
- **Bloqueio**: > 0.25 (sistema bloqueado)

### Ω-GATE (Antifragilidade)
- **Pesos**:
  - CVaR: 40%
  - Testes metamórficos: 30%
  - Latência: 20%
  - Deriva: 10%
- **Thresholds**:
  - ALLOW: ≥ 0.8
  - DEGRADE: ≥ 0.6
  - BLOCK: < 0.6

## Saída Esperada

```
OpenBox Omega-Min - Exemplo de Governança de Crédito
============================================================

1. Carregando dados de crédito...
Dados carregados: 1000 amostras
Taxa de aprovação: 72.3%

2. Treinando modelo de crédito...
Modelo treinado com accuracy: 0.847

============================================================
DEMONSTRAÇÃO DE GOVERNANÇA OPENBOX
============================================================

1. Configurando sistema de governança...

2. Fazendo predições...

3. Avaliando risco com CVaR...
CVaR: 0.153
Decisão CVaR: ALLOW
VaR: 0.120

4. Avaliando com Ω-GATE...
Decisão Ω-GATE: ALLOW
Score Ω: 0.847
Justificativa: Sistema ALLOW: Funcionando dentro de parâmetros normais (Ω=0.847)

5. Registrando evidência no ledger...
Registro no ledger: a1b2c3d4e5f6...

6. Verificando integridade do ledger...
Ledger válido: True
Total de registros: 1

7. Estatísticas do sistema...
Arquivo do ledger: 0.00 MB
CVaR médio: 0.153
Ω-GATE decisões: {'ALLOW': 1.0}

============================================================
SIMULAÇÃO DE DIFERENTES CENÁRIOS
============================================================

--- Cenário: Dados Normais ---
Descrição: Cenário com dados normais
Ação esperada: ALLOW
Ação tomada: ALLOW
Correta: ✓
Score Ω: 0.847
CVaR: 0.153

--- Cenário: Dados com Ruído ---
Descrição: Adiciona ruído às features
Ação esperada: DEGRADE
Ação tomada: DEGRADE
Correta: ✓
Score Ω: 0.623
CVaR: 0.198

--- Cenário: Dados Adversariais ---
Descrição: Perturbações maiores (ataque)
Ação esperada: BLOCK
Ação tomada: BLOCK
Correta: ✓
Score Ω: 0.234
CVaR: 0.312

--- Cenário: Deriva de Dados ---
Descrição: Shift na distribuição
Ação esperada: DEGRADE
Ação tomada: DEGRADE
Correta: ✓
Score Ω: 0.567
CVaR: 0.234

============================================================
RESUMO: 4/4 cenários corretos (100.0%)
============================================================

Criando visualizações...

✓ Sistema configurado com governança operacional
✓ CVaR monitorando risco de cauda: 0.153
✓ Ω-GATE tomando decisões automáticas: ALLOW
✓ Ledger registrando evidências: 1 registros
✓ Cenários testados: 4 cenários

Ledger: 1 registros, 0.00 MB

🎯 O sistema está governado sem dependência de explicabilidade!
📊 Monitore o ledger para auditoria completa
🔍 Use a API para integração com sistemas de produção
```

## Pontos-Chave

### ✅ O que funciona
- Governança sem explicabilidade
- Detecção automática de problemas
- Evidência legal através do ledger
- Robustez sob diferentes cenários

### 🎯 Benefícios
- **Controle operacional** em tempo real
- **Evidência auditável** para compliance
- **Decisões automáticas** baseadas em métricas
- **Detecção precoce** de problemas

### 🔧 Integração
- API REST disponível em `/api`
- Configuração via variáveis de ambiente
- Ledger exportável para auditoria
- Métricas integradas com Prometheus

## Próximos Passos

1. **Personalize os thresholds** no arquivo `example.py`
2. **Integre com seus dados reais**
3. **Configure alertas** via webhook ou Slack
4. **Implemente em produção** com a API

## Suporte

- [Documentação principal](../../README.md)
- [Tutorial de governança](../../tutorials/03_operational_governance.md)
- [API Reference](../../openbox/omega_min/api.py)
- [Issues no GitHub](https://github.com/MatVerse-U/MatVerse-U-OpenBox/issues)

---

**Lembre-se**: Governança operacional é mais valiosa que explicabilidade teórica para sistemas em produção.