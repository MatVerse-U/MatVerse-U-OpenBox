# Tutorial 1: O Problema da Caixa-Preta

**Entendendo por que sistemas caixa-preta são a realidade da IA moderna e como governá-los.**

---

## Objetivos de Aprendizagem

Após este tutorial, você será capaz de:

1. **Reconhecer** que caixa-preta não é defeito, é realidade
2. **Distinguir** entre opacidade técnica e opacidade de controle
3. **Identificar** cenários onde explicabilidade falha
4. **Entender** a diferença entre governar e explicar

## 1. A Realidade da IA Moderna

### Por Que Todo Sistema é Caixa-Preta

A ideia de que podemos "abrir a caixa" da IA é uma **ilusão**. Vejamos por quê:

#### 1.1 Modelos Proprietários

```python
# Exemplo: API de LLM proprietária
import openai

# Não temos acesso ao modelo interno
response = openai.ChatCompletion.create(
    model="gpt-4",  # Modelo caixa-preta total
    messages=[{"role": "user", "content": "Analyze this loan application"}]
)

# Não podemos explicar como o modelo chegou à resposta
print(response.choices[0].message.content)
```

**Realidade**: APIs externas são 100% caixa-preta por design.

#### 1.2 Modelos Gigantes

```python
# Exemplo: Transformer com 175 bilhões de parâmetros
model_size_gb = 700  # GPT-3

# Impossível de interpretar manualmente
total_parameters = 175_000_000_000
print(f"Parâmetros: {total_parameters:,}")
print(f"Tamanho: {model_size_gb} GB")
print("Impossível entender manualmente")
```

**Realidade**: Modelos gigantes são intrinsecamente incompreensíveis.

#### 1.3 Sistemas Híbridos

```python
# Exemplo: Sistema de crédito que combina múltiplos componentes
class CreditScoringSystem:
    def __init__(self):
        # Componente 1: API externa de bureau de crédito
        self.bureau_api = ExternalBureauAPI()
        
        # Componente 2: Modelo de ML interno
        self.ml_model = load_model("credit_model.pkl")
        
        # Componente 3: Regras de negócio
        self.business_rules = BusinessRulesEngine()
        
        # Componente 4: Serviço de fraude
        self.fraud_service = FraudDetectionService()
    
    def evaluate(self, applicant):
        # Cada componente é uma caixa-preta
        bureau_score = self.bureau_api.get_score(applicant)
        ml_score = self.ml_model.predict(applicant.features)
        rule_score = self.business_rules.evaluate(applicant)
        fraud_score = self.fraud_service.check(applicant)
        
        # Sistema global é caixa-preta composta
        final_score = self.combine_scores(bureau_score, ml_score, rule_score, fraud_score)
        return final_score

# Sistema completo é caixa-preta sem possibilidade de explicação
system = CreditScoringSystem()
result = system.evaluate(applicant_data)
```

**Realidade**: Sistemas reais combinam múltiplas caixas-pretas.

## 2. O Problema Real: Não É "Como Funciona", É "Posso Confiar?"

### 2.1 A Confusão Central

Muitos pensam que o problema da IA é:

> *"Não sabemos como o modelo funciona."*

O problema real é:

> *"Não sabemos se podemos confiar no modelo."*

### 2.2 Consequências Práticas

```python
# Cenário: Sistema de crédito nega empréstimo
# Questão 1 (explicabilidade): "Por que foi negado?"
# Questão 2 (governança): "O sistema está funcionando corretamente?"

# Explicabilidade pergunta: Qual feature teve mais peso?
# Governança pergunta: Qual o risco de default?

def explainability_question(features, prediction):
    """O que a explicabilidade pergunta."""
    # SHAP values mostram correlação
    shap_values = compute_shap(features, prediction)
    return f"Feature X foi determinante com peso {shap_values[0]:.3f}"

def governance_question(system_metrics):
    """O que a governança pergunta."""
    # CVaR mostra risco real
    cvar_value = compute_cvar(system_metrics['losses'])
    return f"Risco de cauda (CVaR): {cvar_value:.3f}"

# Para auditoria regulatória, governança é mais valiosa
print("Explicabilidade:", explainability_question(features, prediction))
print("Governança:", governance_question(system_metrics))
```

## 3. Casos Reais de Falhas da Explicabilidade

### Caso 1: Healthcare AI - Diagnóstico Incorreto

```python
# Sistema de IA para radiologia
class MedicalDiagnosisAI:
    def __init__(self):
        self.model = load_pretrained_model("medical_ai.pkl")
    
    def diagnose(self, xray_image):
        # Predição: вероятность de câncer = 0.7
        prediction = self.model.predict(xray_image)
        
        # Explicabilidade: mostra que região X foi importante
        explanation = get_shap_explanation(xray_image)
        
        # MAS: o que interessa é se o sistema é confiável
        return {
            'prediction': prediction,
            'confidence': self.model.predict_proba(xray_image),
            'explanation': explanation
        }

# Problema: Explicação não garante confiabilidade
# Mesmo com explicação "correta", o sistema pode estar errado
```

### Caso 2: Financial Trading - Losses Massivas

```python
# Sistema de trading automatizado
class TradingBot:
    def __init__(self):
        self.model = load_trading_model("trading_ai.pkl")
        self.explainer = shap.Explainer(self.model)
    
    def make_trade(self, market_data):
        # Decisão: COMPRAR
        decision = self.model.predict(market_data)
        
        # Explicação: "Fatores X, Y, Z sugerem alta"
        explanation = self.explainer(market_data)
        
        return {
            'decision': decision,
            'explanation': explanation,
            'expected_return': self.model.predict_proba(market_data)
        }

# Problema: Explicações não previnem losses
# Em 2020, many "explicáveis" AI trading systems falharam
# porque explicabilidade ≠ controle
```

### Caso 3: Criminal Justice - Bias Sistemático

```python
# Sistema COMPAS para avaliação de risco criminal
class COMPASSystem:
    def __init__(self):
        self.model = load_model("compas.pkl")
        self.explainer = shap.Explainer(self.model)
    
    def assess_risk(self, defendant):
        # Risco: 0.8 (alto)
        risk_score = self.model.predict(defendant)
        
        # Explicação: "Histórico criminal foi fator decisivo"
        explanation = self.explainer(defendant)
        
        return {
            'risk_score': risk_score,
            'explanation': explanation
        }

# Problema: Estudos mostraram que o sistema tem bias racial
# Explicações não revelam bias sistêmico
# Governança real seria: testes de bias + controles
```

## 4. O Que Explicabilidade NÃO Resolve

### 4.1 Instabilidade Sob Perturbações

```python
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import shap

# Modelo treinado
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Instância base
x_base = X_test[0:1]
prediction_base = model.predict(x_base)

# Explicação base
explainer = shap.Explainer(model)
shap_base = explainer(x_base)

# Perturbação mínima (ruído)
x_perturbed = x_base + np.random.normal(0, 0.001, x_base.shape)
prediction_perturbed = model.predict(x_perturbed)

# Explicação após perturbação
shap_perturbed = explainer(x_perturbed)

print(f"Predição base: {prediction_base}")
print(f"Predição perturbada: {prediction_perturbed}")
print(f"Stabilidade da explicação: {np.linalg.norm(shap_base.values - shap_perturbed.values):.4f}")

# Conclusão: Mudanças mínimas mudam explicações dramaticamente
```

### 4.2 Fidelidade Global Baixa

```python
def analyze_global_fidelity(model, X_test, n_samples=100):
    """Analisa quão bem explicações locais representam comportamento global."""
    
    # SHAP para instâncias locais
    explainer = shap.Explainer(model)
    local_explanations = []
    
    for i in range(n_samples):
        exp = explainer(X_test[i:i+1])
        local_explanations.append(exp.values.flatten())
    
    # Importância global via permutation importance
    from sklearn.inspection import permutation_importance
    global_importance = permutation_importance(model, X_test, y_test)
    
    # Correlação entre local e global
    correlations = []
    for local_exp in local_explanations:
        corr = np.corrcoef(local_exp, global_importance.importances_mean)[0,1]
        correlations.append(corr)
    
    return np.mean(correlations)

# Resultado típico: correlação < 0.6
fidelity = analyze_global_fidelity(model, X_test)
print(f"Fidelidade Global: {fidelity:.3f}")
print("Conclusão: Explicações locais não representam comportamento global")
```

### 4.3 Impossibilidade de Causalidade

```python
def spurious_correlation_demo():
    """Demonstra como XAI identifica correlação, não causalidade."""
    
    np.random.seed(42)
    n = 1000
    
    # Fator latente (não observável)
    latent = np.random.normal(0, 1, n)
    
    # Features correlacionadas com fator latente
    feature_a = latent + np.random.normal(0, 0.1, n)
    feature_b = latent + np.random.normal(0, 0.2, n)
    
    # Target correlacionado
    y = latent + np.random.normal(0, 0.1, n)
    
    X = np.column_stack([feature_a, feature_b])
    
    # Modelo treinado
    model = RandomForestRegressor()
    model.fit(X, y)
    
    # Análise SHAP
    explainer = shap.Explainer(model)
    shap_values = explainer(X)
    
    print("SHAP identifica correlação com fator latente não observável:")
    print(f"Importância feature_a: {np.mean(np.abs(shap_values.values[:, 0])):.3f}")
    print(f"Importância feature_b: {np.mean(np.abs(shap_values.values[:, 1])):.3f}")
    print("MAS não pode distinguir correlação de causalidade")

spurious_correlation_demo()
```

## 5. A Solução: Governança Operacional

### 5.1 Diferença Fundamental

```python
class ExplainabilityApproach:
    """Abordagem baseada em explicabilidade."""
    
    def __init__(self, model):
        self.model = model
        self.explainer = shap.Explainer(model)
    
    def analyze(self, x):
        # 1. Fazer predição
        prediction = self.model.predict(x)
        
        # 2. Gerar explicação
        explanation = self.explainer(x)
        
        # 3. Concluir baseado em correlação
        return {
            'prediction': prediction,
            'explanation': explanation,
            'correlation': 'Identifica correlação, não causalidade'
        }

class GovernanceApproach:
    """Abordagem baseada em governança."""
    
    def __init__(self, model, config):
        self.model = model
        self.cvar_monitor = CVaRMonitor(config)
        self.metamorphic_tests = MetamorphicTests(config)
        self.ledger = AppendOnlyLedger(config.ledger_path)
    
    def analyze(self, x, reference_data):
        # 1. Fazer predição
        prediction = self.model.predict(x)
        
        # 2. Avaliar risco de cauda (CVaR)
        cvar_score = self.cvar_monitor.evaluate(reference_data)
        
        # 3. Testar robustez comportamental
        robustness_score = self.metamorphic_tests.evaluate(self.model, reference_data)
        
        # 4. Decisão de governança
        decision = self.omega_gate.decide({
            'cvar': cvar_score,
            'robustness': robustness_score
        })
        
        # 5. Registrar evidência
        self.ledger.append({
            'timestamp': datetime.now().isoformat(),
            'decision': decision,
            'metrics': {'cvar': cvar_score, 'robustness': robustness_score}
        })
        
        return {
            'prediction': prediction,
            'governance_decision': decision,
            'evidence': 'Controle operacional + evidência auditável'
        }

# Comparação
print("Explicabilidade:")
print("- Pergunta: 'Por que?'")
print("- Método: SHAP/LIME")
print("- Resultado: Correlação (instável)")
print("- Valor legal: Baixo")

print("\nGovernança:")
print("- Pergunta: 'Posso confiar?'")
print("- Método: CVaR + testes metamórficos")
print("- Resultado: Controle (robusto)")
print("- Valor legal: Alto")
```

### 5.2 Componentes da Governança

```python
# Framework de Governança OpenBox
class OpenBoxGovernance:
    """
    Sistema completo de governança para sistemas de IA.
    
    Componentes:
    1. CVaR: Risco de cauda
    2. Testes metamórficos: Robustez
    3. UMJAM: Controle dinâmico
    4. Ledger: Evidência imutável
    """
    
    def __init__(self, config):
        self.config = config
        self.setup_components()
    
    def setup_components(self):
        """Inicializa componentes de governança."""
        # 1. Monitor CVaR
        self.cvar_monitor = CVaRMonitor(
            alpha=self.config.cvar_alpha,
            threshold=self.config.cvar_threshold
        )
        
        # 2. Testes metamórficos
        self.metamorphic_tester = MetamorphicTestSuite(
            transformations=self.config.metamorphic_transformations,
            tolerance=self.config.metamorphic_tolerance
        )
        
        # 3. Controlador UMJAM
        self.umjam_controller = UMJAMController(
            target=self.config.umjam_target,
            convergence_rate=self.config.umjam_rate
        )
        
        # 4. Ledger imutável
        self.ledger = AppendOnlyLedger(
            path=self.config.ledger_path,
            hash_algorithm="sha3_256"
        )
        
        # 5. Ω-GATE (decisões)
        self.omega_gate = OmegaGate(
            weights=self.config.omega_weights,
            thresholds=self.config.omega_thresholds
        )
    
    def evaluate_system(self, model, X, y, metadata=None):
        """Avalia sistema completo usando governança."""
        
        # 1. Observabilidade
        observations = self.collect_observations(model, X, y)
        
        # 2. Controle
        controls = self.apply_controls(model, X, y, observations)
        
        # 3. Evidência
        evidence = self.record_evidence(observations, controls, metadata)
        
        # 4. Decisão final
        decision = self.omega_gate.decide(controls)
        
        return {
            'decision': decision,
            'observations': observations,
            'controls': controls,
            'evidence': evidence
        }
    
    def collect_observations(self, model, X, y):
        """Coleta observações operacionais."""
        predictions = model.predict(X)
        
        return {
            'accuracy': np.mean(predictions == y),
            'latency': self.measure_latency(model, X),
            'memory_usage': self.measure_memory(model),
            'drift_score': self.detect_drift(X, self.config.reference_data)
        }
    
    def apply_controls(self, model, X, y, observations):
        """Aplica controles de governança."""
        
        # CVaR: Risco de cauda
        losses = compute_losses(model.predict(X), y)
        cvar_score = self.cvar_monitor.evaluate(losses)
        
        # Testes metamórficos: Robustez
        robustness_score = self.metamorphic_tester.evaluate(model, X)
        
        # UMJAM: Controle dinâmico
        umjam_control = self.umjam_controller.update(observations['accuracy'])
        
        return {
            'cvar': cvar_score,
            'robustness': robustness_score,
            'umjam_control': umjam_control,
            'drift': observations['drift_score']
        }
    
    def record_evidence(self, observations, controls, metadata):
        """Registra evidência no ledger."""
        
        evidence_record = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'observations': observations,
            'controls': controls,
            'metadata': metadata or {}
        }
        
        # Hash e registro
        self.ledger.append(evidence_record)
        
        return {
            'ledger_entry': evidence_record,
            'integrity_hash': self.ledger._get_last_hash(),
            'verification': self.ledger.verify()
        }
```

## 6. Exercício Prático

### Exercício: Identifique o Problema Real

```python
# Scenario: Sistema de IA para aprovação de empréstimos
# Você é responsável por compliance

# Situação 1: Cliente A teve empréstimo negado
# Explicabilidade: "Score de crédito foi baixo"
# Governança: "Qual o CVaR dos empréstimos aprovados?"

# Situação 2: Modelo drift detectado
# Explicabilidade: "SHAP mostra mudança nas importâncias"
# Governança: "Qual a taxa de metamórficos violations?"

# Situação 3: Erro em produção
# Explicabilidade: "Análise SHAP do caso específico"
# Governança: "Como isso afeta o ledger de decisões?"

# Sua tarefa: Escreva código que implemente governança real
# não apenas explicabilidade

def implement_real_governance(model, X, y):
    """
    Implemente governança real (não explicabilidade).
    
    Use CVaR, testes metamórficos, ledger imutável.
    """
    # Sua implementação aqui
    pass

# Dica: Leia o próximo tutorial para ver a solução
```

## 7. Resumo

### Pontos-Chave

1. **Caixa-preta é realidade**, não exceção
2. **Explicabilidade ≠ Governança**
3. **Correlação não implica confiança**
4. **Controle operacional** é mais valioso que compreensão teórica
5. **Evidência imutável** tem maior valor legal

### Próximos Passos

- **Tutorial 2**: [Limites da Explicabilidade](./02_explainability_limits.md)
- **Tutorial 3**: [Governança Operacional](./03_operational_governance.md)

### Recursos Adicionais

- [WHY_NOT_XAI.md](../WHY_NOT_XAI.md) - Análise técnica detalhada
- [GOVERNANCE.md](../GOVERNANCE.md) - Implementação formal
- [openbox/omega_min/](../openbox/omega_min/) - Código de governança

---

**Lembre-se**: O objetivo não é abrir a caixa, mas controlá-la.