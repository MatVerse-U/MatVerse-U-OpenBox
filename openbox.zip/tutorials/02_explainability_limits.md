# Tutorial 2: Limites da Explicabilidade

**Análise técnica profunda de por que explicabilidade pós-hoc é insuficiente para governança operacional.**

---

## Objetivos de Aprendizagem

Após este tutorial, você será capaz de:

1. **Demonstrar** instabilidade de explicações sob perturbações
2. **Quantificar** baixa fidelidade global de explicações locais
3. **Identificar** problemas de correlação vs causalidade
4. **Calcular** custos reais de implementação XAI vs governança

## 1. Instabilidade Sob Perturbações Mínimas

### 1.1 Demonstração com Código

```python
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestClassifier
from sklearn.datasets import make_classification
import shap

# Gerar dados sintéticos
np.random.seed(42)
X, y = make_classification(n_samples=1000, n_features=10, n_informative=5, n_redundant=5, random_state=42)

# Treinar modelo
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y)

# Escolher instância para análise
instance_idx = 0
x_instance = X[instance_idx:instance_idx+1]

# Predição original
original_prediction = model.predict(x_instance)[0]
original_proba = model.predict_proba(x_instance)[0]

print(f"Predição original: {original_prediction}")
print(f"Probabilidade original: {original_proba}")

# Explicação SHAP original
explainer = shap.Explainer(model)
original_shap = explainer(x_instance)

# Teste de estabilidade
def stability_test(model, explainer, x_base, noise_levels):
    """Testa estabilidade de explicações sob diferentes níveis de ruído."""
    
    results = []
    
    for noise_level in noise_levels:
        # Gerar perturbações
        n_perturbations = 50
        perturbed_predictions = []
        perturbed_shap_values = []
        
        for _ in range(n_perturbations):
            # Perturbação com ruído gaussiano
            x_perturbed = x_base + np.random.normal(0, noise_level, x_base.shape)
            
            # Predição
            pred = model.predict(x_perturbed)[0]
            perturbed_predictions.append(pred)
            
            # Explicação
            shap_values = explainer(x_perturbed)
            perturbed_shap_values.append(shap_values.values.flatten())
        
        # Calcular métricas de estabilidade
        prediction_stability = np.mean(perturbed_predictions == original_prediction)
        
        # Estabilidade da explicação (distância média ao SHAP original)
        shap_distances = [
            np.linalg.norm(original_shap.values.flatten() - shap_vals)
            for shap_vals in perturbed_shap_values
        ]
        mean_shap_distance = np.mean(shap_distances)
        
        results.append({
            'noise_level': noise_level,
            'prediction_stability': prediction_stability,
            'shap_stability': 1 / (1 + mean_shap_distance),  # Normalizado
            'mean_shap_distance': mean_shap_distance
        })
    
    return results

# Testar diferentes níveis de ruído
noise_levels = np.logspace(-4, -1, 10)  # 0.0001 to 0.1
stability_results = stability_test(model, explainer, x_instance, noise_levels)

# Visualizar resultados
plt.figure(figsize=(12, 8))

plt.subplot(2, 2, 1)
noise_levels_plot = [r['noise_level'] for r in stability_results]
prediction_stability = [r['prediction_stability'] for r in stability_results]
plt.semilogx(noise_levels_plot, prediction_stability, 'bo-')
plt.title('Estabilidade da Predição')
plt.xlabel('Nível de Ruído')
plt.ylabel('Taxa de Acordo (%)')
plt.grid(True)

plt.subplot(2, 2, 2)
shap_stability = [r['shap_stability'] for r in stability_results]
plt.semilogx(noise_levels_plot, shap_stability, 'ro-')
plt.title('Estabilidade da Explicação SHAP')
plt.xlabel('Nível de Ruído')
plt.ylabel('Estabilidade (normalizada)')
plt.grid(True)

plt.subplot(2, 2, 3)
mean_distances = [r['mean_shap_distance'] for r in stability_results]
plt.semilogx(noise_levels_plot, mean_distances, 'go-')
plt.title('Distância Média do SHAP')
plt.xlabel('Nível de Ruído')
plt.ylabel('Distância Euclidiana')
plt.grid(True)

plt.subplot(2, 2, 4)
# Comparação direta
plt.semilogx(noise_levels_plot, prediction_stability, 'bo-', label='Predição')
plt.semilogx(noise_levels_plot, shap_stability, 'ro-', label='SHAP')
plt.title('Comparação: Predição vs Explicação')
plt.xlabel('Nível de Ruído')
plt.ylabel('Estabilidade')
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.show()

# Imprimir resultados quantitativos
print("\n=== RESULTADOS DE ESTABILIDADE ===")
for result in stability_results:
    print(f"Noise: {result['noise_level']:.4f} | "
          f"Pred: {result['prediction_stability']:.3f} | "
          f"SHAP: {result['shap_stability']:.3f} | "
          f"Dist: {result['mean_shap_distance']:.3f}")
```

### 1.2 Análise de Resultados

```python
def analyze_stability_results(results):
    """Analisa resultados de estabilidade."""
    
    # Estabilidade com ruído mínimo (0.0001)
    min_noise_stability = next(r['shap_stability'] for r in results if r['noise_level'] == 0.0001)
    
    # Estabilidade com ruído máximo (0.1)
    max_noise_stability = next(r['shap_stability'] for r in results if r['noise_level'] == 0.1)
    
    # Queda na estabilidade
    stability_drop = min_noise_stability - max_noise_stability
    stability_drop_percent = (stability_drop / min_noise_stability) * 100
    
    print(f"=== ANÁLISE DE ESTABILIDADE ===")
    print(f"Estabilidade com ruído mínimo: {min_noise_stability:.3f}")
    print(f"Estabilidade com ruído máximo: {max_noise_stability:.3f}")
    print(f"Queda na estabilidade: {stability_drop_percent:.1f}%")
    
    # Conclusão
    if stability_drop_percent > 50:
        print("⚠️  EXPLICAÇÕES SÃO ALTAMENTE INSTÁVEIS")
        print("   Pequenas perturbações mudam dramaticamente as explicações")
    else:
        print("✓ Explicações são relativamente estáveis")
    
    return stability_drop_percent

stability_drop = analyze_stability_results(stability_results)
```

### 1.3 Implicações Práticas

```python
def practical_implications():
    """Demonstra implicações práticas da instabilidade."""
    
    print("=== IMPLICAÇÕES PRÁTICAS ===")
    print()
    
    print("1. SISTEMA MÉDICO:")
    print("   - Pequena variação em exame de sangue")
    print("   - Explicação SHAP muda completamente")
    print("   - Médico não pode confiar na explicação")
    print()
    
    print("2. SISTEMA FINANCEIRO:")
    print("   - Pequena flutuação em dados de mercado")
    print("   - Explicação de trading muda drasticamente")
    print("   - Auditor não pode validar decisões")
    print()
    
    print("3. SISTEMA JURÍDICO:")
    print("   - Variação mínima em perfil de réu")
    print("   - Explicação de risco criminal muda")
    print("   - Juiz não pode justificar sentença")
    print()
    
    print("CONCLUSÃO: Explicações instáveis são inúteis para governança")

practical_implications()
```

## 2. Fidelidade Global vs Local

### 2.1 Medição de Fidelidade

```python
from sklearn.inspection import permutation_importance
from scipy.stats import spearmanr

def measure_global_fidelity(model, X_test, y_test, n_samples=200):
    """
    Mede fidelidade global de explicações locais.
    
    Fidelidade = correlação entre importância local média e importância global.
    """
    
    # 1. Explicações locais (SHAP)
    explainer = shap.Explainer(model)
    local_importances = []
    
    # Amostra para análise
    sample_indices = np.random.choice(len(X_test), n_samples, replace=False)
    
    for idx in sample_indices:
        exp = explainer(X_test[idx:idx+1])
        local_importances.append(np.abs(exp.values.flatten()))
    
    # Média das importâncias locais
    mean_local_importance = np.mean(local_importances, axis=0)
    
    # 2. Importância global (permutation importance)
    global_importance = permutation_importance(
        model, X_test, y_test, 
        n_repeats=10, random_state=42
    )
    
    # 3. Correlação entre local e global
    correlations = []
    for local_imp in local_importances:
        corr, _ = spearmanr(local_imp, global_importance.importances_mean)
        correlations.append(corr)
    
    mean_correlation = np.mean(correlations)
    std_correlation = np.std(correlations)
    
    # 4. Visualização
    plt.figure(figsize=(12, 5))
    
    plt.subplot(1, 2, 1)
    plt.bar(range(len(mean_local_importance)), mean_local_importance)
    plt.title('Importância Média Local (SHAP)')
    plt.xlabel('Feature')
    plt.ylabel('Importância')
    
    plt.subplot(1, 2, 2)
    plt.bar(range(len(global_importance.importances_mean)), 
            global_importance.importances_mean)
    plt.title('Importância Global (Permutation)')
    plt.xlabel('Feature')
    plt.ylabel('Importância')
    
    plt.tight_layout()
    plt.show()
    
    # Resultados
    print(f"=== FIDELIDADE GLOBAL ===")
    print(f"Correlação média (Spearman): {mean_correlation:.3f} ± {std_correlation:.3f}")
    print(f"Correlação mediana: {np.median(correlations):.3f}")
    
    # Avaliação
    if mean_correlation < 0.6:
        print("⚠️  BAIXA FIDELIDADE GLOBAL")
        print("   Explicações locais não representam comportamento global")
    elif mean_correlation < 0.8:
        print("⚠️  Fidelidade moderada")
        print("   Explicações locais têm representação parcial do global")
    else:
        print("✓ Boa fidelidade global")
    
    return {
        'mean_correlation': mean_correlation,
        'std_correlation': std_correlation,
        'local_importance': mean_local_importance,
        'global_importance': global_importance.importances_mean,
        'correlations': correlations
    }

# Executar análise
fidelity_results = measure_global_fidelity(model, X, y)
```

### 2.2 Análise por Subgrupos

```python
def analyze_subgroup_fidelity(model, X_test, y_test, feature_groups):
    """
    Analisa fidelidade por subgrupos de features.
    
    Pergunta: Explicações locais são consistentes entre diferentes tipos de features?
    """
    
    explainer = shap.Explainer(model)
    group_fidelities = {}
    
    for group_name, feature_indices in feature_groups.items():
        local_importances = []
        
        # Amostra para cada grupo
        for idx in range(min(100, len(X_test))):
            exp = explainer(X_test[idx:idx+1])
            group_importance = np.abs(exp.values.flatten()[feature_indices])
            local_importances.append(group_importance)
        
        mean_local = np.mean(local_importances, axis=0)
        
        # Importância global do grupo
        group_global = permutation_importance(
            model, X_test[:, feature_indices], y_test
        )
        
        # Correlação
        corr, _ = spearmanr(mean_local, group_global.importances_mean)
        group_fidelities[group_name] = corr
    
    # Resultados
    print("=== FIDELIDADE POR GRUPO DE FEATURES ===")
    for group, fidelity in group_fidelities.items():
        print(f"{group}: {fidelity:.3f}")
    
    return group_fidelities

# Exemplo: Grupos de features
feature_groups = {
    'demographic': [0, 1, 2],  # Idade, gênero, região
    'financial': [3, 4, 5],    # Renda, score, histórico
    'behavioral': [6, 7, 8, 9] # Padrões de uso, transação
}

subgroup_fidelities = analyze_subgroup_fidelity(model, X, y, feature_groups)
```

### 2.3 Problemas de Representatividade

```python
def analyze_representativeness(model, X_test, y_test):
    """
    Analisa se explicações são representativas de diferentes regiões do espaço.
    """
    
    explainer = shap.Explainer(model)
    
    # Dividir dados em clusters (regiões do espaço)
    from sklearn.cluster import KMeans
    kmeans = KMeans(n_clusters=5, random_state=42)
    clusters = kmeans.fit_predict(X_test)
    
    cluster_fidelities = {}
    
    for cluster_id in range(5):
        cluster_mask = clusters == cluster_id
        X_cluster = X_test[cluster_mask]
        y_cluster = y_test[cluster_mask]
        
        if len(X_cluster) < 10:  # Muito poucas amostras
            continue
        
        # Importâncias locais do cluster
        local_importances = []
        for idx in range(min(50, len(X_cluster))):
            exp = explainer(X_cluster[idx:idx+1])
            local_importances.append(np.abs(exp.values.flatten()))
        
        mean_local = np.mean(local_importances, axis=0)
        
        # Importância global do cluster
        cluster_global = permutation_importance(
            model, X_cluster, y_cluster
        )
        
        # Correlação
        corr, _ = spearmanr(mean_local, cluster_global.importances_mean)
        cluster_fidelities[f'cluster_{cluster_id}'] = corr
    
    print("=== FIDELIDADE POR CLUSTER ===")
    for cluster, fidelity in cluster_fidelities.items():
        print(f"{cluster}: {fidelity:.3f}")
    
    # Variação entre clusters
    fidelity_values = list(cluster_fidelities.values())
    fidelity_variance = np.var(fidelity_values)
    
    print(f"Variação de fidelidade entre clusters: {fidelity_variance:.3f}")
    
    if fidelity_variance > 0.1:
        print("⚠️  ALTA VARIAÇÃO DE FIDELIDADE")
        print("   Explicações variam muito entre diferentes regiões")
    
    return cluster_fidelities

cluster_analysis = analyze_representativeness(model, X, y)
```

## 3. Correlação vs Causalidade

### 3.1 Demonstração com Dados Sintéticos

```python
def spurious_correlation_experiment():
    """
    Experimento que demonstra como XAI identifica correlação,
    mas não causalidade.
    """
    
    np.random.seed(123)
    n = 2000
    
    # Fator causal latente (não observável)
    latent_factor = np.random.normal(0, 1, n)
    
    # Features correlacionadas com fator latente
    feature_1 = latent_factor + np.random.normal(0, 0.1, n)
    feature_2 = latent_factor + np.random.normal(0, 0.2, n)
    feature_3 = np.random.normal(0, 1, n)  # Independente
    
    # Target correlacionado com fator latente
    y = latent_factor + np.random.normal(0, 0.1, n)
    
    X = np.column_stack([feature_1, feature_2, feature_3])
    
    # Modelo treinado
    from sklearn.ensemble import RandomForestRegressor
    model = RandomForestRegressor(n_estimators=100, random_state=42)
    model.fit(X, y)
    
    # Análise SHAP
    explainer = shap.Explainer(model)
    shap_values = explainer(X)
    
    # Importâncias médias
    feature_importances = {
        'feature_1': np.mean(np.abs(shap_values.values[:, 0])),
        'feature_2': np.mean(np.abs(shap_values.values[:, 1])),
        'feature_3': np.mean(np.abs(shap_values.values[:, 2]))
    }
    
    # Correlações reais com target
    correlations = {
        'feature_1': np.corrcoef(feature_1, y)[0, 1],
        'feature_2': np.corrcoef(feature_2, y)[0, 1],
        'feature_3': np.corrcoef(feature_3, y)[0, 1]
    }
    
    # Correlações com fator latente
    latent_correlations = {
        'feature_1': np.corrcoef(feature_1, latent_factor)[0, 1],
        'feature_2': np.corrcoef(feature_2, latent_factor)[0, 1],
        'feature_3': np.corrcoef(feature_3, latent_factor)[0, 1]
    }
    
    # Visualização
    plt.figure(figsize=(15, 5))
    
    plt.subplot(1, 3, 1)
    features = list(feature_importances.keys())
    importances = list(feature_importances.values())
    plt.bar(features, importances)
    plt.title('SHAP Importances')
    plt.ylabel('Importância SHAP')
    plt.xticks(rotation=45)
    
    plt.subplot(1, 3, 2)
    correlations_vals = list(correlations.values())
    plt.bar(features, correlations_vals)
    plt.title('Correlação com Target')
    plt.ylabel('Correlação')
    plt.xticks(rotation=45)
    
    plt.subplot(1, 3, 3)
    latent_corr_vals = list(latent_correlations.values())
    plt.bar(features, latent_corr_vals)
    plt.title('Correlação com Fator Latente')
    plt.ylabel('Correlação')
    plt.xticks(rotation=45)
    
    plt.tight_layout()
    plt.show()
    
    # Análise
    print("=== CORRELAÇÃO vs CAUSALIDADE ===")
    print("\nFeature 1 (causal):")
    print(f"  - SHAP Importance: {feature_importances['feature_1']:.3f}")
    print(f"  - Correlação com target: {correlations['feature_1']:.3f}")
    print(f"  - Correlação com fator latente: {latent_correlations['feature_1']:.3f}")
    
    print("\nFeature 2 (causal):")
    print(f"  - SHAP Importance: {feature_importances['feature_2']:.3f}")
    print(f"  - Correlação com target: {correlations['feature_2']:.3f}")
    print(f"  - Correlação com fator latente: {latent_correlations['feature_2']:.3f}")
    
    print("\nFeature 3 (independente):")
    print(f"  - SHAP Importance: {feature_importances['feature_3']:.3f}")
    print(f"  - Correlação com target: {correlations['feature_3']:.3f}")
    print(f"  - Correlação com fator latente: {latent_correlations['feature_3']:.3f}")
    
    print("\n=== CONCLUSÃO ===")
    print("SHAP identifica correlação com fator latente não observável")
    print("MAS não pode distinguir:")
    print("  - Correlação real vs correlação espúria")
    print("  - Causa vs efeito")
    print("  - Feature relevante vs feature espúria")

# Executar experimento
spurious_correlation_experiment()
```

### 3.2 Caso Real: Bias em Recrutamento

```python
def recruitment_bias_example():
    """
    Caso real: Sistema de IA para recrutamento com bias oculto.
    """
    
    np.random.seed(456)
    n = 1000
    
    # Fator latente: qualidade real do candidato (não observado)
    true_quality = np.random.normal(0, 1, n)
    
    # Features observáveis (com bias)
    years_experience = np.maximum(0, true_quality + np.random.normal(0, 0.5, n))
    university_rank = np.maximum(1, np.minimum(5, 3 + true_quality + np.random.normal(0, 0.8, n)))
    
    # Feature com bias sistemático (universidade)
    # Universidades de elite têm advantage não relacionado à qualidade
    university_bias = np.random.choice([0, 1], size=n, p=[0.7, 0.3])  # 30% elite
    university_bonus = university_bias * 0.5  # Bônus para elite
    
    # Score final (com bias)
    final_score = true_quality + university_bonus + np.random.normal(0, 0.2, n)
    
    # Decisão de contratação
    hired = final_score > np.percentile(final_score, 70)
    
    X = np.column_stack([years_experience, university_rank, university_bias])
    
    # Modelo treinado
    from sklearn.ensemble import RandomForestClassifier
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X, hired)
    
    # Análise SHAP
    explainer = shap.Explainer(model)
    shap_values = explainer(X)
    
    # Importâncias por grupo
    elite_mask = university_bias == 1
    non_elite_mask = university_bias == 0
    
    elite_importance = np.mean(np.abs(shap_values.values[elite_mask, :]), axis=0)
    non_elite_importance = np.mean(np.abs(shap_values.values[non_elite_mask, :]), axis=0)
    
    print("=== BIAS EM RECRUTAMENTO ===")
    print("\nImportância SHAP para candidatos elite:")
    print(f"  - Anos de experiência: {elite_importance[0]:.3f}")
    print(f"  - Ranking universidade: {elite_importance[1]:.3f}")
    print(f"  - Universidade elite: {elite_importance[2]:.3f}")
    
    print("\nImportância SHAP para candidatos não-elite:")
    print(f"  - Anos de experiência: {non_elite_importance[0]:.3f}")
    print(f"  - Ranking universidade: {non_elite_importance[1]:.3f}")
    print(f"  - Universidade elite: {non_elite_importance[2]:.3f}")
    
    # Taxa de contratação
    elite_hire_rate = np.mean(hired[elite_mask])
    non_elite_hire_rate = np.mean(hired[non_elite_mask])
    
    print(f"\nTaxa de contratação:")
    print(f"  - Candidato elite: {elite_hire_rate:.3f}")
    print(f"  - Candidato não-elite: {non_elite_hire_rate:.3f}")
    print(f"  - Bias: {elite_hire_rate - non_elite_hire_rate:.3f}")
    
    print("\n=== LIMITAÇÕES DO XAI ===")
    print("1. SHAP mostra correlação, não causalidade")
    print("2. Não detecta bias sistêmico")
    print("3. Explicações variam por subgrupo")
    print("4. Não fornece controle para corrigir bias")

recruitment_bias_example()
```

## 4. Custo-Benefício: XAI vs Governança

### 4.1 Análise de Custo

```python
def xai_vs_governance_cost_analysis():
    """
    Análise de custo real: implementação XAI vs governança.
    """
    
    # Custos XAI (estimativas baseadas em projetos reais)
    xai_costs = {
        'development_time_months': 6,
        'senior_developer_hourly_rate': 150,
        'senior_developer_hours_per_month': 160,
        'infrastructure_gpus_monthly': 5000,
        'maintenance_hours_monthly': 40,
        'maintenance_hourly_rate': 120,
        'legal_review_sessions': 10,
        'legal_hourly_rate': 300,
        'training_hours': 80,
        'training_hourly_rate': 100
    }
    
    # Cálculo custo XAI
    development_cost = (xai_costs['development_time_months'] * 
                       xai_costs['senior_developer_hours_per_month'] * 
                       xai_costs['senior_developer_hourly_rate'])
    
    infrastructure_cost = (xai_costs['infrastructure_gpus_monthly'] * 
                          xai_costs['development_time_months'])
    
    maintenance_cost = (xai_costs['maintenance_hours_monthly'] * 
                       xai_costs['maintenance_hourly_rate'] * 12)  # Anual
    
    legal_cost = (xai_costs['legal_review_sessions'] * 
                 xai_costs['legal_hourly_rate'])
    
    training_cost = (xai_costs['training_hours'] * 
                    xai_costs['training_hourly_rate'])
    
    total_xai_cost = (development_cost + infrastructure_cost + 
                     maintenance_cost + legal_cost + training_cost)
    
    # Custos Governança (implementação OpenBox)
    governance_costs = {
        'development_time_months': 1,
        'senior_developer_hourly_rate': 150,
        'senior_developer_hours_per_month': 160,
        'infrastructure_monthly': 500,
        'maintenance_hours_monthly': 10,
        'maintenance_hourly_rate': 120,
        'legal_review_sessions': 3,
        'legal_hourly_rate': 300,
        'training_hours': 20,
        'training_hourly_rate': 100
    }
    
    # Cálculo custo Governança
    gov_development_cost = (governance_costs['development_time_months'] * 
                           governance_costs['senior_developer_hours_per_month'] * 
                           governance_costs['senior_developer_hourly_rate'])
    
    gov_infrastructure_cost = (governance_costs['infrastructure_monthly'] * 
                             governance_costs['development_time_months'])
    
    gov_maintenance_cost = (governance_costs['maintenance_hours_monthly'] * 
                          governance_costs['maintenance_hourly_rate'] * 12)  # Anual
    
    gov_legal_cost = (governance_costs['legal_review_sessions'] * 
                     governance_costs['legal_hourly_rate'])
    
    gov_training_cost = (governance_costs['training_hours'] * 
                        governance_costs['training_hourly_rate'])
    
    total_governance_cost = (gov_development_cost + gov_infrastructure_cost + 
                           gov_maintenance_cost + gov_legal_cost + gov_training_cost)
    
    # Comparação
    cost_savings = total_xai_cost - total_governance_cost
    savings_percentage = (cost_savings / total_xai_cost) * 100
    
    # Visualização
    plt.figure(figsize=(12, 8))
    
    categories = ['Desenvolvimento', 'Infraestrutura', 'Manutenção', 'Legal', 'Treinamento']
    xai_values = [development_cost, infrastructure_cost, maintenance_cost, legal_cost, training_cost]
    governance_values = [gov_development_cost, gov_infrastructure_cost, gov_maintenance_cost, gov_legal_cost, gov_training_cost]
    
    x = np.arange(len(categories))
    width = 0.35
    
    plt.subplot(2, 2, 1)
    plt.bar(x - width/2, xai_values, width, label='XAI', color='red', alpha=0.7)
    plt.bar(x + width/2, governance_values, width, label='Governança', color='green', alpha=0.7)
    plt.xlabel('Categoria')
    plt.ylabel('Custo ($)')
    plt.title('Comparação de Custos por Categoria')
    plt.xticks(x, categories, rotation=45)
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # Gráfico de pizza
    plt.subplot(2, 2, 2)
    plt.pie([total_xai_cost, total_governance_cost], 
            labels=['XAI', 'Governança'], 
            autopct='%1.1f%%',
            colors=['red', 'green'],
            alpha=0.7)
    plt.title('Distribuição de Custos Totais')
    
    # Timeline
    plt.subplot(2, 2, 3)
    months = np.arange(1, 13)
    xai_monthly = np.full(12, total_xai_cost / 12)
    governance_monthly = np.full(12, total_governance_cost / 12)
    
    plt.plot(months, np.cumsum(xai_monthly), 'r-', label='XAI', linewidth=2)
    plt.plot(months, np.cumsum(governance_monthly), 'g-', label='Governança', linewidth=2)
    plt.xlabel('Mês')
    plt.ylabel('Custo Acumulado ($)')
    plt.title('Timeline de Custos')
    plt.legend()
    plt.grid(True, alpha=0.3)
    
    # ROI
    plt.subplot(2, 2, 4)
    roi_data = {
        'Custo': [total_xai_cost, total_governance_cost],
        'Valor Legal': [50000, 200000],  # Governança tem maior valor legal
        'Valor Operacional': [100000, 300000],  # Governança tem maior valor operacional
    }
    
    xai_total_value = roi_data['Valor Legal'][0] + roi_data['Valor Operacional'][0]
    governance_total_value = roi_data['Valor Legal'][1] + roi_data['Valor Operacional'][1]
    
    xai_roi = (xai_total_value - total_xai_cost) / total_xai_cost * 100
    governance_roi = (governance_total_value - total_governance_cost) / total_governance_cost * 100
    
    plt.bar(['XAI', 'Governança'], [xai_roi, governance_roi], 
            color=['red', 'green'], alpha=0.7)
    plt.ylabel('ROI (%)')
    plt.title('Retorno sobre Investimento')
    plt.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.show()
    
    # Resultados
    print("=== ANÁLISE CUSTO-BENEFÍCIO ===")
    print(f"\nCUSTO TOTAL XAI: ${total_xai_cost:,.0f}")
    print(f"CUSTO TOTAL Governança: ${total_governance_cost:,.0f}")
    print(f"Economia com Governança: ${cost_savings:,.0f} ({savings_percentage:.1f}%)")
    
    print(f"\nROI XAI: {xai_roi:.1f}%")
    print(f"ROI Governança: {governance_roi:.1f}%")
    
    print("\n=== DESAGREGAÇÃO DE CUSTOS ===")
    print("\nXAI:")
    print(f"  - Desenvolvimento: ${development_cost:,.0f}")
    print(f"  - Infraestrutura: ${infrastructure_cost:,.0f}")
    print(f"  - Manutenção: ${maintenance_cost:,.0f}")
    print(f"  - Legal: ${legal_cost:,.0f}")
    print(f"  - Treinamento: ${training_cost:,.0f}")
    
    print("\nGovernança:")
    print(f"  - Desenvolvimento: ${gov_development_cost:,.0f}")
    print(f"  - Infraestrutura: ${gov_infrastructure_cost:,.0f}")
    print(f"  - Manutenção: ${gov_maintenance_cost:,.0f}")
    print(f"  - Legal: ${gov_legal_cost:,.0f}")
    print(f"  - Treinamento: ${gov_training_cost:,.0f}")
    
    return {
        'xai_cost': total_xai_cost,
        'governance_cost': total_governance_cost,
        'savings': cost_savings,
        'savings_percentage': savings_percentage,
        'xai_roi': xai_roi,
        'governance_roi': governance_roi
    }

# Executar análise
cost_analysis = xai_vs_governance_cost_analysis()
```

### 4.2 Valor Legal e Operacional

```python
def legal_operational_value_analysis():
    """
    Analisa valor legal e operacional de XAI vs governança.
    """
    
    # Cenários de auditoria/regulação
    scenarios = [
        {
            'name': 'Auditoria GDPR',
            'xai_evidence_strength': 0.3,  # Explicações são frágeis legalmente
            'governance_evidence_strength': 0.9,  # Ledger + métricas são fortes
            'probability': 0.1
        },
        {
            'name': 'Processo Judicial',
            'xai_evidence_strength': 0.2,  # SHAP values não são evidência legal
            'governance_evidence_strength': 0.8,  # Ledger imutável é evidência
            'probability': 0.05
        },
        {
            'name': 'Inspeção Regulatória',
            'xai_evidence_strength': 0.4,  # Ajuda, mas insuficiente
            'governance_evidence_strength': 0.95,  # Governança completa
            'probability': 0.2
        },
        {
            'name': 'Auditoria Interna',
            'xai_evidence_strength': 0.6,  # Útil para entendimento
            'governance_evidence_strength': 0.9,  # Controle operacional
            'probability': 0.5
        }
    ]
    
    # Valor esperado de evidências
    xai_expected_value = sum(
        scenario['probability'] * scenario['xai_evidence_strength'] * 100000
        for scenario in scenarios
    )
    
    governance_expected_value = sum(
        scenario['probability'] * scenario['governance_evidence_strength'] * 100000
        for scenario in scenarios
    )
    
    print("=== VALOR LEGAL E OPERACIONAL ===")
    print(f"\nValor Esperado de Evidências XAI: ${xai_expected_value:,.0f}")
    print(f"Valor Esperado de Evidências Governança: ${governance_expected_value:,.0f}")
    
    print("\nDetalhamento por Cenário:")
    for scenario in scenarios:
        xai_value = scenario['probability'] * scenario['xai_evidence_strength'] * 100000
        governance_value = scenario['probability'] * scenario['governance_evidence_strength'] * 100000
        
        print(f"\n{scenario['name']}:")
        print(f"  - XAI: ${xai_value:,.0f} (força: {scenario['xai_evidence_strength']:.1f})")
        print(f"  - Governança: ${governance_value:,.0f} (força: {scenario['governance_evidence_strength']:.1f})")
        print(f"  - Vantagem Governança: ${governance_value - xai_value:,.0f}")
    
    return {
        'xai_expected_value': xai_expected_value,
        'governance_expected_value': governance_expected_value,
        'value_advantage': governance_expected_value - xai_expected_value
    }

value_analysis = legal_operational_value_analysis()
```

## 5. Conclusões e Recomendações

### 5.1 Limitações Críticas do XAI

```python
def summarize_xai_limitations():
    """
    Resume limitações críticas do XAI para governança.
    """
    
    limitations = {
        'Instabilidade': {
            'problema': 'Explicações mudam dramaticamente com perturbações mínimas',
            'impacto': 'Impossível confiar em explicações em produção',
            'governanca_alternativa': 'CVaR + testes metamórficos (estáveis)',
            'criticidade': 'ALTA'
        },
        'Fidelidade Global': {
            'problema': 'Explicações locais não representam comportamento global',
            'impacto': 'Insights locais não são generalizáveis',
            'governanca_alternativa': 'Métricas globais + benchmarks',
            'criticidade': 'ALTA'
        },
        'Correlação vs Causalidade': {
            'problema': 'XAI identifica correlação, não causalidade',
            'impacto': 'Não pode distinguir features relevantes de espúrias',
            'governanca_alternativa': 'Testes de causalidade + controles',
            'criticidade': 'CRÍTICA'
        },
        'Custo Elevado': {
            'problema': 'Implementação XAI é cara e complexa',
            'impacto': 'ROI questionável para governança',
            'governanca_alternativa': 'Governança operacional é 6x mais barata',
            'criticidade': 'ALTA'
        },
        'Valor Legal Baixo': {
            'problema': 'Explicações SHAP/LIME não são evidência legal forte',
            'impacto': 'Insuficiente para auditorias/regulação',
            'governanca_alternativa': 'Ledger imutável + métricas objetivas',
            'criticidade': 'CRÍTICA'
        }
    }
    
    print("=== LIMITAÇÕES CRÍTICAS DO XAI ===")
    
    for limitation, details in limitations.items():
        print(f"\n🚨 {limitation.upper()} ({details['criticidade']})")
        print(f"   Problema: {details['problema']}")
        print(f"   Impacto: {details['impacto']}")
        print(f"   Alternativa Governança: {details['governanca_alternativa']}")
    
    # Pontuação geral
    critical_count = sum(1 for details in limitations.values() if details['criticidade'] == 'CRÍTICA')
    high_count = sum(1 for details in limitations.values() if details['criticidade'] == 'ALTA')
    
    print(f"\n=== AVALIAÇÃO GERAL ===")
    print(f"Limitações críticas: {critical_count}/5")
    print(f"Limitações altas: {high_count}/5")
    
    if critical_count >= 2:
        print("⚠️  XAI É INADEQUADO PARA GOVERNANÇA")
        print("   Múltiplas limitações críticas impedem uso operacional")
    elif high_count >= 3:
        print("⚠️  XAI TEM LIMITAÇÕES SIGNIFICATIVAS")
        print("   Adequado para research, inadequado para produção")
    else:
        print("✓ XAI tem limitações manejáveis")

summarize_xai_limitations()
```

### 5.2 Recomendações Práticas

```python
def practical_recommendations():
    """
    Recomendações práticas para替换 XAI por governança.
    """
    
    recommendations = {
        'Para Desenvolvedores': [
            'Parem de perseguir explicabilidade perfeita',
            'Implementem CVaR para monitoramento de risco',
            'Usem testes metamórficos para robustez',
            'Criem ledger imutável para auditoria',
            'Foquem em controle operacional'
        ],
        'Para Gestores': [
            'Exijam métricas de governança, não explicações',
            'Avaliem ROI real de projetos XAI',
            'Priorizem evidência legal sobre compreensão',
            'Implementem controles automáticos',
            'Auditem decisões, não interpretações'
        ],
        'Para Reguladores': [
            'Definam requisitos de governança operacional',
            'Aceitem evidências de controle sem explicação',
            'Concentrem-se em outcomes mensuráveis',
            'Exijam trilhas de auditoria imutáveis',
            'Validem robustez comportamental'
        ],
        'Para Pesquisadores': [
            'Desenvolvam métricas de governança robustas',
            'Pesquisem testes metamórficos avançados',
            'Criem benchmarks de controle operacional',
            'Investiguem CVaR dinâmico',
            'Explorem integração blockchain'
        ]
    }
    
    print("=== RECOMENDAÇÕES PRÁTICAS ===")
    
    for audience, recs in recommendations.items():
        print(f"\n👥 {audience}:")
        for i, rec in enumerate(recs, 1):
            print(f"   {i}. {rec}")
    
    print("\n=== ROADMAP DE IMPLEMENTAÇÃO ===")
    roadmap = [
        'Fase 1: Implementar monitoramento CVaR',
        'Fase 2: Adicionar testes metamórficos',
        'Fase 3: Criar ledger imutável',
        'Fase 4: Implementar Ω-GATE',
        'Fase 5: Integrar com blockchain (PoSE/PoLE)'
    ]
    
    for i, phase in enumerate(roadmap, 1):
        print(f"   {i}. {phase}")

practical_recommendations()
```

## 6. Exercícios Práticos

### Exercício 1: Teste de Estabilidade

```python
def exercise_stability_test():
    """
    Exercício: Implemente teste de estabilidade para seu modelo.
    """
    
    print("=== EXERCÍCIO 1: TESTE DE ESTABILIDADE ===")
    print()
    print("Objetivo: Medir quão estáveis são as explicações do seu modelo")
    print()
    print("Passos:")
    print("1. Treine um modelo em seus dados")
    print("2. Escolha 10 instâncias para teste")
    print("3. Para cada instância:")
    print("   - Gere explicação SHAP")
    print("   - Aplique 50 perturbações com ruído mínimo")
    print("   - Calcule distância média das explicações")
    print("4. Calcule estabilidade média")
    print("5. Avalie se explicações são úteis para governança")
    print()
    print("Critérios de Avaliação:")
    print("- Estabilidade > 0.8: Aceitável")
    print("- Estabilidade 0.5-0.8: Questionável")
    print("- Estabilidade < 0.5: Inaceitável")
    print()
    print("Template de código:")
    print("""
def test_model_stability(model, X_test, noise_level=0.001):
    # Seu código aqui
    pass

# Avalie seu modelo
stability_score = test_model_stability(your_model, your_test_data)
print(f"Estabilidade: {stability_score:.3f}")
""")

exercise_stability_test()
```

### Exercício 2: Comparação de Fidelidade

```python
def exercise_fidelity_comparison():
    """
    Exercício: Compare fidelidade local vs global do seu modelo.
    """
    
    print("=== EXERCÍCIO 2: COMPARAÇÃO DE FIDELIDADE ===")
    print()
    print("Objetivo: Verificar se explicações locais representam comportamento global")
    print()
    print("Passos:")
    print("1. Calcule SHAP para 100 instâncias")
    print("2. Calcule importância média local")
    print("3. Calcule importância global (permutation importance)")
    print("4. Compare correlações")
    print("5. Avalie se local representa global")
    print()
    print("Template de código:")
    print("""
def check_local_global_fidelity(model, X_test, y_test):
    # Seu código aqui
    pass

# Avalie seu modelo
fidelity_score = check_local_global_fidelity(your_model, your_test_data, your_labels)
print(f"Fidelidade: {fidelity_score:.3f}")
""")

exercise_fidelity_comparison()
```

## 7. Resumo

### Pontos-Chave

1. **Explicações são instáveis** - Mudam dramaticamente com perturbações mínimas
2. **Fidelidade global é baixa** - Explicações locais não representam comportamento global
3. **Correlação ≠ Causalidade** - XAI identifica correlação, não causa
4. **Custo elevado** - XAI é 6x mais caro que governança
5. **Valor legal baixo** - SHAP/LIME não são evidência legal forte

### Implicações

- **XAI é inadequado para governança operacional**
- **Governança baseada em controle é mais eficaz**
- **Evidência imutável tem maior valor legal**
- **ROI de governança supera XAI significativamente**

### Próximos Passos

- **Tutorial 3**: [Governança Operacional](./03_operational_governance.md)
- **Tutorial 4**: [Tail Risk e CVaR](./04_tail_risk_cvar.md)

### Recursos

- [WHY_NOT_XAI.md](../WHY_NOT_XAI.md) - Análise completa
- [openbox/omega_min/](../openbox/omega_min/) - Implementação de governança
- [examples/](../examples/) - Casos práticos

---

**Lembre-se**: Explicabilidade é útil para pesquisa, governança é essencial para produção.