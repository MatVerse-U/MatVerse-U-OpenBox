# Tutorial 3: Governança Operacional

**Implementação prática de sistemas de governança para IA sem dependência de explicabilidade.**

---

## Objetivos de Aprendizagem

Após este tutorial, você será capaz de:

1. **Implementar** CVaR (Conditional Value at Risk) para monitoramento de risco
2. **Aplicar** testes metamórficos para robustez comportamental
3. **Configurar** UMJAM para controle dinâmico externo
4. **Criar** ledger imutável para evidência de auditoria
5. **Integrar** todos os componentes em sistema completo de governança

## 1. Arquitetura de Governança Operacional

### 1.1 Visão Geral

```python
"""
Arquitetura de Governança Operacional OpenBox

Componentes principais:
1. Observabilidade: Coleta de métricas em tempo real
2. Controle: CVaR + Testes Metamórficos + UMJAM
3. Evidência: Ledger imutável + blockchain (PoSE/PoLE)
4. Decisão: Ω-GATE para aprovação/degradação/bloqueio
"""

class OperationalGovernance:
    """
    Sistema completo de governança operacional para IA.
    
    Filosifia: Controlar sem explicar, evidenciar sem interpretar.
    """
    
    def __init__(self, config: GovernanceConfig):
        self.config = config
        self.setup_layers()
    
    def setup_layers(self):
        """Inicializa as 3 camadas de governança."""
        
        # Camada 1: Observabilidade
        self.observability = ObservabilityLayer(self.config.observability)
        
        # Camada 2: Controle
        self.control = ControlLayer(self.config.control)
        
        # Camada 3: Evidência
        self.evidence = EvidenceLayer(self.config.evidence)
        
        # Ω-GATE: Sistema de decisões
        self.omega_gate = OmegaGate(self.config.omega)
    
    def evaluate_system(self, model, X, y, metadata=None):
        """
        Avalia sistema completo usando governança operacional.
        
        Returns:
            Dict com decisão, métricas, evidências
        """
        
        # 1. Observabilidade: Coleta métricas
        observations = self.observability.collect(model, X, y)
        
        # 2. Controle: Aplica governança
        controls = self.control.apply(model, X, y, observations)
        
        # 3. Evidência: Registra tudo
        evidence = self.evidence.record(observations, controls, metadata)
        
        # 4. Decisão: Ω-GATE
        decision = self.omega_gate.decide(controls)
        
        return {
            'decision': decision,
            'observations': observations,
            'controls': controls,
            'evidence': evidence,
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
```

### 1.2 Configuração Completa

```python
from dataclasses import dataclass
from typing import Dict, List, Any
import numpy as np

@dataclass
class GovernanceConfig:
    """Configuração completa do sistema de governança."""
    
    # === OBSERVABILIDADE ===
    observability: Dict[str, Any] = None
    
    # === CONTROLE ===
    control: Dict[str, Any] = None
    
    # === EVIDÊNCIA ===
    evidence: Dict[str, Any] = None
    
    # === Ω-GATE ===
    omega: Dict[str, Any] = None
    
    def __post_init__(self):
        """Inicializa configurações padrão se não fornecidas."""
        
        if self.observability is None:
            self.observability = {
                'latency_threshold_ms': 100.0,
                'error_rate_threshold': 0.05,
                'drift_threshold': 0.1,
                'accuracy_threshold': 0.85
            }
        
        if self.control is None:
            self.control = {
                'cvar': {
                    'alpha': 0.95,
                    'max_allow': 0.20,
                    'max_degrade': 0.25
                },
                'metamorphic': {
                    'transformations': 4,
                    'tolerance': 0.1,
                    'max_violations_allow': 0.05,
                    'max_violations_degrade': 0.10
                },
                'umjam': {
                    'target': 0.05,
                    'convergence_rate': 0.1,
                    'max_iterations': 10
                }
            }
        
        if self.evidence is None:
            self.evidence = {
                'ledger_path': 'governance_ledger.jsonl',
                'hash_algorithm': 'sha3_256',
                'backup_enabled': True,
                'blockchain_enabled': False  # Opcional
            }
        
        if self.omega is None:
            self.omega = {
                'weights': {
                    'cvar': 0.4,
                    'metamorphic_violations': 0.3,
                    'latency_p95': 0.2,
                    'drift_score': 0.1
                },
                'thresholds': {
                    'allow': 0.8,
                    'degrade': 0.6,
                    'block': 0.0
                }
            }

# Configuração padrão
default_config = GovernanceConfig()
print("Configuração padrão criada com sucesso!")
```

## 2. Camada de Observabilidade

### 2.1 Coleta de Métricas

```python
import time
import psutil
from typing import Dict, List, Any
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score

class ObservabilityLayer:
    """
    Camada de observabilidade para monitoramento em tempo real.
    
    Responsabilidades:
    - Medir performance (latência, accuracy, erro)
    - Monitorar recursos (memória, CPU)
    - Detectar deriva de dados
    - Coletar telemetria operacional
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.reference_data = None
        self.reference_stats = {}
    
    def collect(self, model, X, y) -> Dict[str, Any]:
        """Coleta observações completas do sistema."""
        
        # Métricas de performance
        performance = self._measure_performance(model, X, y)
        
        # Métricas de recursos
        resources = self._measure_resources()
        
        # Detecção de deriva
        drift = self._detect_drift(X)
        
        # Telemetria operacional
        telemetry = self._collect_telemetry()
        
        return {
            'performance': performance,
            'resources': resources,
            'drift': drift,
            'telemetry': telemetry,
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
    
    def _measure_performance(self, model, X, y) -> Dict[str, float]:
        """Mede performance do modelo."""
        
        # Tempo de predição
        start_time = time.time()
        predictions = model.predict(X)
        inference_time = time.time() - start_time
        
        # Métricas de qualidade
        accuracy = accuracy_score(y, predictions)
        precision = precision_score(y, predictions, average='weighted', zero_division=0)
        recall = recall_score(y, predictions, average='weighted', zero_division=0)
        
        # Latência percentis
        latencies = []
        for i in range(min(100, len(X))):
            start = time.time()
            model.predict(X[i:i+1])
            latencies.append(time.time() - start)
        
        latency_p50 = np.percentile(latencies, 50)
        latency_p95 = np.percentile(latencies, 95)
        latency_p99 = np.percentile(latencies, 99)
        
        return {
            'accuracy': accuracy,
            'precision': precision,
            'recall': recall,
            'inference_time': inference_time,
            'latency_p50': latency_p50 * 1000,  # ms
            'latency_p95': latency_p95 * 1000,  # ms
            'latency_p99': latency_p99 * 1000,  # ms
            'throughput': len(X) / inference_time  # samples/second
        }
    
    def _measure_resources(self) -> Dict[str, float]:
        """Mede uso de recursos do sistema."""
        
        process = psutil.Process()
        
        return {
            'memory_usage_mb': process.memory_info().rss / 1024 / 1024,
            'cpu_percent': process.cpu_percent(),
            'memory_percent': process.memory_percent(),
            'disk_usage_percent': psutil.disk_usage('/').percent
        }
    
    def _detect_drift(self, X) -> Dict[str, Any]:
        """Detecta deriva de dados."""
        
        if self.reference_data is None:
            # Primeira execução: armazena dados como referência
            self.reference_data = X
            self.reference_stats = self._compute_data_statistics(X)
            return {'status': 'reference_established', 'score': 0.0}
        
        # Compara com referência
        current_stats = self._compute_data_statistics(X)
        drift_score = self._compute_drift_score(self.reference_stats, current_stats)
        
        # Status baseado no threshold
        threshold = self.config.get('drift_threshold', 0.1)
        if drift_score <= threshold:
            status = 'normal'
        elif drift_score <= threshold * 1.5:
            status = 'warning'
        else:
            status = 'critical'
        
        return {
            'status': status,
            'score': drift_score,
            'threshold': threshold,
            'reference_established': True
        }
    
    def _compute_data_statistics(self, X) -> Dict[str, Any]:
        """Computa estatísticas dos dados."""
        
        return {
            'mean': np.mean(X, axis=0),
            'std': np.std(X, axis=0),
            'min': np.min(X, axis=0),
            'max': np.max(X, axis=0),
            'shape': X.shape
        }
    
    def _compute_drift_score(self, ref_stats, current_stats) -> float:
        """Computa score de deriva usando distribuição."""
        
        # Driftscore baseado na distância entre distribuições
        mean_distance = np.linalg.norm(current_stats['mean'] - ref_stats['mean'])
        std_distance = np.linalg.norm(current_stats['std'] - ref_stats['std'])
        
        # Normaliza pelo número de features
        n_features = len(ref_stats['mean'])
        drift_score = (mean_distance + std_distance) / (2 * n_features)
        
        return drift_score
    
    def _collect_telemetry(self) -> Dict[str, Any]:
        """Coleta telemetria operacional."""
        
        return {
            'system_time': datetime.now(timezone.utc).isoformat(),
            'python_version': sys.version.split()[0],
            'platform': sys.platform,
            'available_memory_gb': psutil.virtual_memory().available / 1024**3,
            'cpu_count': psutil.cpu_count()
        }

# Teste da camada de observabilidade
def test_observability():
    """Testa a camada de observabilidade."""
    
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.datasets import make_classification
    
    # Gerar dados de teste
    X, y = make_classification(n_samples=1000, n_features=10, random_state=42)
    
    # Treinar modelo
    model = RandomForestClassifier(random_state=42)
    model.fit(X, y)
    
    # Configurar observabilidade
    obs_config = {'drift_threshold': 0.1}
    observability = ObservabilityLayer(obs_config)
    
    # Coletar observações
    observations = observability.collect(model, X, y)
    
    print("=== TESTE DA CAMADA DE OBSERVABILIDADE ===")
    print(f"Accuracy: {observations['performance']['accuracy']:.3f}")
    print(f"Latência p95: {observations['performance']['latency_p95']:.2f}ms")
    print(f"Memória: {observations['resources']['memory_usage_mb']:.1f}MB")
    print(f"Deriva: {observations['drift']['score']:.4f} ({observations['drift']['status']})")
    
    return observations

# Executar teste
test_obs = test_observability()
```

### 2.2 Monitoramento em Tempo Real

```python
import threading
import queue
from datetime import datetime, timedelta

class RealTimeMonitor:
    """
    Monitoramento em tempo real com alertas automáticos.
    """
    
    def __init__(self, governance_system, alert_callback=None):
        self.governance_system = governance_system
        self.alert_callback = alert_callback
        self.monitoring = False
        self.data_queue = queue.Queue()
        self.alert_history = []
    
    def start_monitoring(self, data_stream, interval_seconds=60):
        """Inicia monitoramento contínuo."""
        
        self.monitoring = True
        
        def monitor_loop():
            while self.monitoring:
                try:
                    # Obter batch de dados
                    batch_data = data_stream.get_batch(interval_seconds)
                    
                    if batch_data is not None:
                        # Avaliar sistema
                        result = self.governance_system.evaluate_system(
                            batch_data['model'], 
                            batch_data['X'], 
                            batch_data['y']
                        )
                        
                        # Verificar alertas
                        self._check_alerts(result)
                        
                        # Armazenar resultado
                        self.data_queue.put(result)
                
                except Exception as e:
                    print(f"Erro no monitoramento: {e}")
                
                time.sleep(interval_seconds)
        
        # Iniciar thread de monitoramento
        self.monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
        self.monitor_thread.start()
        
        print(f"Monitoramento iniciado (intervalo: {interval_seconds}s)")
    
    def stop_monitoring(self):
        """Para o monitoramento."""
        
        self.monitoring = False
        if hasattr(self, 'monitor_thread'):
            self.monitor_thread.join(timeout=5)
        
        print("Monitoramento parado")
    
    def _check_alerts(self, governance_result):
        """Verifica condições de alerta."""
        
        decision = governance_result['decision']
        controls = governance_result['controls']
        
        # Alertas críticos
        if decision['action'] == 'BLOCK':
            alert = {
                'type': 'CRITICAL',
                'message': f"Sistema bloqueado! Ω-score: {decision['omega_score']:.3f}",
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'details': decision['justification']
            }
            self._trigger_alert(alert)
        
        # Alertas de degradação
        elif decision['action'] == 'DEGRADE':
            alert = {
                'type': 'WARNING',
                'message': f"Sistema degradado. Ω-score: {decision['omega_score']:.3f}",
                'timestamp': datetime.now(timezone.utc).isoformat(),
                'details': decision['justification']
            }
            self._trigger_alert(alert)
        
        # Alertas de métricas específicas
        if controls.get('cvar', 0) > 0.25:
            alert = {
                'type': 'WARNING',
                'message': f"CVaR alto: {controls['cvar']:.3f}",
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
            self._trigger_alert(alert)
        
        if controls.get('metamorphic_violations', 0) > 0.10:
            alert = {
                'type': 'WARNING',
                'message': f"Violações metamórficas altas: {controls['metamorphic_violations']:.3f}",
                'timestamp': datetime.now(timezone.utc).isoformat()
            }
            self._trigger_alert(alert)
    
    def _trigger_alert(self, alert):
        """Dispara alerta."""
        
        self.alert_history.append(alert)
        
        # Chamar callback personalizado
        if self.alert_callback:
            self.alert_callback(alert)
        
        # Log do alerta
        print(f"🚨 ALERTA {alert['type']}: {alert['message']}")
    
    def get_recent_alerts(self, hours=24) -> List[Dict]:
        """Obtém alertas recentes."""
        
        cutoff_time = datetime.now(timezone.utc) - timedelta(hours=hours)
        
        recent_alerts = [
            alert for alert in self.alert_history
            if datetime.fromisoformat(alert['timestamp']) > cutoff_time
        ]
        
        return recent_alerts
    
    def get_monitoring_stats(self) -> Dict:
        """Obtém estatísticas do monitoramento."""
        
        total_evaluations = self.data_queue.qsize()
        recent_alerts = self.get_recent_alerts()
        
        alert_counts = {}
        for alert in recent_alerts:
            alert_type = alert['type']
            alert_counts[alert_type] = alert_counts.get(alert_type, 0) + 1
        
        return {
            'total_evaluations': total_evaluations,
            'recent_alerts': len(recent_alerts),
            'alert_counts': alert_counts,
            'monitoring_active': self.monitoring
        }

# Exemplo de uso do monitoramento em tempo real
def example_realtime_monitoring():
    """Exemplo de monitoramento em tempo real."""
    
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.datasets import make_classification
    
    # Configurar sistema de governança
    config = GovernanceConfig()
    governance = OperationalGovernance(config)
    
    # Callback para alertas
    def alert_handler(alert):
        print(f"ALERTA RECEBIDO: {alert['message']}")
        # Aqui você pode integrar com sistemas de notificação
        # (email, Slack, PagerDuty, etc.)
    
    # Iniciar monitoramento
    monitor = RealTimeMonitor(governance, alert_handler)
    
    # Simular stream de dados
    class MockDataStream:
        def __init__(self):
            self.model = RandomForestClassifier(random_state=42)
            X, y = make_classification(n_samples=1000, n_features=10, random_state=42)
            self.model.fit(X, y)
            
            # Dados para simulação
            self.data_batches = []
            for i in range(10):
                X_batch, y_batch = make_classification(
                    n_samples=100, n_features=10, random_state=42+i
                )
                self.data_batches.append({'X': X_batch, 'y': y_batch})
            
            self.batch_index = 0
        
        def get_batch(self, interval_seconds):
            """Simula obter batch de dados."""
            if self.batch_index < len(self.data_batches):
                batch = self.data_batches[self.batch_index].copy()
                batch['model'] = self.model
                self.batch_index += 1
                return batch
            return None
    
    data_stream = MockDataStream()
    
    # Iniciar monitoramento (10 segundos de intervalo)
    monitor.start_monitoring(data_stream, interval_seconds=10)
    
    print("Monitoramento ativo. Aguardando dados...")
    
    # Aguardar um pouco para demonstração
    time.sleep(15)
    
    # Parar monitoramento
    monitor.stop_monitoring()
    
    # Estatísticas
    stats = monitor.get_monitoring_stats()
    print(f"\n=== ESTATÍSTICAS DO MONITORAMENTO ===")
    print(f"Total de avaliações: {stats['total_evaluations']}")
    print(f"Alertas recentes: {stats['recent_alerts']}")
    print(f"Tipos de alerta: {stats['alert_counts']}")

# Executar exemplo
example_realtime_monitoring()
```

## 3. Camada de Controle

### 3.1 CVaR (Conditional Value at Risk)

```python
class CVaRController:
    """
    Controlador CVaR para monitoramento de risco de cauda.
    
    CVaR mede a perda esperada no pior α% dos casos.
    Essencial para governança porque quantifica risco extremo.
    """
    
    def __init__(self, alpha=0.95, max_allow=0.20, max_degrade=0.25):
        self.alpha = alpha
        self.max_allow = max_allow
        self.max_degrade = max_degrade
        
        # Histórico de CVaR para trending
        self.cvar_history = []
        self.decision_history = []
    
    def compute_cvar(self, losses: np.ndarray) -> float:
        """
        Calcula CVaR (Expected Shortfall) para perdas.
        
        Args:
            losses: Array de perdas (maior = pior)
        
        Returns:
            CVaR alpha (Expected Shortfall)
        """
        if len(losses) == 0:
            return 0.0
        
        # Ordenar perdas
        sorted_losses = np.sort(losses)
        
        # Índice do VaR (percentil alpha)
        var_index = int(self.alpha * len(sorted_losses))
        
        # CVaR = média das perdas no pior α%
        if var_index < len(sorted_losses):
            cvar_value = np.mean(sorted_losses[var_index:])
        else:
            cvar_value = sorted_losses[-1] if len(sorted_losses) > 0 else 0.0
        
        return cvar_value
    
    def evaluate(self, model, X, y) -> Dict[str, Any]:
        """
        Avalia sistema usando CVaR.
        
        Args:
            model: Modelo a ser avaliado
            X: Features
            y: Labels verdadeiros
        
        Returns:
            Dict com decisão CVaR e valor
        """
        
        # Fazer predições
        predictions = model.predict(X)
        
        # Calcular perdas (exemplo: erro de classificação)
        losses = self._compute_losses(predictions, y)
        
        # Calcular CVaR
        cvar_value = self.compute_cvar(losses)
        
        # Decisão baseada em thresholds
        if cvar_value <= self.max_allow:
            decision = "ALLOW"
        elif cvar_value <= self.max_degrade:
            decision = "DEGRADE"
        else:
            decision = "BLOCK"
        
        # Armazenar histórico
        self.cvar_history.append(cvar_value)
        self.decision_history.append(decision)
        
        # Manter apenas últimos 1000 valores
        if len(self.cvar_history) > 1000:
            self.cvar_history = self.cvar_history[-1000:]
            self.decision_history = self.decision_history[-1000:]
        
        # Análise de trending
        trending = self._analyze_trending()
        
        return {
            'cvar': cvar_value,
            'decision': decision,
            'alpha': self.alpha,
            'threshold_allow': self.max_allow,
            'threshold_degrade': self.max_degrade,
            'trending': trending,
            'statistics': {
                'mean_cvar': np.mean(self.cvar_history[-100:]),
                'std_cvar': np.std(self.cvar_history[-100:]),
                'recent_decisions': self._get_decision_distribution()
            }
        }
    
    def _compute_losses(self, predictions, y_true) -> np.ndarray:
        """
        Computa perdas baseadas no problema específico.
        
        Pode ser customizado para diferentes domínios:
        - Classificação: erro binário/categórico
        - Regressão: erro absoluto/quadrático
        - Ranking: precisão/inverted rank
        """
        
        # Exemplo: perda binária (0/1)
        losses = (predictions != y_true).astype(float)
        
        # Exemplo: perda ponderada por confiança
        # predictions_proba = model.predict_proba(X)
        # max_proba = np.max(predictions_proba, axis=1)
        # losses = (predictions != y_true) * (1 - max_proba)
        
        return losses
    
    def _analyze_trending(self) -> Dict[str, Any]:
        """Analisa trending do CVaR."""
        
        if len(self.cvar_history) < 10:
            return {'status': 'insufficient_data'}
        
        recent_values = np.array(self.cvar_history[-20:])
        
        # Tendência linear
        x = np.arange(len(recent_values))
        slope = np.polyfit(x, recent_values, 1)[0]
        
        # Volatilidade
        volatility = np.std(recent_values)
        
        # Classificar tendência
        if slope > 0.01 and volatility < 0.05:
            trend = 'improving'
        elif slope < -0.01 and volatility < 0.05:
            trend = 'deteriorating'
        elif volatility > 0.1:
            trend = 'volatile'
        else:
            trend = 'stable'
        
        return {
            'trend': trend,
            'slope': slope,
            'volatility': volatility,
            'direction': 'increasing' if slope > 0 else 'decreasing'
        }
    
    def _get_decision_distribution(self) -> Dict[str, float]:
        """Obtém distribuição de decisões recentes."""
        
        recent_decisions = self.decision_history[-50:]
        
        if not recent_decisions:
            return {}
        
        total = len(recent_decisions)
        distribution = {
            'ALLOW': recent_decisions.count('ALLOW') / total,
            'DEGRADE': recent_decisions.count('DEGRADE') / total,
            'BLOCK': recent_decisions.count('BLOCK') / total
        }
        
        return distribution
    
    def visualize_cvar(self, save_path=None):
        """Visualiza histórico de CVaR."""
        
        if len(self.cvar_history) < 10:
            print("Dados insuficientes para visualização")
            return
        
        plt.figure(figsize=(12, 8))
        
        # Subplot 1: CVaR ao longo do tempo
        plt.subplot(2, 2, 1)
        plt.plot(self.cvar_history, 'b-', alpha=0.7, label='CVaR')
        plt.axhline(y=self.max_allow, color='g', linestyle='--', label='Allow Threshold')
        plt.axhline(y=self.max_degrade, color='orange', linestyle='--', label='Degrade Threshold')
        plt.xlabel('Avaliação')
        plt.ylabel('CVaR')
        plt.title('CVaR ao Longo do Tempo')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Subplot 2: Distribuição de decisões
        plt.subplot(2, 2, 2)
        decisions = self._get_decision_distribution()
        if decisions:
            plt.pie(decisions.values(), labels=decisions.keys(), autopct='%1.1f%%')
            plt.title('Distribuição de Decisões (Últimas 50)')
        
        # Subplot 3: Histograma de CVaR
        plt.subplot(2, 2, 3)
        plt.hist(self.cvar_history[-100:], bins=20, alpha=0.7, edgecolor='black')
        plt.axvline(x=self.max_allow, color='g', linestyle='--', label='Allow')
        plt.axvline(x=self.max_degrade, color='orange', linestyle='--', label='Degrade')
        plt.xlabel('CVaR')
        plt.ylabel('Frequência')
        plt.title('Distribuição de CVaR')
        plt.legend()
        
        # Subplot 4: Box plot por decisão
        plt.subplot(2, 2, 4)
        recent_data = list(zip(self.decision_history[-100:], self.cvar_history[-100:]))
        
        allow_cvars = [cvar for decision, cvar in recent_data if decision == 'ALLOW']
        degrade_cvars = [cvar for decision, cvar in recent_data if decision == 'DEGRADE']
        block_cvars = [cvar for decision, cvar in recent_data if decision == 'BLOCK']
        
        data_to_plot = [allow_cvars, degrade_cvars, block_cvars]
        labels = ['Allow', 'Degrade', 'Block']
        
        plt.boxplot(data_to_plot, labels=labels)
        plt.ylabel('CVaR')
        plt.title('CVaR por Decisão')
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            print(f"Gráfico salvo em: {save_path}")
        
        plt.show()

# Teste do CVaR Controller
def test_cvar_controller():
    """Testa o controlador CVaR."""
    
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.datasets import make_classification
    
    # Gerar dados com diferentes níveis de ruído
    X_clean, y_clean = make_classification(n_samples=500, n_features=5, noise=0.1, random_state=42)
    X_noisy, y_noisy = make_classification(n_samples=500, n_features=5, noise=0.5, random_state=42)
    
    # Treinar modelo
    model = RandomForestClassifier(random_state=42)
    model.fit(X_clean, y_clean)
    
    # Controlador CVaR
    cvar_controller = CVaRController(alpha=0.95, max_allow=0.20, max_degrade=0.25)
    
    # Testar com dados limpos
    print("=== TESTE COM DADOS LIMPOS ===")
    result_clean = cvar_controller.evaluate(model, X_clean, y_clean)
    print(f"CVaR: {result_clean['cvar']:.3f}")
    print(f"Decisão: {result_clean['decision']}")
    print(f"Tendência: {result_clean['trending']['trend']}")
    
    # Testar com dados ruidosos
    print("\n=== TESTE COM DADOS RUIDOSOS ===")
    result_noisy = cvar_controller.evaluate(model, X_noisy, y_noisy)
    print(f"CVaR: {result_noisy['cvar']:.3f}")
    print(f"Decisão: {result_noisy['decision']}")
    print(f"Tendência: {result_noisy['trending']['trend']}")
    
    # Visualizar resultados
    cvar_controller.visualize_cvar()
    
    return cvar_controller

# Executar teste
test_cvar = test_cvar_controller()
```

### 3.2 Testes Metamórficos

```python
class MetamorphicTestSuite:
    """
    Suite de testes metamórficos para robustez comportamental.
    
    Testes metamórficos verificam invariância sob transformações válidas
    sem conhecer a função interna do modelo.
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.tolerance = config.get('tolerance', 0.1)
        self.max_violations_allow = config.get('max_violations_allow', 0.05)
        self.max_violations_degrade = config.get('max_violations_degrade', 0.10)
        
        # Histórico de violações
        self.violation_history = []
        self.test_results_history = []
    
    def evaluate(self, model, X_test: np.ndarray, n_samples: int = 100) -> Dict[str, Any]:
        """
        Avalia robustez usando testes metamórficos.
        
        Args:
            model: Modelo a ser testado
            X_test: Dados de teste
            n_samples: Número de amostras para teste
        
        Returns:
            Dict com taxa de violação e detalhes
        """
        
        # Selecionar amostras para teste
        sample_indices = np.random.choice(len(X_test), min(n_samples, len(X_test)), replace=False)
        X_sample = X_test[sample_indices]
        
        # Predições originais
        original_predictions = model.predict(X_sample)
        
        # Definir transformações metamórficas
        transformations = self._define_transformations(X_sample)
        
        # Executar testes
        test_results = {}
        total_violations = 0
        total_tests = 0
        
        for test_name, transformation_func in transformations.items():
            try:
                # Aplicar transformação
                X_transformed = transformation_func(X_sample)
                
                # Fazer predições
                transformed_predictions = model.predict(X_transformed)
                
                # Verificar invariância
                violations = self._check_invariance(
                    original_predictions, 
                    transformed_predictions, 
                    test_name
                )
                
                violation_rate = len(violations) / len(original_predictions)
                
                test_results[test_name] = {
                    'violations': len(violations),
                    'violation_rate': violation_rate,
                    'status': 'PASS' if violation_rate <= self.tolerance else 'FAIL',
                    'violation_indices': violations[:10]  # Primeiros 10 para análise
                }
                
                total_violations += len(violations)
                total_tests += len(original_predictions)
                
            except Exception as e:
                print(f"Erro no teste {test_name}: {e}")
                test_results[test_name] = {
                    'error': str(e),
                    'status': 'ERROR'
                }
        
        # Taxa de violação global
        global_violation_rate = total_violations / total_tests if total_tests > 0 else 0
        
        # Decisão baseada em thresholds
        if global_violation_rate <= self.max_violations_allow:
            decision = "ALLOW"
        elif global_violation_rate <= self.max_violations_degrade:
            decision = "DEGRADE"
        else:
            decision = "BLOCK"
        
        # Armazenar histórico
        self.violation_history.append(global_violation_rate)
        self.test_results_history.append(test_results)
        
        return {
            'global_violation_rate': global_violation_rate,
            'decision': decision,
            'tolerance': self.tolerance,
            'test_results': test_results,
            'statistics': {
                'total_tests': total_tests,
                'total_violations': total_violations,
                'tests_passed': sum(1 for r in test_results.values() if r.get('status') == 'PASS'),
                'tests_failed': sum(1 for r in test_results.values() if r.get('status') == 'FAIL')
            }
        }
    
    def _define_transformations(self, X: np.ndarray) -> Dict[str, callable]:
        """
        Define transformações metamórficas válidas.
        
        Cada transformação deve preservar o significado semântico dos dados.
        """
        
        transformations = {}
        
        # 1. Ruído gaussiano mínimo
        noise_level = np.std(X) * 0.01  # 1% do desvio padrão
        transformations['gaussian_noise'] = lambda x: x + np.random.normal(0, noise_level, x.shape)
        
        # 2. Permutação de features (se features são independentes)
        n_features = X.shape[1]
        if n_features > 1:
            transformations['feature_permutation'] = lambda x: x[:, np.random.permutation(n_features)]
        
        # 3. Escalonamento pequeno (dentro de limites válidos)
        scale_factor = np.random.uniform(0.95, 1.05)
        transformations['small_scaling'] = lambda x: x * scale_factor
        
        # 4. Adição de offset pequeno
        offset = np.random.normal(0, np.std(X) * 0.01, X.shape[1])
        transformations['small_offset'] = lambda x: x + offset
        
        # 5. Rotação (para dados com simetria)
        if n_features >= 2:
            # Rotação 2D simples
            angle = np.random.uniform(-5, 5) * np.pi / 180  # ±5 graus
            rotation_matrix = np.array([
                [np.cos(angle), -np.sin(angle)],
                [np.sin(angle), np.cos(angle)]
            ])
            
            def rotate_2d(x):
                if x.shape[1] >= 2:
                    x_2d = x[:, :2]
                    x_2d_rotated = x_2d @ rotation_matrix.T
                    x_new = x.copy()
                    x_new[:, :2] = x_2d_rotated
                    return x_new
                return x
            
            transformations['small_rotation'] = rotate_2d
        
        return transformations
    
    def _check_invariance(self, original_preds, transformed_preds, test_name) -> List[int]:
        """
        Verifica invariância entre predições originais e transformadas.
        
        Retorna índices das predições que violaram a invariância.
        """
        
        violations = []
        
        # Para classificação
        if len(np.unique(original_preds)) <= 10:  # Assume classificação se poucas classes
            # Predições devem ser idênticas (tolerância para problemas numéricos)
            differences = np.abs(original_preds - transformed_preds)
            violation_mask = differences > self.tolerance
            violations = np.where(violation_mask)[0].tolist()
        
        else:  # Assume regressão
            # Predições devem ser similares (diferença relativa)
            relative_differences = np.abs(
                (original_preds - transformed_preds) / (np.abs(original_preds) + 1e-8)
            )
            violation_mask = relative_differences > self.tolerance
            violations = np.where(violation_mask)[0].tolist()
        
        return violations
    
    def analyze_violations(self, test_results: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analisa padrões de violação para insights.
        """
        
        violation_analysis = {
            'worst_test': None,
            'best_test': None,
            'most_common_violations': [],
            'patterns': []
        }
        
        # Encontrar melhor e pior teste
        test_violations = {
            name: result.get('violation_rate', 0)
            for name, result in test_results.items()
            if 'violation_rate' in result
        }
        
        if test_violations:
            worst_test = max(test_violations, key=test_violations.get)
            best_test = min(test_violations, key=test_violations.get)
            
            violation_analysis['worst_test'] = {
                'name': worst_test,
                'rate': test_violations[worst_test]
            }
            violation_analysis['best_test'] = {
                'name': best_test,
                'rate': test_violations[best_test]
            }
        
        # Padrões de violação
        if 'gaussian_noise' in test_violations:
            if test_violations['gaussian_noise'] > 0.1:
                violation_analysis['patterns'].append("Modelo sensível a ruído")
        
        if 'feature_permutation' in test_violations:
            if test_violations['feature_permutation'] > 0.05:
                violation_analysis['patterns'].append("Dependência inadequada de ordem de features")
        
        return violation_analysis
    
    def visualize_results(self, save_path=None):
        """Visualiza resultados dos testes metamórficos."""
        
        if not self.test_results_history:
            print("Dados insuficientes para visualização")
            return
        
        plt.figure(figsize=(15, 10))
        
        # Subplot 1: Taxa de violação ao longo do tempo
        plt.subplot(2, 3, 1)
        plt.plot(self.violation_history, 'r-', linewidth=2)
        plt.axhline(y=self.max_violations_allow, color='g', linestyle='--', label='Allow Threshold')
        plt.axhline(y=self.max_violations_degrade, color='orange', linestyle='--', label='Degrade Threshold')
        plt.xlabel('Avaliação')
        plt.ylabel('Taxa de Violação Global')
        plt.title('Robustez ao Longo do Tempo')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Subplot 2: Distribuição de resultados por teste
        plt.subplot(2, 3, 2)
        latest_results = self.test_results_history[-1]
        test_names = list(latest_results.keys())
        violation_rates = [latest_results[name].get('violation_rate', 0) for name in test_names]
        
        plt.barh(test_names, violation_rates, alpha=0.7)
        plt.axvline(x=self.tolerance, color='red', linestyle='--', label='Tolerância')
        plt.xlabel('Taxa de Violação')
        plt.title('Resultados por Teste (Mais Recente)')
        plt.legend()
        
        # Subplot 3: Status dos testes
        plt.subplot(2, 3, 3)
        statuses = [latest_results[name].get('status', 'ERROR') for name in test_names]
        status_counts = {}
        for status in statuses:
            status_counts[status] = status_counts.get(status, 0) + 1
        
        if status_counts:
            plt.pie(status_counts.values(), labels=status_counts.keys(), autopct='%1.0f')
            plt.title('Status dos Testes (Mais Recente)')
        
        # Subplot 4: Histograma de violações
        plt.subplot(2, 3, 4)
        plt.hist(self.violation_history[-50:], bins=20, alpha=0.7, edgecolor='black')
        plt.axvline(x=self.max_violations_allow, color='g', linestyle='--', label='Allow')
        plt.axvline(x=self.max_violations_degrade, color='orange', linestyle='--', label='Degrade')
        plt.xlabel('Taxa de Violação')
        plt.ylabel('Frequência')
        plt.title('Distribuição de Taxa de Violação')
        plt.legend()
        
        # Subplot 5: Evolução dos testes individuais
        plt.subplot(2, 3, 5)
        test_names = list(latest_results.keys())
        
        for test_name in test_names[:3]:  # Primeiros 3 testes
            test_violations = []
            for results in self.test_results_history[-20:]:  # Últimas 20 avaliações
                if test_name in results and 'violation_rate' in results[test_name]:
                    test_violations.append(results[test_name]['violation_rate'])
                else:
                    test_violations.append(0)
            
            plt.plot(test_violations, label=test_name, alpha=0.7)
        
        plt.xlabel('Avaliação')
        plt.ylabel('Taxa de Violação')
        plt.title('Evolução dos Testes (Últimas 20)')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Subplot 6: Comparação com benchmarks
        plt.subplot(2, 3, 6)
        recent_violations = np.array(self.violation_history[-20:])
        
        plt.boxplot([recent_violations], labels=['Atual'])
        plt.axhline(y=0.01, color='green', linestyle='--', label='Robusto (<1%)')
        plt.axhline(y=0.05, color='yellow', linestyle='--', label='Aceitável (<5%)')
        plt.axhline(y=0.10, color='red', linestyle='--', label='Crítico (>10%)')
        plt.ylabel('Taxa de Violação')
        plt.title('Comparação com Benchmarks')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            print(f"Gráfico salvo em: {save_path}")
        
        plt.show()

# Teste da suite de testes metamórficos
def test_metamorphic_suite():
    """Testa a suite de testes metamórficos."""
    
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.datasets import make_classification
    
    # Gerar dados de teste
    X, y = make_classification(n_samples=500, n_features=10, random_state=42)
    
    # Treinar modelo
    model = RandomForestClassifier(random_state=42)
    model.fit(X, y)
    
    # Suite de testes metamórficos
    config = {
        'tolerance': 0.1,
        'max_violations_allow': 0.05,
        'max_violations_degrade': 0.10
    }
    
    metamorphic_suite = MetamorphicTestSuite(config)
    
    # Executar testes
    print("=== TESTE DE ROBUSTEZ METAMÓRFICA ===")
    result = metamorphic_suite.evaluate(model, X, n_samples=100)
    
    print(f"Taxa de violação global: {result['global_violation_rate']:.3f}")
    print(f"Decisão: {result['decision']}")
    print(f"Testes passados: {result['statistics']['tests_passed']}/{len(result['test_results'])}")
    
    # Detalhes por teste
    print("\nDetalhes por teste:")
    for test_name, test_result in result['test_results'].items():
        status = test_result.get('status', 'ERROR')
        violations = test_result.get('violations', 0)
        rate = test_result.get('violation_rate', 0)
        print(f"  {test_name}: {status} ({violations} violações, {rate:.3f})")
    
    # Análise de violações
    analysis = metamorphic_suite.analyze_violations(result['test_results'])
    if analysis['patterns']:
        print(f"\nPadrões identificados: {', '.join(analysis['patterns'])}")
    
    # Visualizar resultados
    metamorphic_suite.visualize_results()
    
    return metamorphic_suite

# Executar teste
test_meta = test_metamorphic_suite()
```

### 3.3 UMJAM (Controle Afim Externo)

```python
class UMJAMController:
    """
    Controlador UMJAM para controle afim externo.
    
    Implementa: m_{t+1} = (I-K)m_t + K*target
    
    Garante convergência se λ_max(K) < 1.
    Usado para estabilizar sistemas de IA sem abrir a caixa.
    """
    
    def __init__(self, target: float, convergence_rate: float = 0.1, max_iterations: int = 10):
        self.target = target
        self.convergence_rate = convergence_rate
        self.max_iterations = max_iterations
        
        # Estado do controlador
        self.state = 0.0
        self.control_history = []
        self.observation_history = []
        
        # Verificar se K é estável
        if convergence_rate >= 2.0:
            raise ValueError("Convergence rate deve ser < 2.0 para estabilidade")
    
    def update(self, observation: float) -> float:
        """
        Atualiza estado do controlador com nova observação.
        
        Args:
            observation: Nova observação do sistema
        
        Returns:
            Sinal de controle
        """
        
        # Atualizar estado: m_{t+1} = (I-K)m_t + K*target
        self.state = (1 - self.convergence_rate) * self.state + self.convergence_rate * self.target
        
        # Calcular sinal de controle: u_t = m_t + K*(obs - target)
        control_signal = self.state + self.convergence_rate * (observation - self.target)
        
        # Armazenar histórico
        self.control_history.append(control_signal)
        self.observation_history.append(observation)
        
        # Manter apenas últimos 1000 valores
        if len(self.control_history) > 1000:
            self.control_history = self.control_history[-1000:]
            self.observation_history = self.observation_history[-1000:]
        
        return control_signal
    
    def converge(self, observations: List[float]) -> bool:
        """
        Testa convergência do controlador.
        
        Args:
            observations: Lista de observações para teste
        
        Returns:
            True se convergiu dentro do número máximo de iterações
        """
        
        # Reset estado
        self.state = 0.0
        
        for i in range(min(self.max_iterations, len(observations))):
            obs = observations[i]
            control = self.update(obs)
            
            # Verificar convergência
            error = abs(self.state - self.target)
            if error < 0.01:  # Tolerância
                return True
        
        return False
    
    def get_stability_analysis(self) -> Dict[str, Any]:
        """
        Analisa estabilidade do controlador.
        
        Returns:
            Dict com análise de estabilidade
        """
        
        if len(self.control_history) < 10:
            return {'status': 'insufficient_data'}
        
        # Análise de convergência
        recent_controls = np.array(self.control_history[-20:])
        recent_observations = np.array(self.observation_history[-20:])
        
        # Verificar se estado está convergindo para target
        state_errors = np.abs(recent_controls - self.target)
        mean_error = np.mean(state_errors)
        std_error = np.std(state_errors)
        
        # Verificar se observações estão sendo controladas
        observation_errors = np.abs(recent_observations - self.target)
        mean_obs_error = np.mean(observation_errors)
        
        # Classificar estabilidade
        if mean_error < 0.01 and std_error < 0.005:
            stability = 'stable'
        elif mean_error < 0.05:
            stability = 'mostly_stable'
        elif mean_error < 0.1:
            stability = 'marginally_stable'
        else:
            stability = 'unstable'
        
        # Calcular taxa de convergência
        if len(state_errors) > 1:
            convergence_rate_estimated = np.mean(np.diff(np.log(state_errors + 1e-10)))
        else:
            convergence_rate_estimated = 0.0
        
        return {
            'stability': stability,
            'mean_error': mean_error,
            'std_error': std_error,
            'mean_observation_error': mean_obs_error,
            'convergence_rate_estimated': convergence_rate_estimated,
            'target': self.target,
            'current_state': self.state,
            'control_signal': self.control_history[-1] if self.control_history else 0.0
        }
    
    def apply_control_policy(self, model, X, y, control_signal: float) -> Dict[str, Any]:
        """
        Aplica política de controle ao modelo/sistema.
        
        Args:
            model: Modelo a ser controlado
            X: Features
            y: Labels
            control_signal: Sinal de controle do UMJAM
        
        Returns:
            Dict com resultado da aplicação do controle
        """
        
        # Implementação básica: ajustar threshold de decisão
        # baseado no sinal de controle
        
        original_predictions = model.predict(X)
        accuracy = np.mean(original_predictions == y)
        
        # Ajustar comportamento baseado no sinal de controle
        if hasattr(model, 'predict_proba'):
            probabilities = model.predict_proba(X)
            
            # Modificar probabilities baseado no controle
            # Sinal positivo: ser mais conservador (aumentar threshold)
            # Sinal negativo: ser mais agressivo (diminuir threshold)
            
            adjustment_factor = 1.0 + (control_signal * 0.1)  # Ajuste máximo de 10%
            adjusted_probs = probabilities * adjustment_factor
            
            # Normalizar
            adjusted_probs = adjusted_probs / np.sum(adjusted_probs, axis=1, keepdims=True)
            
            # Novas predições baseadas em probabilities ajustadas
            adjusted_predictions = np.argmax(adjusted_probs, axis=1)
            adjusted_accuracy = np.mean(adjusted_predictions == y)
            
        else:
            # Para modelos sem predict_proba, aplicar controle de outra forma
            adjusted_predictions = original_predictions
            adjusted_accuracy = accuracy
        
        return {
            'original_accuracy': accuracy,
            'adjusted_accuracy': adjusted_accuracy,
            'control_effect': adjusted_accuracy - accuracy,
            'control_signal': control_signal,
            'adjustment_factor': 1.0 + (control_signal * 0.1)
        }
    
    def visualize_control(self, save_path=None):
        """Visualiza histórico de controle."""
        
        if len(self.control_history) < 10:
            print("Dados insuficientes para visualização")
            return
        
        plt.figure(figsize=(12, 8))
        
        # Subplot 1: Controle ao longo do tempo
        plt.subplot(2, 2, 1)
        plt.plot(self.control_history, 'b-', label='Sinal de Controle', linewidth=2)
        plt.axhline(y=self.target, color='g', linestyle='--', label='Target')
        plt.xlabel('Iteração')
        plt.ylabel('Sinal de Controle')
        plt.title('Evolução do Controle UMJAM')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Subplot 2: Estado vs Target
        plt.subplot(2, 2, 2)
        states = [(1 - self.convergence_rate) ** i * self.state for i in range(len(self.control_history))]
        plt.plot(states, 'r-', label='Estado', linewidth=2)
        plt.axhline(y=self.target, color='g', linestyle='--', label='Target')
        plt.xlabel('Iteração')
        plt.ylabel('Estado')
        plt.title('Convergência do Estado')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Subplot 3: Observações vs Target
        plt.subplot(2, 2, 3)
        plt.plot(self.observation_history, 'orange', label='Observações', alpha=0.7)
        plt.axhline(y=self.target, color='g', linestyle='--', label='Target')
        plt.xlabel('Iteração')
        plt.ylabel('Valor Observado')
        plt.title('Observações do Sistema')
        plt.legend()
        plt.grid(True, alpha=0.3)
        
        # Subplot 4: Análise de estabilidade
        plt.subplot(2, 2, 4)
        stability = self.get_stability_analysis()
        
        if stability['status'] != 'insufficient_data':
            errors = np.abs(np.array(self.control_history[-20:]) - self.target)
            plt.plot(errors, 'purple', linewidth=2)
            plt.xlabel('Iteração')
            plt.ylabel('Erro Absoluto')
            plt.title(f'Estabilidade: {stability["stability"]}')
            plt.grid(True, alpha=0.3)
            
            # Estatísticas
            plt.text(0.02, 0.98, 
                    f'Erro médio: {stability["mean_error"]:.4f}\n'
                    f'Erro std: {stability["std_error"]:.4f}',
                    transform=plt.gca().transAxes,
                    verticalalignment='top',
                    bbox=dict(boxstyle='round', facecolor='wheat', alpha=0.5))
        
        plt.tight_layout()
        
        if save_path:
            plt.savefig(save_path)
            print(f"Gráfico salvo em: {save_path}")
        
        plt.show()

# Teste do controlador UMJAM
def test_umjam_controller():
    """Testa o controlador UMJAM."""
    
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.datasets import make_classification
    
    # Gerar dados com deriva
    np.random.seed(42)
    X1, y1 = make_classification(n_samples=300, n_features=5, random_state=1)
    X2, y2 = make_classification(n_samples=300, n_features=5, random_state=2)
    
    # Treinar modelo inicial
    model = RandomForestClassifier(random_state=42)
    model.fit(X1, y1)
    
    # Controller UMJAM
    target_accuracy = 0.85
    umjam = UMJAMController(target=target_accuracy, convergence_rate=0.1)
    
    # Simular observações com deriva
    observations = []
    controls = []
    
    print("=== TESTE DO CONTROLADOR UMJAM ===")
    print(f"Target accuracy: {target_accuracy}")
    
    # Teste 1: Dados iniciais (boa performance)
    for i in range(5):
        accuracy = np.mean(model.predict(X1) == y1)
        control = umjam.update(accuracy)
        observations.append(accuracy)
        controls.append(control)
        print(f"Iteração {i+1}: Accuracy={accuracy:.3f}, Control={control:.3f}")
    
    # Teste 2: Dados com deriva (performance degrada)
    for i in range(5):
        accuracy = np.mean(model.predict(X2) == y2)
        control = umjam.update(accuracy)
        observations.append(accuracy)
        controls.append(control)
        print(f"Iteração {i+6}: Accuracy={accuracy:.3f}, Control={control:.3f}")
    
    # Testar convergência
    convergence_result = umjam.converge(observations)
    print(f"\nConvergência: {convergence_result}")
    
    # Análise de estabilidade
    stability = umjam.get_stability_analysis()
    print(f"Estabilidade: {stability['stability']}")
    print(f"Erro médio: {stability['mean_error']:.4f}")
    
    # Visualizar controle
    umjam.visualize_control()
    
    return umjam

# Executar teste
test_umjam = test_umjam_controller()
```

## 4. Camada de Evidência

### 4.1 Ledger Imutável

```python
class ImmutableLedger:
    """
    Ledger imutável com hash chaining para evidência de auditoria.
    
    Cada entrada contém:
    - prev_hash: hash da entrada anterior
    - record_hash: hash desta entrada (sem o campo record_hash)
    - timestamp: UTC ISO format
    - data: dados da decisão
    """
    
    def __init__(self, path: str, hash_algorithm: str = "sha3_256"):
        self.path = path
        self.hash_algorithm = hash_algorithm
        self._ensure_file_exists()
    
    def _ensure_file_exists(self):
        """Garante que o arquivo do ledger existe."""
        import os
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        if not os.path.exists(self.path):
            with open(self.path, 'w') as f:
                pass  # Cria arquivo vazio
    
    def _hash_data(self, data: bytes) -> str:
        """Calcula hash usando algoritmo especificado."""
        import hashlib
        h = hashlib.new(self.hash_algorithm)
        h.update(data)
        return h.hexdigest()
    
    def _canonical_json(self, obj: dict) -> bytes:
        """Canonical JSON: keys ordenadas, sem whitespace."""
        import json
        return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    
    def append(self, data: dict) -> dict:
        """
        Adiciona nova entrada ao ledger.
        
        Args:
            data: Dados a serem registrados
        
        Returns:
            Dict com a entrada completa (incluindo hashes)
        """
        
        # Obter hash da entrada anterior
        prev_hash = self._get_last_hash()
        
        # Preparar nova entrada
        record = {
            "prev_hash": prev_hash,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **data
        }
        
        # Calcular hash da entrada (sem o campo record_hash)
        record_copy = record.copy()
        record_copy.pop("record_hash", None)
        record["record_hash"] = self._hash_data(self._canonical_json(record_copy))
        
        # Escrever no arquivo
        with open(self.path, "a", encoding="utf-8") as f:
            import json
            f.write(json.dumps(record, ensure_ascii=False) + "\\n")
        
        return record
    
    def verify(self) -> Dict[str, Any]:
        """
        Verifica integridade do ledger.
        
        Returns:
            Dict com resultado da verificação
        """
        
        import os
        import json
        
        if not os.path.exists(self.path) or os.path.getsize(self.path) == 0:
            return {
                "valid": True,
                "message": "Ledger vazio",
                "total_records": 0
            }
        
        prev_hash = "GENESIS"
        total_records = 0
        invalid_records = []
        
        with open(self.path, "r", encoding="utf-8") as f:
            for line_num, line in enumerate(f, 1):
                if not line.strip():
                    continue
                
                try:
                    record = json.loads(line)
                    total_records += 1
                    
                    # Verificar cadeia de hash
                    if record.get("prev_hash") != prev_hash:
                        invalid_records.append({
                            "line": line_num,
                            "reason": f"Hash anterior incorreto: {record.get('prev_hash')} != {prev_hash}",
                            "record": record
                        })
                        break
                    
                    # Verificar hash da entrada
                    record_copy = record.copy()
                    expected_hash = record_copy.pop("record_hash")
                    calculated_hash = self._hash_data(self._canonical_json(record_copy))
                    
                    if expected_hash != calculated_hash:
                        invalid_records.append({
                            "line": line_num,
                            "reason": f"Hash da entrada incorreto: {expected_hash} != {calculated_hash}",
                            "record": record
                        })
                        break
                    
                    prev_hash = expected_hash
                
                except json.JSONDecodeError as e:
                    invalid_records.append({
                        "line": line_num,
                        "reason": f"JSON inválido: {e}",
                        "record": None
                    })
                    break
        
        if invalid_records:
            return {
                "valid": False,
                "message": f"Ledger inválido: {len(invalid_records)} erro(s)",
                "total_records": total_records,
                "invalid_records": invalid_records[:5]  # Primeiros 5 erros
            }
        else:
            return {
                "valid": True,
                "message": "Ledger íntegro",
                "total_records": total_records,
                "last_hash": prev_hash
            }
    
    def _get_last_hash(self) -> str:
        """Obtém hash da última entrada."""
        
        import os
        if not os.path.exists(self.path) or os.path.getsize(self.path) == 0:
            return "GENESIS"
        
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    import json
                    last_record = json.loads(line)
        
        return last_record.get("record_hash", "GENESIS")
    
    def get_records(self, limit: int = None, offset: int = 0) -> List[dict]:
        """
        Obtém registros do ledger.
        
        Args:
            limit: Número máximo de registros
            offset: Offset para paginação
        
        Returns:
            Lista de registros
        """
        
        import json
        
        records = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line_num, line in enumerate(f):
                if not line.strip():
                    continue
                
                if line_num < offset:
                    continue
                
                if limit and len(records) >= limit:
                    break
                
                try:
                    record = json.loads(line)
                    records.append(record)
                except json.JSONDecodeError:
                    continue
        
        return records
    
    def search_records(self, query: dict) -> List[dict]:
        """
        Busca registros que contenham os critérios especificados.
        
        Args:
            query: Dict com critérios de busca
        
        Returns:
            Lista de registros que atendem aos critérios
        """
        
        import json
        
        results = []
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                
                try:
                    record = json.loads(line)
                    
                    # Verificar se record atende aos critérios
                    matches = True
                    for key, value in query.items():
                        if key not in record or record[key] != value:
                            matches = False
                            break
                    
                    if matches:
                        results.append(record)
                
                except json.JSONDecodeError:
                    continue
        
        return results
    
    def export_audit_trail(self, output_path: str, format: str = "json") -> str:
        """
        Exporta trilha de auditoria para arquivo.
        
        Args:
            output_path: Caminho do arquivo de saída
            format: Formato de exportação ("json", "csv", "txt")
        
        Returns:
            Caminho do arquivo exportado
        """
        
        records = self.get_records()
        
        if format == "json":
            import json
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(records, f, indent=2, ensure_ascii=False)
        
        elif format == "csv":
            import csv
            if records:
                with open(output_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.DictWriter(f, fieldnames=records[0].keys())
                    writer.writeheader()
                    writer.writerows(records)
        
        elif format == "txt":
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write("AUDIT TRAIL - MATVERSE GOVERNANCE\\n")
                f.write("=" * 50 + "\\n\\n")
                
                for i, record in enumerate(records, 1):
                    f.write(f"RECORD {i:\\n")
                    for key, value in record.items():
                        f.write(f"  {key}: {value}\\n")
                    f.write("\\n")
        
        return output_path
    
    def get_statistics(self) -> Dict[str, Any]:
        """Obtém estatísticas do ledger."""
        
        import json
        
        records = self.get_records()
        
        if not records:
            return {
                "total_records": 0,
                "date_range": None,
                "hash_algorithm": self.hash_algorithm,
                "file_size": 0
            }
        
        # Estatísticas básicas
        total_records = len(records)
        
        # Range de datas
        timestamps = [record.get('timestamp') for record in records if record.get('timestamp')]
        date_range = {
            "first": min(timestamps) if timestamps else None,
            "last": max(timestamps) if timestamps else None
        }
        
        # Distribuição por tipo de decisão
        decisions = {}
        for record in records:
            decision = record.get('decision', {}).get('action', 'UNKNOWN')
            decisions[decision] = decisions.get(decision, 0) + 1
        
        # Estatísticas de métricas
        metrics = {}
        cvar_values = [record.get('controls', {}).get('cvar') for record in records 
                      if record.get('controls', {}).get('cvar') is not None]
        
        if cvar_values:
            metrics['cvar'] = {
                'mean': np.mean(cvar_values),
                'std': np.std(cvar_values),
                'min': np.min(cvar_values),
                'max': np.max(cvar_values)
            }
        
        # Tamanho do arquivo
        import os
        file_size = os.path.getsize(self.path) if os.path.exists(self.path) else 0
        
        return {
            "total_records": total_records,
            "date_range": date_range,
            "decision_distribution": decisions,
            "metrics_statistics": metrics,
            "hash_algorithm": self.hash_algorithm,
            "file_size_bytes": file_size,
            "file_size_mb": file_size / (1024 * 1024)
        }

# Teste do ledger imutável
def test_immutable_ledger():
    """Testa o ledger imutável."""
    
    import tempfile
    import os
    
    # Criar arquivo temporário para teste
    temp_dir = tempfile.mkdtemp()
    ledger_path = os.path.join(temp_dir, "test_ledger.jsonl")
    
    # Criar ledger
    ledger = ImmutableLedger(ledger_path)
    
    print("=== TESTE DO LEDGER IMUTÁVEL ===")
    
    # Adicionar registros de exemplo
    for i in range(5):
        record_data = {
            "evaluation_id": f"eval_{i:03d}",
            "decision": {
                "action": ["ALLOW", "DEGRADE", "BLOCK"][i % 3],
                "omega_score": 0.8 + i * 0.05
            },
            "controls": {
                "cvar": 0.1 + i * 0.02,
                "metamorphic_violations": 0.05 + i * 0.01
            },
            "model_info": {
                "type": "RandomForest",
                "version": "1.0"
            }
        }
        
        record = ledger.append(record_data)
        print(f"Registro {i+1}: {record['evaluation_id']} - Hash: {record['record_hash'][:16]}...")
    
    # Verificar integridade
    print("\\nVerificação de integridade:")
    verification = ledger.verify()
    print(f"Válido: {verification['valid']}")
    print(f"Total de registros: {verification['total_records']}")
    print(f"Mensagem: {verification['message']}")
    
    # Obter registros
    print("\\nÚltimos 3 registros:")
    recent_records = ledger.get_records(limit=3)
    for record in recent_records:
        print(f"  - {record['evaluation_id']}: {record['decision']['action']}")
    
    # Estatísticas
    print("\\nEstatísticas:")
    stats = ledger.get_statistics()
    print(f"Total de registros: {stats['total_records']}")
    print(f"Tamanho do arquivo: {stats['file_size_mb']:.2f} MB")
    print(f"Distribuição de decisões: {stats['decision_distribution']}")
    
    # Exportar trilha de auditoria
    audit_path = os.path.join(temp_dir, "audit_trail.json")
    ledger.export_audit_trail(audit_path, format="json")
    print(f"\\nTrilha de auditoria exportada: {audit_path}")
    
    # Limpeza
    import shutil
    shutil.rmtree(temp_dir)
    
    return ledger

# Executar teste
test_ledger = test_immutable_ledger()
```

## 5. Sistema Completo de Governança

### 5.1 Integração das Camadas

```python
class ControlLayer:
    """
    Camada de controle que integra CVaR, testes metamórficos e UMJAM.
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        
        # Inicializar componentes
        self.cvar_controller = CVaRController(
            alpha=config['cvar']['alpha'],
            max_allow=config['cvar']['max_allow'],
            max_degrade=config['cvar']['max_degrade']
        )
        
        self.metamorphic_suite = MetamorphicTestSuite(config['metamorphic'])
        
        self.umjam_controller = UMJAMController(
            target=config['umjam']['target'],
            convergence_rate=config['umjam']['convergence_rate'],
            max_iterations=config['umjam']['max_iterations']
        )
    
    def apply(self, model, X, y, observations: Dict[str, Any]) -> Dict[str, Any]:
        """Aplica todos os controles."""
        
        # CVaR: Risco de cauda
        cvar_result = self.cvar_controller.evaluate(model, X, y)
        
        # Testes metamórficos: Robustez
        metamorphic_result = self.metamorphic_suite.evaluate(model, X)
        
        # UMJAM: Controle dinâmico
        accuracy = observations['performance']['accuracy']
        umjam_control = self.umjam_controller.update(accuracy)
        
        # Aplicar política de controle
        control_policy = self.umjam_controller.apply_control_policy(model, X, y, umjam_control)
        
        return {
            'cvar': cvar_result['cvar'],
            'cvar_decision': cvar_result['decision'],
            'metamorphic_violations': metamorphic_result['global_violation_rate'],
            'metamorphic_decision': metamorphic_result['decision'],
            'umjam_control': umjam_control,
            'control_policy': control_policy,
            'all_decisions': {
                'cvar': cvar_result['decision'],
                'metamorphic': metamorphic_result['decision'],
                'umjam': 'ACTIVE'
            }
        }

class EvidenceLayer:
    """
    Camada de evidência para registro imutável.
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.ledger = ImmutableLedger(
            path=config['ledger_path'],
            hash_algorithm=config['hash_algorithm']
        )
    
    def record(self, observations: Dict[str, Any], controls: Dict[str, Any], metadata: Dict[str, Any] = None) -> Dict[str, Any]:
        """Registra evidência no ledger."""
        
        # Preparar dados para registro
        evidence_data = {
            'observations': observations,
            'controls': controls,
            'metadata': metadata or {},
            'system_info': {
                'version': '1.0.0',
                'governance_layer': 'OpenBox'
            }
        }
        
        # Registrar no ledger
        ledger_entry = self.ledger.append(evidence_data)
        
        return {
            'ledger_entry': ledger_entry,
            'ledger_path': self.config['ledger_path'],
            'verification': self.ledger.verify()
        }

class OmegaGate:
    """
    Ω-GATE: Sistema de decisões final.
    Combina múltiplas métricas para decisão única.
    """
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.weights = config['weights']
        self.thresholds = config['thresholds']
        self.decision_history = []
    
    def decide(self, controls: Dict[str, Any]) -> Dict[str, Any]:
        """Decisão final baseada em todas as métricas."""
        
        # Normalizar métricas (0 = pior, 1 = melhor)
        normalized_metrics = self._normalize_metrics(controls)
        
        # Calcular score Ω (antifragilidade)
        omega_score = sum(
            normalized_metrics[metric] * weight 
            for metric, weight in self.weights.items()
            if metric in normalized_metrics
        )
        
        # Decisão baseada em thresholds
        if omega_score >= self.thresholds['allow']:
            action = "ALLOW"
        elif omega_score >= self.thresholds['degrade']:
            action = "DEGRADE"
        else:
            action = "BLOCK"
        
        # Gerar justificativa
        justification = self._generate_justification(controls, omega_score, action)
        
        # Armazenar histórico
        self.decision_history.append({
            'omega_score': omega_score,
            'action': action,
            'metrics': normalized_metrics,
            'timestamp': datetime.now(timezone.utc).isoformat()
        })
        
        return {
            'action': action,
            'omega_score': omega_score,
            'justification': justification,
            'normalized_metrics': normalized_metrics,
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
    
    def _normalize_metrics(self, controls: Dict[str, Any]) -> Dict[str, float]:
        """Normaliza métricas para [0,1]."""
        
        normalized = {}
        
        # CVaR: menor é melhor
        cvar_value = controls.get('cvar', 1.0)
        normalized['cvar'] = max(0, 1 - cvar_value / 0.5)  # Normaliza para 0.5 como máximo
        
        # Metamórfico: menor é melhor
        meta_violations = controls.get('metamorphic_violations', 1.0)
        normalized['metamorphic_violations'] = max(0, 1 - meta_violations / 0.2)  # Normaliza para 0.2
        
        # Latência: menor é melhor
        # (seria extraído das observações, mas aqui assumimos valor padrão)
        normalized['latency_p95'] = max(0, 1 - 0.1)  # Assumindo 100ms como threshold
        
        # Deriva: menor é melhor
        normalized['drift_score'] = max(0, 1 - 0.1)  # Assumindo 0.1 como threshold
        
        return normalized
    
    def _generate_justification(self, controls: Dict[str, Any], omega_score: float, action: str) -> str:
        """Gera justificativa textual da decisão."""
        
        violations = []
        
        # Verificar violações específicas
        if controls.get('cvar', 0) > 0.25:
            violations.append(f"CVaR crítico: {controls['cvar']:.3f}")
        
        if controls.get('metamorphic_violations', 0) > 0.15:
            violations.append(f"Violações metamórficas altas: {controls['metamorphic_violations']:.3f}")
        
        if violations:
            return f"Decisão {action}: " + "; ".join(violations)
        else:
            return f"Decisão {action}: Sistema dentro de parâmetros normais (Ω={omega_score:.3f})"

# Atualizar a classe principal
class OperationalGovernance:
    """Sistema completo de governança operacional."""
    
    def __init__(self, config: GovernanceConfig):
        self.config = config
        self.setup_layers()
    
    def setup_layers(self):
        """Inicializa as 3 camadas de governança."""
        
        # Camada 1: Observabilidade
        self.observability = ObservabilityLayer(self.config.observability)
        
        # Camada 2: Controle
        self.control = ControlLayer(self.config.control)
        
        # Camada 3: Evidência
        self.evidence = EvidenceLayer(self.config.evidence)
        
        # Ω-GATE: Sistema de decisões
        self.omega_gate = OmegaGate(self.config.omega)
    
    def evaluate_system(self, model, X, y, metadata=None):
        """Avalia sistema completo."""
        
        # 1. Observabilidade: Coleta métricas
        observations = self.observability.collect(model, X, y)
        
        # 2. Controle: Aplica governança
        controls = self.control.apply(model, X, y, observations)
        
        # 3. Evidência: Registra tudo
        evidence = self.evidence.record(observations, controls, metadata)
        
        # 4. Decisão: Ω-GATE
        decision = self.omega_gate.decide(controls)
        
        return {
            'decision': decision,
            'observations': observations,
            'controls': controls,
            'evidence': evidence,
            'timestamp': datetime.now(timezone.utc).isoformat()
        }
    
    def get_system_status(self) -> Dict[str, Any]:
        """Obtém status completo do sistema."""
        
        return {
            'observability': {
                'status': 'active',
                'last_update': datetime.now(timezone.utc).isoformat()
            },
            'control': {
                'cvar_status': 'active' if hasattr(self.control.cvar_controller, 'cvar_history') else 'inactive',
                'metamorphic_status': 'active' if hasattr(self.control.metamorphic_suite, 'violation_history') else 'inactive',
                'umjam_status': 'active'
            },
            'evidence': {
                'ledger_status': self.evidence.ledger.verify()['valid'],
                'ledger_path': self.evidence.config['ledger_path']
            },
            'omega_gate': {
                'status': 'active',
                'total_decisions': len(self.omega_gate.decision_history)
            }
        }
```

### 5.2 Sistema Completo em Ação

```python
def demo_complete_governance_system():
    """Demonstração do sistema completo de governança."""
    
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.datasets import make_classification
    
    print("=== DEMONSTRAÇÃO DO SISTEMA COMPLETO ===")
    
    # 1. Configurar sistema
    config = GovernanceConfig()
    governance_system = OperationalGovernance(config)
    
    # 2. Gerar dados com diferentes características
    print("\\n1. Gerando datasets...")
    
    # Dataset 1: Dados limpos (boa performance)
    X_clean, y_clean = make_classification(
        n_samples=500, n_features=10, n_informative=8, 
        n_redundant=2, noise=0.1, random_state=42
    )
    
    # Dataset 2: Dados com ruído (performance degradada)
    X_noisy, y_noisy = make_classification(
        n_samples=500, n_features=10, n_informative=8, 
        n_redundant=2, noise=0.5, random_state=123
    )
    
    # Dataset 3: Dados com deriva (performance variável)
    X_drift, y_drift = make_classification(
        n_samples=500, n_features=10, n_informative=8, 
        n_redundant=2, noise=0.3, random_state=456
    )
    
    # 3. Treinar modelo
    print("\\n2. Treinando modelo...")
    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_clean, y_clean)
    
    # 4. Avaliar com diferentes datasets
    datasets = [
        ("Dados Limpos", X_clean, y_clean),
        ("Dados Ruidosos", X_noisy, y_noisy),
        ("Dados com Deriva", X_drift, y_drift)
    ]
    
    results_summary = []
    
    for dataset_name, X, y in datasets:
        print(f"\\n3. Avaliando: {dataset_name}")
        
        # Metadados da avaliação
        metadata = {
            'dataset_name': dataset_name,
            'dataset_size': len(X),
            'evaluation_id': f"eval_{dataset_name.replace(' ', '_').lower()}"
        }
        
        # Avaliar sistema
        result = governance_system.evaluate_system(model, X, y, metadata)
        
        # Exibir resultados
        decision = result['decision']
        controls = result['controls']
        observations = result['observations']
        
        print(f"   Decisão Ω-GATE: {decision['action']}")
        print(f"   Score Ω: {decision['omega_score']:.3f}")
        print(f"   CVaR: {controls['cvar']:.3f}")
        print(f"   Violações Metamórficas: {controls['metamorphic_violations']:.3f}")
        print(f"   Controle UMJAM: {controls['umjam_control']:.3f}")
        print(f"   Accuracy: {observations['performance']['accuracy']:.3f}")
        print(f"   Latência p95: {observations['performance']['latency_p95']:.1f}ms")
        
        # Verificar evidência
        evidence = result['evidence']
        ledger_valid = evidence['verification']['valid']
        print(f"   Ledger Válido: {ledger_valid}")
        
        # Armazenar para resumo
        results_summary.append({
            'dataset': dataset_name,
            'decision': decision['action'],
            'omega_score': decision['omega_score'],
            'cvar': controls['cvar'],
            'violations': controls['metamorphic_violations'],
            'accuracy': observations['performance']['accuracy']
        })
    
    # 5. Resumo final
    print("\\n" + "="*60)
    print("RESUMO FINAL")
    print("="*60)
    
    for summary in results_summary:
        print(f"{summary['dataset']:20s} | {summary['decision']:8s} | "
              f"Ω={summary['omega_score']:.3f} | CVaR={summary['cvar']:.3f}")
    
    # 6. Status do sistema
    print("\\n4. Status do Sistema:")
    system_status = governance_system.get_system_status()
    print(f"   Observabilidade: {system_status['observability']['status']}")
    print(f"   CVaR Controller: {system_status['control']['cvar_status']}")
    print(f"   Metamorphic Suite: {system_status['control']['metamorphic_status']}")
    print(f"   UMJAM Controller: {system_status['control']['umjam_status']}")
    print(f"   Ledger: {'Válido' if system_status['evidence']['ledger_status'] else 'Inválido'}")
    print(f"   Ω-GATE: {system_status['omega_gate']['status']}")
    
    print("\\n✅ Sistema de governança operacional funcionando!")
    
    return governance_system, results_summary

# Executar demonstração
governance_demo, demo_results = demo_complete_governance_system()
```

## 6. Exercícios Práticos

### Exercício 1: Implementar CVaR Customizado

```python
def exercise_custom_cvar():
    """
    Exercício: Implemente CVaR customizado para seu domínio específico.
    
    Casos de uso:
    - Financeiro: CVaR de perdas monetárias
    - Healthcare: CVaR de erros médicos
    - Trading: CVaR de drawdowns
    """
    
    print("=== EXERCÍCIO 1: CVaR CUSTOMIZADO ===")
    print()
    print("Implemente função de perda específica para seu domínio:")
    print()
    print("Exemplo Financeiro:")
    print("""
def financial_losses(predictions, actual_returns, portfolio_value):
    '''Calcula perdas financeiras reais.'''
    pnl = predictions * actual_returns * portfolio_value
    losses = np.where(pnl < 0, -pnl, 0)  # Apenas perdas
    return losses
""")
    
    print()
    print("Exemplo Healthcare:")
    print("""
def medical_losses(predictions, true_diagnosis, severity_weights):
    '''Calcula perdas por erro médico ponderadas por severidade.'''
    errors = (predictions != true_diagnosis).astype(float)
    weighted_errors = errors * severity_weights
    return weighted_errors
""")
    
    print()
    print("Sua implementação:")
    print("""
def your_domain_losses(predictions, y_true, **kwargs):
    # Seu código aqui
    pass
""")
    
    # Template para implementação
    implementation_template = '''
def custom_cvar_implementation():
    """
    Template para implementação de CVaR customizado.
    """
    
    # 1. Defina sua função de perda específica
    def domain_specific_losses(predictions, y_true, **kwargs):
        # Implemente lógica específica do seu domínio
        # Exemplo: combinar diferentes tipos de perda
        
        # Tipo 1: Erro binário
        binary_errors = (predictions != y_true).astype(float)
        
        # Tipo 2: Perda de confiança
        if hasattr(model, 'predict_proba'):
            probabilities = model.predict_proba(X)
            max_proba = np.max(probabilities, axis=1)
            confidence_loss = (1 - max_proba)
        else:
            confidence_loss = np.zeros(len(predictions))
        
        # Tipo 3: Penalidade específica do domínio
        domain_penalty = calculate_domain_penalty(predictions, y_true, **kwargs)
        
        # Combinar perdas
        total_losses = binary_errors + confidence_loss + domain_penalty
        
        return total_losses
    
    # 2. Modifique o CVaR controller
    class CustomCVaRController(CVaRController):
        def _compute_losses(self, predictions, y_true):
            # Usar função customizada
            return domain_specific_losses(predictions, y_true)
    
    return CustomCVaRController()

# Execute e teste sua implementação
custom_cvar = custom_cvar_implementation()
'''
    
    print(implementation_template)

exercise_custom_cvar()
```

### Exercício 2: Testes Metamórficos Específicos

```python
def exercise_domain_metamorphic_tests():
    """
    Exercício: Defina testes metamórficos específicos para seu domínio.
    """
    
    print("=== EXERCÍCIO 2: TESTES METAMÓRFICOS ESPECÍFICOS ===")
    print()
    print("Defina transformações válidas para seu domínio:")
    print()
    
    examples = {
        "Financeiro": [
            "Pequena variação em preços (ruído de mercado)",
            "Permutação de ativos não correlacionados",
            "Escalonamento proporcional de portfolio",
            "Offset temporal mínimo"
        ],
        "Healthcare": [
            "Variação normal em exames médicos",
            "Permutação de sintomas não correlacionados",
            "Escalonamento dentro de ranges fisiológicos",
            "Adição de ruído instrumental"
        ],
        "E-commerce": [
            "Pequena variação em preços",
            "Permutação de produtos não relacionados",
            "Escalonamento de ratings",
            "Offset em timestamps de comportamento"
        ],
        "IoT/Sensores": [
            "Ruído de sensor dentro de especificações",
            "Permutação de sensores não correlacionados",
            "Escalonamento de leituras",
            "Offset de calibração mínimo"
        ]
    }
    
    for domain, tests in examples.items():
        print(f"{domain}:")
        for i, test in enumerate(tests, 1):
            print(f"  {i}. {test}")
        print()
    
    print("Template para implementação:")
    print("""
def define_domain_transformations(your_data):
    '''Defina transformações específicas do seu domínio.'''
    
    transformations = {}
    
    # Transformação 1: Variação mínima válida
    def min_valid_variation(x):
        # Sua lógica aqui
        return x + your_noise_function(x)
    
    transformations['min_variation'] = min_valid_variation
    
    # Transformação 2: Permutação válida
    def valid_permutation(x):
        # Sua lógica aqui
        return x[:, your_permutation]
    
    transformations['valid_permutation'] = valid_permutation
    
    # Adicione mais transformações...
    
    return transformations
""")

exercise_domain_metamorphic_tests()
```

## 7. Resumo e Próximos Passos

### 7.1 Componentes Implementados

```python
def implementation_summary():
    """Resumo dos componentes implementados."""
    
    components = {
        "Observabilidade": {
            "status": "✅ Completo",
            "funcionalidades": [
                "Métricas de performance (latência, accuracy)",
                "Monitoramento de recursos (memória, CPU)",
                "Detecção de deriva de dados",
                "Monitoramento em tempo real com alertas"
            ]
        },
        "Controle": {
            "status": "✅ Completo",
            "funcionalidades": [
                "CVaR para risco de cauda",
                "Testes metamórficos para robustez",
                "UMJAM para controle dinâmico",
                "Integração de múltiplos controles"
            ]
        },
        "Evidência": {
            "status": "✅ Completo",
            "funcionalidades": [
                "Ledger imutável com hash chaining",
                "Verificação de integridade",
                "Busca e paginação de registros",
                "Exportação de trilha de auditoria"
            ]
        },
        "Decisão": {
            "status": "✅ Completo",
            "funcionalidades": [
                "Ω-GATE para decisão final",
                "Normalização de métricas",
                "Geração de justificativas",
                "Histórico de decisões"
            ]
        },
        "Sistema Completo": {
            "status": "✅ Operacional",
            "funcionalidades": [
                "Integração das 3 camadas",
                "Avaliação end-to-end",
                "Status do sistema",
                "Demonstração completa"
            ]
        }
    }
    
    print("=== RESUMO DA IMPLEMENTAÇÃO ===")
    for component, details in components.items():
        print(f"\\n{component}: {details['status']}")
        for feature in details['funcionalidades']:
            print(f"  ✓ {feature}")
    
    return components

implementation_summary()
```

### 7.2 Próximos Passos

```python
def next_steps():
    """Próximos passos para implementação em produção."""
    
    next_steps = {
        "Integração com Produção": [
            "Conectar com pipeline de ML existente",
            "Implementar caching para performance",
            "Configurar monitoramento contínuo",
            "Integrar com sistemas de alerta (Slack, PagerDuty)"
        ],
        "Escalabilidade": [
            "Implementar processamento distribuído",
            "Otimizar para grandes volumes de dados",
            "Configurar banco de dados para ledger",
            "Implementar compressão de dados históricos"
        ],
        "Compliance e Auditoria": [
            "Integrar com sistemas de compliance existentes",
            "Implementar retenção de dados conforme regulamentação",
            "Criar relatórios automáticos para auditores",
            "Integrar com blockchain (PoSE/PoLE)"
        ],
        "Automação Avançada": [
            "Implementar auto-remediation",
            "Criar políticas de controle dinâmicas",
            "Desenvolver dashboard executivo",
            "Implementar integração com CI/CD"
        ]
    }
    
    print("=== PRÓXIMOS PASSOS ===")
    for category, steps in next_steps.items():
        print(f"\\n{category}:")
        for i, step in enumerate(steps, 1):
            print(f"  {i}. {step}")
    
    return next_steps

next_steps()
```

### 7.3 Recursos Adicionais

- **Tutorial 4**: [Tail Risk e CVaR](./04_tail_risk_cvar.md) - Aprofundamento em CVaR
- **Tutorial 5**: [Testes Metamórficos](./05_metamorphic_tests.md) - Suite completa de testes
- **Tutorial 6**: [UMJAM Control](./06_umjam_control.md) - Controle dinâmico avançado
- **Tutorial 7**: [Exemplo End-to-End](./07_end_to_end_example.md) - Caso completo

### 7.4 Arquivos de Referência

- [openbox/omega_min/](../openbox/omega_min/) - Implementação de produção
- [examples/](../examples/) - Casos práticos
- [GOVERNANCE.md](../GOVERNANCE.md) - Definição formal

---

**Lembre-se**: Governança operacional é mais valiosa que explicabilidade teórica para sistemas em produção.