# OpenBox — Open the Blackbox (MatVerse-U)

**OpenBox é um repositório operacional para transformar sistemas caixa-preta (IA ou regras externas) em sistemas governáveis, auditáveis e reproduzíveis.**

## Frase Central

> *"Explicar um modelo não governa um sistema. Governar um sistema não exige explicar o modelo."*

## O que é o OpenBox

OpenBox é um **arsenal técnico-filosófico** que resolve o problema fundamental da governança de IA: como ter controle, auditabilidade e robustez operacional sem depender de explicabilidade pós-hoc.

### Diferença Fundamental

| **Explicabilidade** | **Governança** |
|---------------------|----------------|
| Responde "por quê" | Responde "posso confiar" |
| Análise local | Controle operacional |
| Ferramentas: SHAP, LIME | Ferramentas: CVaR, testes metamórficos |
| Instável sob perturbações | Robusto por design |
| Baixa defesa jurídica | Evidência legal |

## Como Ler Este Repositório (Ordem Recomendada)

1. **Leia a carta aberta**: → [OPEN_LETTER.md](./OPEN_LETTER.md)
2. **Entenda a confusão central**: → [WHY_NOT_XAI.md](./WHY_NOT_XAI.md)
3. **Veja o contraste visual**: → [diagrams/why_vs_governance.png](./diagrams/why_vs_governance.png)
4. **Leia a definição formal**: → [GOVERNANCE.md](./GOVERNANCE.md)
5. **Entre no código**: → [openbox/omega_min/](./openbox/omega_min/)
6. **Execute os exemplos**: → [examples/](./examples/)

## Estrutura do Repositório

```
OpenBox/
├── README.md              # Você está aqui
├── GOVERNANCE.md          # Definição formal de governança
├── ARCHITECTURE.md        # Arquitetura em camadas
├── WHY_NOT_XAI.md         # Por que explicabilidade ≠ governança
├── OPEN_LETTER.md         # Carta aberta à comunidade
├── FAQ.md                 # Perguntas comuns
│
├── tutorials/             # ENSINO passo a passo
│   ├── 01_blackbox_problem.md
│   ├── 02_explainability_limits.md
│   ├── 03_operational_governance.md
│   ├── 04_tail_risk_cvar.md
│   ├── 05_metamorphic_tests.md
│   ├── 06_umjam_control.md
│   └── 07_end_to_end_example.md
│
├── openbox/                  # CÓDIGO (prova)
│   ├── omega_min/           # Núcleo mínimo certificável
│   ├── benchmark/           # Runner de benchmarks
│   └── integrations/        # Integrações com MatVerseChain
│
├── examples/                 # EXEMPLOS EXECUTÁVEIS
│   ├── simple_credit/
│   ├── noisy_classifier/
│   └── failure_containment/
│
├── diagrams/                 # DIAGRAMAS (PNG + Mermaid)
│   ├── governance_layers.png
│   ├── decision_flow.png
│   ├── umjam_control_loop.png
│   └── why_vs_governance.png
│
└── papers/                   # PAPERS / PREPRINTS
    └── omega_min_arxiv/
```

## Componentes Principais

### 🔧 Omega-Min (Núcleo Operacional)
- **Ledger append-only** com hash chaining para evidência
- **CVaR (Expected Shortfall)** para risco de cauda
- **Testes metamórficos** para robustez comportamental
- **Ω-GATE** para aprovação/degradação/bloqueio automático
- **Observabilidade básica** (latência, erros, drift)

### 🎯 UMJAM (Controle Dinâmico)
- **Controle afim externo**: `m_{t+1} = (I-K)m_t + KΘ`
- **Métricas**: CVaR, Ψ (Spearman), Ω-Score
- **Convergência garantida**: λ_max(K) < 1 em ≤5 iterações

### 📊 MatVerse Chain (Integração Blockchain)
- **PoSE/PoLE**: Proof of State/Execution no Ethereum
- **MatVerseScan**: Explorer público para auditoria
- **Ledger descentralizado** para governança global

## Instalação Rápida

```bash
# Clone o repositório
git clone https://github.com/MatVerse-U/MatVerse-U-OpenBox.git
cd MatVerse-U-OpenBox

# Setup do ambiente
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate
pip install -r requirements.txt

# Testes
pytest -q

# Executar servidor Omega-Min
uvicorn openbox.omega_min.api:app --host 0.0.0.0 --port 8000
```

## Exemplo Básico

```python
from openbox.omega_min import OmegaMinConfig, AppendOnlyLedger, cvar, omega_gate

# Configuração
config = OmegaMinConfig()
ledger = AppendOnlyLedger("ledger/decisions.jsonl")

# Avaliar sistema
losses = [0.1, 0.05, 0.2, 0.15, 0.08]
cvar_value = cvar(losses, alpha=0.95)

# Decisão de governança
decision = omega_gate(config, cvar_value, violation_rate=0.03)
print(f"Decisão: {decision.action}")
```

## Métricas de Governança

| Métrica | Descrição | Gate |
|---------|-----------|------|
| **CVaR** | Risco de cauda (Expected Shortfall) | ≤ 0.20 (allow), ≤ 0.25 (degrade) |
| **Ψ** | Coerência semântica (Spearman) | ≥ 0.995 |
| **Ω** | Antifragilidade global | ≥ 0.95 |
| **Θ** | Latência normalizada p95 | < 100ms |

## Aplicações Práticas

- **Sistemas Financeiros**: Controle de risco em modelos de crédito
- **Saúde**: Governança de sistemas de diagnóstico
- **Automotivo**: Validação de sistemas autônomos
- **Regulatório**: Auditoria de sistemas críticos

## Contribuindo

1. Leia primeiro: [CONTRIBUTING.md](./CONTRIBUTING.md)
2. Fork e clone o repositório
3. Crie uma branch para sua feature
4. Execute os testes: `pytest -q`
5. Submeta um pull request

## Licença

MIT License - veja [LICENSE](./LICENSE) para detalhes.

## Contato

- **Website**: https://matverse.org
- **Email**: contact@matverse.org
- **Discord**: https://discord.gg/matverse

---

*"Tornar-se inevitável por necessidade matemática e legal, não por força."*