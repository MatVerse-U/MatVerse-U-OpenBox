# Governança de IA: Definição Formal e Implementação

**Documento técnico formal sobre governança operacional de sistemas de IA, estabelecendo métricas, controles e evidências necessárias para conformidade regulatória.**

---

## Definição Formal de Governança de IA

### Definição
> **Governança de IA** é o conjunto de controles operacionais, métricas objetivas e evidências auditáveis que permitem controle, monitoramento e auditoria de sistemas de IA caixa-preta sem dependência de explicabilidade interna.

### Axiomas Fundamentais

#### Axioma 1: Independência da Explicabilidade
> A governança de sistemas de IA é **independente** da capacidade de explicar decisões individuais.

**Implicação**: Sistemas caixa-preta podem ser governados eficazmente sem entendimento interno.

#### Axioma 2: Controle Operacional > Compreensão Teórica
> **Controle operacional** em tempo real tem precedência sobre **compreensão teórica** pós-hoc.

**Implicação**: Métricas de controle são mais valiosas que explicações.

#### Axioma 3: Evidência Imutável > Interpretação Subjetiva
> **Evidência imutável** tem maior valor legal que **interpretação subjetiva**.

**Implicação**: Ledger + hash > SHAP values em tribunal.

## Arquitetura de Governança em Camadas

### Camada 1: Observabilidade (Observability Layer)

**Objetivo**: Monitoramento em tempo real de todos os aspectos operacionais.

#### Componentes

```python
class ObservabilityLayer:
    def __init__(self, config):
        self.metrics = MetricsCollector(config)
        self.telemetry = TelemetryCollector(config)
        self.drift = DriftDetector(config)
    
    def monitor(self, model, X, y, predictions):
        """Monitora sistema completo em tempo real."""
        # Métricas de performance
        latency = self.metrics.measure_latency(model, X)
        accuracy = self.metrics.measure_accuracy(predictions, y)
        error_rate = self.metrics.measure_error_rate(predictions, y)
        
        # Telemetria operacional
        memory_usage = self.telemetry.memory_usage()
        cpu_usage = self.telemetry.cpu_usage()
        throughput = self.telemetry.throughput()
        
        # Detecção de deriva
        drift_score = self.drift.detect(X, reference_data=config.reference_data)
        
        return {
            'performance': {'latency': latency, 'accuracy': accuracy, 'error_rate': error_rate},
            'telemetry': {'memory': memory_usage, 'cpu': cpu_usage, 'throughput': throughput},
            'drift': {'score': drift_score, 'status': self.drift.status()}
        }
```

#### Métricas Primárias

| Métrica | Definição | Gate | Observação |
|---------|-----------|------|------------|
| **Latência p95** | 95º percentil de tempo de resposta | < 100ms | SLA operacional |
| **Taxa de Erro** | % de predições incorretas | < 5% | Qualidade mínima |
| **Deriva de Dados** | Distributional shift | Score < 0.1 | Estabilidade |
| **Throughput** | Requests/segundo | > 1000 RPS | Capacidade |

### Camada 2: Controle (Control Layer)

**Objetivo**: Implementação de controles automáticos baseados em métricas objetivas.

#### 2.1 CVaR (Conditional Value at Risk)

```python
def compute_cvar_governance(losses: np.ndarray, alpha: float = 0.95) -> float:
    """
    CVaR para governança operacional de sistemas de IA.
    
    Mede o risco de cauda: perda média no pior α% dos casos.
    Essencial para governança porque quantifica risco extremo.
    """
    sorted_losses = np.sort(losses)
    var_index = int(alpha * len(sorted_losses))
    cvar_value = np.mean(sorted_losses[var_index:])
    
    return cvar_value

class CVaRGovernance:
    def __init__(self, alpha: float = 0.95, max_allow: float = 0.20):
        self.alpha = alpha
        self.max_allow = max_allow
    
    def evaluate(self, model, X, y):
        """Avalia sistema usando CVaR."""
        predictions = model.predict(X)
        losses = compute_losses(predictions, y)
        cvar_value = compute_cvar_governance(losses, self.alpha)
        
        # Decisão de governança baseada em CVaR
        if cvar_value <= self.max_allow:
            return "ALLOW", cvar_value
        elif cvar_value <= self.max_allow * 1.25:
            return "DEGRADE", cvar_value
        else:
            return "BLOCK", cvar_value
```

#### 2.2 Testes Metamórficos

```python
def metamorphic_tests_governance(model, X_test: np.ndarray) -> float:
    """
    Testes metamórficos para governança operacional.
    
    Testam robustez comportamental sem conhecer função interna.
    Fundamentação teórica: invariância sob transformações válidas.
    """
    test_transformations = [
        # Teste 1: Adição de ruído gaussiano mínimo
        lambda x: x + np.random.normal(0, 0.01, x.shape),
        
        # Teste 2: Permutação de features não correlacionadas
        lambda x: x[:, np.random.permutation(x.shape[1])],
        
        # Teste 3: Escalonamento dentro de limites válidos
        lambda x: x * np.random.uniform(0.95, 1.05, x.shape),
        
        # Teste 4: Adição de valores dentro do range observado
        lambda x: x + np.random.uniform(-0.1, 0.1, x.shape)
    ]
    
    predictions_original = model.predict(X_test)
    violation_count = 0
    
    for transformation in test_transformations:
        X_transformed = transformation(X_test)
        predictions_transformed = model.predict(X_transformed)
        
        # Teste de invariância: predições devem ser similares
        similarity = np.mean(np.abs(predictions_original - predictions_transformed))
        if similarity > 0.1:  # Threshold de tolerância
            violation_count += 1
    
    violation_rate = violation_count / len(test_transformations)
    return violation_rate
```

#### 2.3 UMJAM (Controle Afim Externo)

```python
class UMJAMController:
    """
    Controle afim externo para sistemas de IA.
    
    Implementa: m_{t+1} = (I-K)m_t + K*target
    
    Garante convergência se λ_max(K) < 1.
    """
    def __init__(self, target: float, convergence_rate: float = 0.1):
        self.target = target
        self.K = convergence_rate
        self.state = 0.0
    
    def update(self, observation: float) -> float:
        """Atualiza estado do controlador."""
        self.state = (1 - self.K) * self.state + self.K * self.target
        control_signal = self.state + self.K * (observation - self.target)
        return control_signal
    
    def converge(self, observations: List[float], max_iterations: int = 10) -> bool:
        """Testa convergência do controlador."""
        for i in range(max_iterations):
            obs = observations[i % len(observations)]
            self.update(obs)
        
        # Verifica se convergiu para target
        convergence_error = abs(self.state - self.target)
        return convergence_error < 0.01
```

### Camada 3: Evidência (Evidence Layer)

**Objetivo**: Criação de trilha imutável de auditoria para conformidade legal.

#### 3.1 Ledger Imutável com Hash Chaining

```python
import hashlib
import json
from datetime import datetime, timezone
from typing import Dict, Any

class AppendOnlyLedger:
    """
    Ledger append-only com hash chaining para evidência imutável.
    
    Cada entrada contém:
    - prev_hash: hash da entrada anterior
    - record_hash: hash desta entrada (sem o campo record_hash)
    - timestamp: UTC ISO format
    - data: dados da decisão
    """
    
    def __init__(self, path: str, hash_algorithm: str = "sha3_256"):
        self.path = path
        self.hash_algorithm = hash_algorithm
        self._ensure_file_exists()
    
    def _hash_data(self, data: bytes) -> str:
        """Calcula hash usando algoritmo especificado."""
        h = hashlib.new(self.hash_algorithm)
        h.update(data)
        return h.hexdigest()
    
    def _canonical_json(self, obj: Dict[str, Any]) -> bytes:
        """Canonical JSON: keys ordenadas, sem whitespace."""
        return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")
    
    def append(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Adiciona nova entrada ao ledger."""
        # Obtém hash da entrada anterior
        prev_hash = self._get_last_hash()
        
        # Prepara nova entrada
        record = {
            "prev_hash": prev_hash,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            **data
        }
        
        # Calcula hash da entrada (sem o campo record_hash)
        record_copy = record.copy()
        record_copy.pop("record_hash", None)
        record["record_hash"] = self._hash_data(self._canonical_json(record_copy))
        
        # Escreve no arquivo
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False) + "\\n")
        
        return record
    
    def verify(self) -> bool:
        """Verifica integridade do ledger."""
        prev_hash = "GENESIS"
        
        if not os.path.exists(self.path) or os.path.getsize(self.path) == 0:
            return True
        
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip():
                    continue
                
                record = json.loads(line)
                
                # Verifica cadeia de hash
                if record.get("prev_hash") != prev_hash:
                    return False
                
                # Verifica hash da entrada
                record_copy = record.copy()
                expected_hash = record_copy.pop("record_hash")
                calculated_hash = self._hash_data(self._canonical_json(record_copy))
                
                if expected_hash != calculated_hash:
                    return False
                
                prev_hash = expected_hash
        
        return True
    
    def _get_last_hash(self) -> str:
        """Obtém hash da última entrada."""
        if not os.path.exists(self.path) or os.path.getsize(self.path) == 0:
            return "GENESIS"
        
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    last_record = json.loads(line)
        
        return last_record.get("record_hash", "GENESIS")
```

#### 3.2 PoSE/PoLE (Proof of State/Execution)

```python
class PosePoleRegistry:
    """
    Registro PoSE/PoLE para integração com blockchain.
    
    PoSE: Proof of State - registro imutável do estado
    PoLE: Proof of Life - registro de execução + métricas
    """
    
    def __init__(self, blockchain_config):
        self.blockchain = BlockchainInterface(blockchain_config)
        self.ledger = AppendOnlyLedger("pose_pole_ledger.jsonl")
    
    def register_pose(self, model_hash: str, metadata: Dict[str, Any]) -> str:
        """Registra PoSE (Proof of State)."""
        pose_record = {
            "type": "PoSE",
            "model_hash": model_hash,
            "metadata": metadata,
            "block_height": self.blockchain.get_block_height()
        }
        
        tx_hash = self.blockchain.submit_transaction(pose_record)
        pose_record["tx_hash"] = tx_hash
        
        self.ledger.append(pose_record)
        return tx_hash
    
    def register_pole(self, execution_hash: str, metrics: Dict[str, float]) -> str:
        """Registra PoLE (Proof of Life + Execution)."""
        pole_record = {
            "type": "PoLE",
            "execution_hash": execution_hash,
            "metrics": metrics,
            "block_height": self.blockchain.get_block_height()
        }
        
        tx_hash = self.blockchain.submit_transaction(pole_record)
        pole_record["tx_hash"] = tx_hash
        
        self.ledger.append(pole_record)
        return tx_hash
```

## Sistema de Decisões (Ω-GATE)

```python
class OmegaGate:
    """
    Ω-GATE: Sistema de decisões de governança.
    
    Combina múltiplas métricas para decisão final:
    - CVaR (risco de cauda)
    - Testes metamórficos (robustez)
    - Latência (performance)
    - Deriva (estabilidade)
    """
    
    def __init__(self, config: GovernanceConfig):
        self.config = config
        self.weights = config.omega_weights
    
    def decide(self, metrics: Dict[str, float]) -> Dict[str, Any]:
        """Decisão final de governança."""
        
        # Normaliza métricas (0 = pior, 1 = melhor)
        normalized_metrics = self._normalize_metrics(metrics)
        
        # Calcula score Ω (antifragilidade)
        omega_score = sum(
            normalized_metrics[metric] * weight 
            for metric, weight in self.weights.items()
        )
        
        # Decisão baseada em thresholds
        if omega_score >= 0.8:
            action = "ALLOW"
        elif omega_score >= 0.6:
            action = "DEGRADE"
        else:
            action = "BLOCK"
        
        # Gera justificativa
        justification = self._generate_justification(metrics, omega_score, action)
        
        return {
            "action": action,
            "omega_score": omega_score,
            "justification": justification,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    
    def _normalize_metrics(self, metrics: Dict[str, float]) -> Dict[str, float]:
        """Normaliza métricas para [0,1]."""
        normalized = {}
        
        # CVaR: menor é melhor
        if "cvar" in metrics:
            normalized["cvar"] = max(0, 1 - metrics["cvar"] / self.config.cvar_threshold)
        
        # Metamórfico: menor é melhor
        if "metamorphic_violations" in metrics:
            normalized["metamorphic_violations"] = max(0, 1 - metrics["metamorphic_violations"] / self.config.metamorphic_threshold)
        
        # Latência: menor é melhor
        if "latency_p95" in metrics:
            normalized["latency_p95"] = max(0, 1 - metrics["latency_p95"] / self.config.latency_threshold)
        
        # Deriva: menor é melhor
        if "drift_score" in metrics:
            normalized["drift_score"] = max(0, 1 - metrics["drift_score"] / self.config.drift_threshold)
        
        return normalized
    
    def _generate_justification(self, metrics: Dict[str, float], omega_score: float, action: str) -> str:
        """Gera justificativa textual da decisão."""
        violations = []
        
        if metrics.get("cvar", 0) > self.config.cvar_threshold:
            violations.append(f"CVaR excede limite: {metrics['cvar']:.3f}")
        
        if metrics.get("metamorphic_violations", 0) > self.config.metamorphic_threshold:
            violations.append(f"Violações metamórficas: {metrics['metamorphic_violations']:.3f}")
        
        if metrics.get("latency_p95", 0) > self.config.latency_threshold:
            violations.append(f"Latência alta: {metrics['latency_p95']:.2f}ms")
        
        if violations:
            return f"Decisão {action}: " + "; ".join(violations)
        else:
            return f"Decisão {action}: Sistema dentro de parâmetros normais"
```

## Configuração e Deploy

```python
# Configuração completa de governança
governance_config = {
    # CVaR
    "cvar_alpha": 0.95,
    "cvar_max_allow": 0.20,
    "cvar_max_degrade": 0.25,
    
    # Testes metamórficos
    "metamorphic_max_violation_rate_allow": 0.05,
    "metamorphic_max_violation_rate_degrade": 0.10,
    
    # Performance
    "latency_threshold_ms": 100.0,
    "error_rate_threshold": 0.05,
    
    # Deriva
    "drift_threshold": 0.1,
    
    # UMJAM
    "umjam_target": 0.05,
    "umjam_convergence_rate": 0.1,
    
    # Ledger
    "ledger_path": "governance_ledger.jsonl",
    "hash_algorithm": "sha3_256",
    
    # Ω-GATE weights
    "omega_weights": {
        "cvar": 0.4,
        "metamorphic_violations": 0.3,
        "latency_p95": 0.2,
        "drift_score": 0.1
    }
}

# Deploy do sistema completo
def deploy_governance_system(model, config):
    """Deploy completo do sistema de governança."""
    
    # Inicializa camadas
    observability = ObservabilityLayer(config)
    cvar_governance = CVaRGovernance(config.cvar_alpha, config.cvar_max_allow)
    metamorphic_tests = MetamorphicTestSuite(config)
    umjam = UMJAMController(config.umjam_target, config.umjam_convergence_rate)
    ledger = AppendOnlyLedger(config.ledger_path, config.hash_algorithm)
    omega_gate = OmegaGate(config)
    
    # Sistema integrado
    def govern_system(X, y):
        # Camada 1: Observabilidade
        observations = observability.monitor(model, X, y, model.predict(X))
        
        # Camada 2: Controle
        cvar_decision, cvar_value = cvar_governance.evaluate(model, X, y)
        metamorphic_violation_rate = metamorphic_tests.evaluate(model, X)
        umjam.update(observations['performance']['accuracy'])
        
        # Camada 3: Evidência
        governance_metrics = {
            "cvar": cvar_value,
            "metamorphic_violations": metamorphic_violation_rate,
            "latency_p95": observations['performance']['latency'],
            "drift_score": observations['drift']['score']
        }
        
        final_decision = omega_gate.decide(governance_metrics)
        
        # Registra evidência
        ledger.append({
            "decision": final_decision,
            "metrics": governance_metrics,
            "observations": observations
        })
        
        return final_decision
    
    return govern_system
```

## Métricas de Conformidade Regulatória

### GDPR/AI Act Compliance

| Requisito | Implementação OpenBox | Evidência |
|-----------|----------------------|-----------|
| **Auditabilidade** | Ledger imutável + hash chaining | Arquivo JSONL verificável |
| **Transparência** | Métricas públicas + PoSE/PoLE | Transações blockchain |
| **Responsabilidade** | Decisões automáticas documentadas | Trilha completa de auditoria |
| **Controle** | Ω-GATE com thresholds | Logs de decisões |
| **Robustez** | Testes metamórficos | Relatórios de violação |

### ISO/IEC 23053 (AI Risk Management)

| Controle | Implementação | Métrica |
|----------|---------------|---------|
| **Risco Operacional** | CVaR dinâmico | CVaR@95% ≤ 0.20 |
| **Robustez** | Testes metamórficos | Taxa violação ≤ 5% |
| **Monitoramento** | Observabilidade em tempo real | p95 < 100ms |
| **Deriva** | Detector automático | Score < 0.1 |
| **Evidência** | Ledger + blockchain | 100% verificável |

## Conclusão

**Governança ≠ Explicabilidade**

Este documento estabelece os fundamentos técnicos para governança operacional de sistemas de IA sem dependência de explicabilidade interna. A implementação demonstra que:

1. **Controle operacional** é mais valioso que compreensão teórica
2. **Evidência imutável** tem maior valor legal que interpretações
3. **Métricas objetivas** permitem auditoria automatizada
4. **Sistemas caixa-preta** podem ser governados eficazmente

**Próximo passo**: Explore os [tutoriais](./tutorials/) para implementação prática.