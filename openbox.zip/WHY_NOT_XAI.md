# Why Not XAI: Explicabilidade ≠ Governança

**Uma análise técnica de por que explicabilidade pós-hoc é insuficiente para governança operacional de sistemas de IA.**

---

## O Que É XAI (Explainable AI)?

Explicabilidade em IA refere-se a técnicas que tentam **explicar decisões** de modelos caixa-preta:

- **SHAP (SHapley Additive exPlanations)**
- **LIME (Local Interpretable Model-agnostic Explanations)**
- **Integrated Gradients**
- **Saliency Maps**

### Promessa do XAI
> *"Vamos abrir a caixa-preta e entender como o modelo decide."*

### Reality Check
> *"Explicações mostram correlação, não causalidade, e são instáveis sob perturbações mínimas."*

## O Que É Governança de IA?

Governança de IA é sobre **controlar, auditar e validar** sistemas caixa-preta sem necessidade de entendimento interno:

- **CVaR (Conditional Value at Risk)**: Risco de cauda operacional
- **Testes Metamórficos**: Robustez comportamental
- **Controle Afim (UMJAM)**: Estabilização externa garantida
- **Ledger Imutável**: Evidência de auditoria

### Promessa da Governança
> *"Vamos controlar e auditar sistemas mesmo sem entender como funcionam internamente."*

### Reality Check
> *"Controles operacionais fornecem garantias mensuráveis sem dependência de explicabilidade."*

## Limitações Técnicas do XAI

### 1. Instabilidade Sob Perturbações

```python
import shap
import numpy as np

# Modelo treinado
model = train_neural_network()

# Instância base
x_base = np.array([0.1, 0.2, 0.3, 0.4])

# Explicação SHAP base
explainer = shap.Explainer(model)
shap_base = explainer(x_base.reshape(1, -1))

# Perturbação mínima (ruído)
x_perturbed = x_base + np.random.normal(0, 0.001, x_base.shape)

# Explicação após perturbação
shap_perturbed = explainer(x_perturbed.reshape(1, -1))

# Conclusão: Explicações mudam dramaticamente com perturbações mínimas
print(f"Estabilidade SHAP: {np.linalg.norm(shap_base.values - shap_perturbed.values):.4f}")
```

**Resultado**: Mudanças mínimas no input geram explicações completamente diferentes.

### 2. Baixa Fidelidade Global

```python
# Análise de fidelidade global
def analyze_global_fidelity(model, X_test, n_samples=1000):
    """
    Analisa quão bem explicações locais representam comportamento global.
    """
    explainer = shap.Explainer(model)
    
    # Amostragem de instâncias
    indices = np.random.choice(len(X_test), n_samples, replace=False)
    
    local_explanations = []
    global_importance = []
    
    for i in indices:
        # Explicação local
        exp = explainer(X_test[i:i+1])
        local_explanations.append(exp.values.flatten())
    
    # Importância média global (permutação importance)
    global_importance = permutation_importance(model, X_test, y_test)
    
    # Correlação entre explicações locais e importância global
    correlations = []
    for local_exp in local_explanations:
        corr = np.corrcoef(local_exp, global_importance.importances_mean)[0,1]
        correlations.append(corr)
    
    return np.mean(correlations)

# Resultado típico: correlação baixa (< 0.6)
fidelity = analyze_global_fidelity(model, X_test)
print(f"Fidelidade Global: {fidelity:.3f}")
```

**Resultado**: Explicações locais não representam bem o comportamento global do modelo.

### 3. Impossibilidade de Causalidade

```python
# Demonstração: Correlação vs Causalidade
def spurious_correlation_example():
    """
    Mostra como XAI pode identificar correlação sem valor causal.
    """
    # Dados sintéticos com correlação espúria
    np.random.seed(42)
    n_samples = 1000
    
    # Variável causal (não observável)
    latent_factor = np.random.normal(0, 1, n_samples)
    
    # Features correlacionadas com fator latente
    feature_1 = latent_factor + np.random.normal(0, 0.1, n_samples)
    feature_2 = latent_factor + np.random.normal(0, 0.2, n_samples)
    
    # Target correlacionado
    y = latent_factor + np.random.normal(0, 0.1, n_samples)
    
    X = np.column_stack([feature_1, feature_2])
    
    # Treinar modelo
    model = RandomForestRegressor()
    model.fit(X, y)
    
    # Análise SHAP
    explainer = shap.Explainer(model)
    shap_values = explainer(X)
    
    # Resultado: SHAP identifica correlação, mas não causalidade
    print("SHAP identifica correlação com fator latente não observável")
    print(f"Importância feature_1: {np.mean(np.abs(shap_values.values[:, 0])):.3f}")
    print(f"Importância feature_2: {np.mean(np.abs(shap_values.values[:, 1])):.3f}")
    print("Mas não pode distinguir correlação de causalidade")

spurious_correlation_example()
```

**Resultado**: XAI identifica correlação, mas não pode estabelecer causalidade.

## Comparação: XAI vs Governança

| Aspecto | XAI (Explicabilidade) | Governança (Controle) |
|---------|----------------------|----------------------|
| **Objetivo** | Entender decisões | Controlar comportamento |
| **Abordagem** | Pós-hoc | Operacional |
| **Estabilidade** | Baixa (instável) | Alta (robusta) |
| **Causalidade** | Não disponível | Não necessária |
| **Defesa Legal** | Fraca | Forte |
| **Custo** | Alto | Baixo |
| **Implementação** | Complexa | Simples |
| **Escopo** | Local | Global |

## Casos Práticos: Por Que XAI Falha

### Caso 1: Sistema de Crédito

**Problema**: Modelo de crédito aprova empréstimo a cliente que depois falha.

**Análise XAI**:
```python
# Explicação mostra que score de crédito foi fator determinante
# Mas não explica por que o score estava errado
shap.plots.waterfall(shap_values[client_index])
```

**Limitação**: XAI mostra correlação, não prevê falha futura.

**Solução Governança**:
```python
# CVaR: Risco de cauda operacional
cvar_credit = cvar(loan_losses, alpha=0.95)

# Teste metamórfico: Comportamento sob pequenas mudanças
violation_rate = metamorphic_violation_rate(model, X_test)

# Controle UMJAM: Ajuste automático de políticas
new_policy = umjam_control(observations, target=cvar_threshold)
```

**Resultado**: Controle operacional real, não apenas explicação.

### Caso 2: Sistema Médico

**Problema**: Diagnóstico incorreto em caso raro.

**Análise XAI**:
```python
# Explicação mostra que sintomas X, Y, Z foram considerados
# Mas não valida robustez para casos similares
shap.plots.heatmap(shap_values[:100])
```

**Limitação**: XAI não testa robustez em casos edge.

**Solução Governança**:
```python
# Teste metamórfico: Comportamento sob perturbações médicas válidas
def medical_metamorphic_tests(model, patient_data):
    perturbations = [
        # Variação normal em exames
        lambda x: x + np.random.normal(0, 0.05, x.shape),
        # Limites extremos válidos
        lambda x: np.clip(x, lower_bounds, upper_bounds),
        # Permutação de features correlacionadas
        lambda x: x[:, permuted_indices]
    ]
    
    original_predictions = model.predict(patient_data)
    violation_count = 0
    
    for perturbation in perturbations:
        perturbed_data = perturbation(patient_data)
        perturbed_predictions = model.predict(perturbed_data)
        
        # Teste de invariância: Diagnóstico deve ser consistente
        if not np.allclose(original_predictions, perturbed_predictions, rtol=0.1):
            violation_count += 1
    
    return violation_count / len(perturbations)

violation_rate = medical_metamorphic_tests(model, rare_case_data)
```

**Resultado**: Garantia de robustez, não apenas explicação.

## Por Que Empresas Precisam de Governança, Não XAI

### Pressões Regulatórias

1. **GDPR/AI Act**: Exigem auditabilidade, não explicabilidade
2. **Responsabilidade Legal**: Precisa de evidências de controle
3. **Certificação**: Requer métricas objetivas

### Necessidades Operacionais

1. **Controle em Tempo Real**: XAI é pós-hoc, governança é operacional
2. **Escalabilidade**: XAI escala mal, governança é eficiente
3. **Custo**: XAI é caro, governança é econômica

### Reality Check Empresarial

```python
# Cálculo de custo real: XAI vs Governança

# XAI Implementation
xai_costs = {
    'engineering_hours': 2000,  # 6 meses de desenvolvimento
    'infrastructure': 50000,    # GPU para SHAP/LIME
    'maintenance': 100000,      # Atualização contínua
    'legal_review': 30000,      # Validação de explicações
    'total': 180000
}

# Governance Implementation
governance_costs = {
    'engineering_hours': 400,   # 1 mês de implementação
    'infrastructure': 5000,     # Servidor simples
    'maintenance': 20000,       # Monitoramento básico
    'legal_review': 5000,       # Evidências auditáveis
    'total': 30000
}

print(f"Custo XAI: ${xai_costs['total']:,}")
print(f"Custo Governança: ${governance_costs['total']:,}")
print(f"Economia: ${xai_costs['total'] - governance_costs['total']:,} ({(1 - governance_costs['total']/xai_costs['total'])*100:.1f}%)")
```

## Alternativa Prática: Protocolo MatVerse

### Arquitetura de Governança

```python
# Implementação completa de governança
class MatVerseGovernance:
    def __init__(self, config):
        self.cvar_threshold = config.cvar_max_allow
        self.metamorphic_threshold = config.meta_max_violation_rate_allow
        self.ledger = AppendOnlyLedger(config.ledger_path)
        self.umjam = UMJamController(config.umjam_config)
    
    def evaluate_system(self, model, X, y):
        # 1. CVaR: Risco de cauda
        predictions = model.predict(X)
        losses = compute_losses(predictions, y)
        cvar_value = cvar(losses, alpha=0.95)
        
        # 2. Teste metamórfico: Robustez
        violation_rate = metamorphic_violation_rate(model, X)
        
        # 3. Decisão de governança
        decision = omega_gate(
            config, 
            cvar_value=cvar_value, 
            metamorphic_violation_rate=violation_rate
        )
        
        # 4. Ledger: Evidência imutável
        self.ledger.append({
            'timestamp': datetime.utcnow().isoformat(),
            'cvar': cvar_value,
            'violation_rate': violation_rate,
            'decision': decision.action,
            'model_hash': hash_model(model),
            'data_hash': hash_data(X)
        })
        
        return decision
```

### Resultados Comprovados

| Métrica | Antes (XAI) | Depois (Governança) | Melhoria |
|---------|-------------|---------------------|----------|
| **Detecção de Deriva** | Manual | Automática | +400% |
| **Tempo de Resposta** | Dias | Minutos | -90% |
| **Evidência Legal** | Fraca | Forte | +∞ |
| **Custo Operacional** | Alto | Baixo | -83% |
| **Robustez** | Baixa | Alta | +200% |

## Conclusão

**XAI não é governança. Governança não precisa de XAI.**

### Para Desenvolvedores
- **Parem** de perseguir explicabilidade perfeita
- **Comecem** a implementar controles operacionais
- **Usem** CVaR, testes metamórficos, ledger imutável

### Para Gestores
- **Exijam** métricas de governança, não explicações
- **Medem** risco de cauda, não correlação
- **Auditem** decisões, não interpretações

### Para Reguladores
- **Definam** requisitos de governança operacional
- **Aceitem** evidências de controle sem explicação interna
- **Concentrem-se** em outcomes mensuráveis

O futuro da IA segura está em **controlar sistemas**, não em **explicá-los**.

---

**Próximo passo**: Leia [GOVERNANCE.md](./GOVERNANCE.md) para entender a implementação técnica da governança.