"""
Implementação de CVaR (Conditional Value at Risk) para governança de IA.

CVaR (Expected Shortfall) é uma métrica fundamental para governança
operacional porque quantifica risco de cauda sem depender de
explicabilidade interna dos modelos.
"""

import numpy as np
from typing import Iterable, Union, List, Dict, Any
from scipy import stats


def cvar(losses: Iterable[float], alpha: float = 0.95) -> float:
    """
    Calcula CVaR (Conditional Value at Risk / Expected Shortfall).
    
    CVaR é a perda esperada no pior α% dos casos. É mais robusto que
    VaR porque considera a magnitude das perdas extremas, não apenas
    o ponto de corte.
    
    Fórmula: CVaR_α = E[L | L ≥ VaR_α]
    onde L são as perdas e VaR_α é o quantil α.
    
    Args:
        losses: Iterable de perdas (maior = pior)
        alpha: Nível de confiança (0.5 a 0.999)
    
    Returns:
        CVaR (Expected Shortfall)
    
    Raises:
        ValueError: Se alpha fora do range válido ou losses vazio
    """
    # Validar entrada
    if not 0.5 <= alpha <= 0.999:
        raise ValueError(f"alpha deve estar entre 0.5 e 0.999, recebido: {alpha}")
    
    # Converter para numpy array
    x = np.asarray(list(losses), dtype=float)
    
    if len(x) == 0:
        raise ValueError("Array de perdas não pode estar vazio")
    
    # Ordenar perdas (maior para menor)
    sorted_losses = np.sort(x)[::-1]
    
    # Índice do VaR (percentil alpha)
    var_index = int(alpha * len(sorted_losses))
    
    # CVaR = média das perdas no pior α%
    if var_index < len(sorted_losses):
        cvar_value = np.mean(sorted_losses[:var_index + 1])
    else:
        cvar_value = np.mean(sorted_losses)
    
    return float(cvar_value)


def var(losses: Iterable[float], alpha: float = 0.95) -> float:
    """
    Calcula VaR (Value at Risk).
    
    VaR é o quantil alpha das perdas.
    
    Args:
        losses: Iterable de perdas
        alpha: Nível de confiança
    
    Returns:
        VaR (quantil alpha)
    """
    x = np.asarray(list(losses), dtype=float)
    
    if len(x) == 0:
        raise ValueError("Array de perdas não pode estar vazio")
    
    return float(np.quantile(x, alpha))


def cvar_portfolio(returns: np.ndarray, weights: np.ndarray, alpha: float = 0.95) -> float:
    """
    Calcula CVaR de um portfolio com retornos e pesos.
    
    Args:
        returns: Matriz de retornos (n_samples, n_assets)
        weights: Pesos dos ativos
        alpha: Nível de confiança
    
    Returns:
        CVaR do portfolio
    """
    # Calcular retornos do portfolio
    portfolio_returns = returns @ weights
    
    # Perdas são retornos negativos
    portfolio_losses = -portfolio_returns
    
    return cvar(portfolio_losses, alpha)


def cvar_time_series(returns: np.ndarray, window: int = 252, alpha: float = 0.95) -> np.ndarray:
    """
    Calcula CVaR em janelas deslizantes para séries temporais.
    
    Args:
        returns: Série temporal de retornos
        window: Tamanho da janela (default: 252 dias = 1 ano)
        alpha: Nível de confiança
    
    Returns:
        Array de CVaR por janela
    """
    cvar_series = []
    
    for i in range(window, len(returns)):
        window_returns = returns[i-window:i]
        window_losses = -window_returns
        cvar_value = cvar(window_losses, alpha)
        cvar_series.append(cvar_value)
    
    return np.array(cvar_series)


class CVaRMonitor:
    """
    Monitor CVaR para governança de IA em tempo real.
    
    Monitora CVaR de sistemas de IA e gera alertas quando
    o risco de cauda excede thresholds definidos.
    """
    
    def __init__(self, alpha: float = 0.95, max_allow: float = 0.20, max_degrade: float = 0.25):
        """
        Inicializa monitor CVaR.
        
        Args:
            alpha: Nível de confiança
            max_allow: CVaR máximo permitido (sistema aprovado)
            max_degrade: CVaR máximo para degradação (acima disso bloqueia)
        """
        self.alpha = alpha
        self.max_allow = max_allow
        self.max_degrade = max_degrade
        
        # Histórico para trending
        self.cvar_history = []
        self.decision_history = []
        self.loss_history = []
    
    def compute_losses(self, predictions: np.ndarray, y_true: np.ndarray, 
                      loss_type: str = "binary") -> np.ndarray:
        """
        Calcula perdas baseadas no tipo de problema.
        
        Args:
            predictions: Predições do modelo
            y_true: Valores verdadeiros
            loss_type: Tipo de perda ("binary", "regression", "custom")
        
        Returns:
            Array de perdas
        """
        if loss_type == "binary":
            # Perda binária (0/1)
            losses = (predictions != y_true).astype(float)
        
        elif loss_type == "regression":
            # Perda de regressão (erro absoluto)
            losses = np.abs(predictions - y_true)
        
        elif loss_type == "weighted_binary":
            # Perda binária ponderada
            losses = (predictions != y_true).astype(float)
            # Aplicar pesos baseados em confiança se disponível
            if hasattr(predictions, 'confidence') or len(predictions.shape) > 1:
                try:
                    if len(predictions.shape) > 1:
                        max_proba = np.max(predictions, axis=1)
                        losses = losses * (1 - max_proba)
                except:
                    pass
        
        else:
            raise ValueError(f"Tipo de perda não suportado: {loss_type}")
        
        return losses
    
    def evaluate(self, model, X: np.ndarray, y: np.ndarray, 
                loss_type: str = "binary") -> Dict[str, Any]:
        """
        Avalia sistema usando CVaR.
        
        Args:
            model: Modelo a ser avaliado
            X: Features
            y: Labels verdadeiros
            loss_type: Tipo de perda
        
        Returns:
            Dict com resultado da avaliação
        """
        # Fazer predições
        predictions = model.predict(X)
        
        # Calcular perdas
        losses = self.compute_losses(predictions, y, loss_type)
        
        # Calcular CVaR
        cvar_value = cvar(losses, self.alpha)
        
        # Decisão baseada em thresholds
        if cvar_value <= self.max_allow:
            decision = "ALLOW"
        elif cvar_value <= self.max_degrade:
            decision = "DEGRADE"
        else:
            decision = "BLOCK"
        
        # Armazenar histórico
        self.cvar_history.append(cvar_value)
        self.decision_history.append(decision)
        self.loss_history.extend(losses)
        
        # Manter apenas últimos 1000 valores
        if len(self.cvar_history) > 1000:
            self.cvar_history = self.cvar_history[-1000:]
            self.decision_history = self.decision_history[-1000:]
        
        # Análise de trending
        trending = self._analyze_trending()
        
        return {
            'cvar': cvar_value,
            'var': var(losses, self.alpha),
            'decision': decision,
            'alpha': self.alpha,
            'threshold_allow': self.max_allow,
            'threshold_degrade': self.max_degrade,
            'trending': trending,
            'statistics': {
                'mean_cvar': np.mean(self.cvar_history[-100:]),
                'std_cvar': np.std(self.cvar_history[-100:]),
                'recent_decisions': self._get_decision_distribution(),
                'total_evaluations': len(self.cvar_history),
                'total_losses': len(self.loss_history),
                'mean_loss': np.mean(self.loss_history[-1000:]) if self.loss_history else 0,
                'loss_std': np.std(self.loss_history[-1000:]) if self.loss_history else 0
            }
        }
    
    def _analyze_trending(self) -> Dict[str, Any]:
        """Analisa trending do CVaR."""
        
        if len(self.cvar_history) < 10:
            return {'status': 'insufficient_data'}
        
        recent_values = np.array(self.cvar_history[-20:])
        
        # Tendência linear
        x = np.arange(len(recent_values))
        slope = np.polyfit(x, recent_values, 1)[0]
        
        # Volatilidade
        volatility = np.std(recent_values)
        
        # Classificar tendência
        if slope > 0.01 and volatility < 0.05:
            trend = 'improving'
        elif slope < -0.01 and volatility < 0.05:
            trend = 'deteriorating'
        elif volatility > 0.1:
            trend = 'volatile'
        else:
            trend = 'stable'
        
        return {
            'trend': trend,
            'slope': slope,
            'volatility': volatility,
            'direction': 'increasing' if slope > 0 else 'decreasing'
        }
    
    def _get_decision_distribution(self) -> Dict[str, float]:
        """Obtém distribuição de decisões recentes."""
        
        recent_decisions = self.decision_history[-50:]
        
        if not recent_decisions:
            return {}
        
        total = len(recent_decisions)
        distribution = {
            'ALLOW': recent_decisions.count('ALLOW') / total,
            'DEGRADE': recent_decisions.count('DEGRADE') / total,
            'BLOCK': recent_decisions.count('BLOCK') / total
        }
        
        return distribution
    
    def get_risk_metrics(self) -> Dict[str, Any]:
        """
        Obtém métricas de risco detalhadas.
        
        Returns:
            Dict com métricas de risco
        """
        if not self.loss_history:
            return {'status': 'no_data'}
        
        losses_array = np.array(self.loss_history[-1000:])  # Últimas 1000 perdas
        
        return {
            'mean': float(np.mean(losses_array)),
            'median': float(np.median(losses_array)),
            'std': float(np.std(losses_array)),
            'min': float(np.min(losses_array)),
            'max': float(np.max(losses_array)),
            'skewness': float(stats.skew(losses_array)),
            'kurtosis': float(stats.kurtosis(losses_array)),
            'cvar_90': cvar(losses_array, 0.90),
            'cvar_95': cvar(losses_array, 0.95),
            'cvar_99': cvar(losses_array, 0.99),
            'var_95': var(losses_array, 0.95),
            'var_99': var(losses_array, 0.99)
        }
    
    def detect_anomalies(self, threshold_std: float = 3.0) -> List[Dict[str, Any]]:
        """
        Detecta anomalias no CVaR usando z-score.
        
        Args:
            threshold_std: Threshold em desvios padrão
        
        Returns:
            Lista de anomalias detectadas
        """
        if len(self.cvar_history) < 20:
            return []
        
        recent_cvar = np.array(self.cvar_history[-100:])
        mean_cvar = np.mean(recent_cvar)
        std_cvar = np.std(recent_cvar)
        
        anomalies = []
        for i, cvar_value in enumerate(self.cvar_history[-20:], 0):
            z_score = abs(cvar_value - mean_cvar) / std_cvar
            
            if z_score > threshold_std:
                anomalies.append({
                    'index': len(self.cvar_history) - 20 + i,
                    'cvar': cvar_value,
                    'z_score': z_score,
                    'severity': 'high' if z_score > 4.0 else 'medium'
                })
        
        return anomalies
    
    def plot_risk_profile(self, save_path: str = None):
        """
        Plota perfil de risco do CVaR.
        
        Args:
            save_path: Caminho para salvar o gráfico
        """
        try:
            import matplotlib.pyplot as plt
            import seaborn as sns
            
            # Configurar estilo
            plt.style.use('seaborn-v0_8')
            sns.set_palette("husl")
            
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            
            # Subplot 1: CVaR ao longo do tempo
            axes[0, 0].plot(self.cvar_history, 'b-', alpha=0.7, label='CVaR')
            axes[0, 0].axhline(y=self.max_allow, color='g', linestyle='--', label='Allow Threshold')
            axes[0, 0].axhline(y=self.max_degrade, color='orange', linestyle='--', label='Degrade Threshold')
            axes[0, 0].set_xlabel('Avaliação')
            axes[0, 0].set_ylabel('CVaR')
            axes[0, 0].set_title('CVaR ao Longo do Tempo')
            axes[0, 0].legend()
            axes[0, 0].grid(True, alpha=0.3)
            
            # Subplot 2: Distribuição de perdas
            if self.loss_history:
                recent_losses = self.loss_history[-1000:]
                axes[0, 1].hist(recent_losses, bins=30, alpha=0.7, edgecolor='black')
                axes[0, 1].axvline(x=np.mean(recent_losses), color='r', linestyle='--', label='Média')
                axes[0, 1].axvline(x=cvar(recent_losses, self.alpha), color='g', linestyle='--', label=f'CVaR {self.alpha}')
                axes[0, 1].set_xlabel('Perdas')
                axes[0, 1].set_ylabel('Frequência')
                axes[0, 1].set_title('Distribuição de Perdas')
                axes[0, 1].legend()
                axes[0, 1].grid(True, alpha=0.3)
            
            # Subplot 3: Box plot por decisão
            if len(self.decision_history) > 0:
                recent_data = list(zip(self.decision_history[-100:], self.cvar_history[-100:]))
                
                allow_cvars = [cvar for decision, cvar in recent_data if decision == 'ALLOW']
                degrade_cvars = [cvar for decision, cvar in recent_data if decision == 'DEGRADE']
                block_cvars = [cvar for decision, cvar in recent_data if decision == 'BLOCK']
                
                data_to_plot = []
                labels = []
                
                if allow_cvars:
                    data_to_plot.append(allow_cvars)
                    labels.append('Allow')
                
                if degrade_cvars:
                    data_to_plot.append(degrade_cvars)
                    labels.append('Degrade')
                
                if block_cvars:
                    data_to_plot.append(block_cvars)
                    labels.append('Block')
                
                if data_to_plot:
                    axes[1, 0].boxplot(data_to_plot, labels=labels)
                    axes[1, 0].set_ylabel('CVaR')
                    axes[1, 0].set_title('CVaR por Decisão')
                    axes[1, 0].grid(True, alpha=0.3)
            
            # Subplot 4: Distribuição de decisões
            recent_decisions = self.decision_history[-50:]
            if recent_decisions:
                decision_counts = {}
                for decision in recent_decisions:
                    decision_counts[decision] = decision_counts.get(decision, 0) + 1
                
                axes[1, 1].pie(decision_counts.values(), labels=decision_counts.keys(), autopct='%1.1f%%')
                axes[1, 1].set_title('Distribuição de Decisões (Últimas 50)')
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                print(f"Gráfico salvo em: {save_path}")
            
            plt.show()
            
        except ImportError:
            print("matplotlib e/ou seaborn não estão disponíveis. Instale com: pip install matplotlib seaborn")


# Função de conveniência para avaliação rápida
def quick_cvar_evaluation(model, X, y, alpha: float = 0.95) -> float:
    """
    Avaliação rápida de CVaR para uso em testes.
    
    Args:
        model: Modelo a avaliar
        X: Features
        y: Labels
        alpha: Nível de confiança
    
    Returns:
        Valor CVaR
    """
    predictions = model.predict(X)
    losses = (predictions != y).astype(float)
    return cvar(losses, alpha)