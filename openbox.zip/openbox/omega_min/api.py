"""
API FastAPI para integração do Omega-Min.

Fornece endpoints REST para:
- Avaliação de sistemas de IA
- Consulta de métricas
- Gestão do ledger
- Status do sistema
"""

from fastapi import FastAPI, HTTPException, BackgroundTasks, Depends
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional
import uvicorn
import numpy as np
from datetime import datetime, timezone
import logging

# Importar componentes do Omega-Min
from .config import OmegaMinConfig, get_config
from .ledger import AppendOnlyLedger
from .risk import CVaRMonitor, cvar
from .gate import OmegaGate, GateResult


# Configurar logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Criar aplicação FastAPI
app = FastAPI(
    title="Omega-Min API",
    description="API para governança de IA sem dependência de explicabilidade",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Instância global da configuração
config = get_config()

# Componentes globais
ledger = AppendOnlyLedger(config.ledger_path, config.hash_alg)
cvar_monitor = CVaRMonitor(
    alpha=config.cvar_alpha,
    max_allow=config.cvar_max_allow,
    max_degrade=config.cvar_max_degrade
)

omega_gate = OmegaGate(config.omega_weights, config.omega_thresholds)


# === MODELOS PYDANTIC ===

class SystemEvaluationRequest(BaseModel):
    """Requisição para avaliação de sistema."""
    model_predictions: List[float] = Field(..., description="Predições do modelo")
    true_labels: List[float] = Field(..., description="Labels verdadeiros")
    metadata: Optional[Dict[str, Any]] = Field(default=None, description="Metadados opcionais")


class SystemEvaluationResponse(BaseModel):
    """Resposta de avaliação de sistema."""
    decision: Dict[str, Any]
    metrics: Dict[str, Any]
    timestamp: str
    evaluation_id: str


class LedgerQuery(BaseModel):
    """Query para busca no ledger."""
    limit: Optional[int] = Field(default=100, ge=1, le=1000)
    offset: Optional[int] = Field(default=0, ge=0)
    query: Optional[Dict[str, Any]] = Field(default=None)


class SystemStatusResponse(BaseModel):
    """Resposta de status do sistema."""
    status: str
    timestamp: str
    version: str
    configuration: Dict[str, Any]
    statistics: Dict[str, Any]


# === ENDPOINTS ===

@app.get("/", tags=["Health"])
async def root():
    """Endpoint raiz - informações básicas."""
    return {
        "service": "Omega-Min API",
        "version": "1.0.0",
        "description": "Governança de IA sem dependência de explicabilidade",
        "docs": "/docs",
        "health": "/health"
    }


@app.get("/health", tags=["Health"])
async def health_check():
    """Verificação de saúde do sistema."""
    try:
        # Verificar ledger
        ledger_status = ledger.verify()
        
        # Verificar configuração
        config_validation = config.validate_config()
        
        status = "healthy"
        if not ledger_status['valid']:
            status = "degraded"
        if not config_validation['valid']:
            status = "unhealthy"
        
        return {
            "status": status,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "ledger": ledger_status,
            "configuration": config_validation
        }
    
    except Exception as e:
        logger.error(f"Erro na verificação de saúde: {e}")
        raise HTTPException(status_code=503, detail=str(e))


@app.get("/status", response_model=SystemStatusResponse, tags=["System"])
async def get_system_status():
    """Obtém status completo do sistema."""
    try:
        # Estatísticas do ledger
        ledger_stats = ledger.get_statistics()
        
        # Estatísticas do CVaR
        cvar_stats = cvar_monitor.get_risk_metrics()
        
        # Estatísticas do Ω-GATE
        gate_stats = omega_gate.get_decision_statistics()
        
        # Configuração
        config_dict = config.to_dict()
        
        return SystemStatusResponse(
            status="operational",
            timestamp=datetime.now(timezone.utc).isoformat(),
            version="1.0.0",
            configuration=config_dict,
            statistics={
                "ledger": ledger_stats,
                "cvar_monitor": cvar_stats,
                "omega_gate": gate_stats
            }
        )
    
    except Exception as e:
        logger.error(f"Erro ao obter status: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/evaluate", response_model=SystemEvaluationResponse, tags=["Evaluation"])
async def evaluate_system(request: SystemEvaluationRequest):
    """
    Avalia sistema de IA usando governança operacional.
    
    Avalia o sistema combinando:
    - CVaR (risco de cauda)
    - Decisão Ω-GATE
    - Registro no ledger
    """
    try:
        # Validar entrada
        if len(request.model_predictions) != len(request.true_labels):
            raise HTTPException(
                status_code=400, 
                detail="Predições e labels devem ter o mesmo tamanho"
            )
        
        if len(request.model_predictions) == 0:
            raise HTTPException(
                status_code=400, 
                detail="Deve haver pelo menos uma predição"
            )
        
        # Converter para numpy arrays
        predictions = np.array(request.model_predictions)
        true_labels = np.array(request.true_labels)
        
        # Avaliar com CVaR monitor
        cvar_result = cvar_monitor.evaluate(
            model=None,  # Modelo não necessário para avaliação CVaR
            X=None,      # X não necessário quando temos predições diretas
            y=true_labels
        )
        
        # Preparar controles para Ω-GATE
        controls = {
            'cvar': cvar_result['cvar'],
            'metamorphic_violations': 0.05,  # Placeholder - seria calculado separadamente
            'latency_p95': 100.0,  # Placeholder - seria medido em produção
            'drift_score': 0.05,   # Placeholder - seria detectado separadamente
            'observability_available': True
        }
        
        # Decisão Ω-GATE
        gate_result = omega_gate.decide(controls)
        
        # Preparar dados para ledger
        evaluation_data = {
            "evaluation_type": "system_governance",
            "request_metadata": request.metadata or {},
            "cvar_result": cvar_result,
            "gate_result": gate_result.to_dict(),
            "data_summary": {
                "n_predictions": len(predictions),
                "accuracy": float(np.mean(predictions == true_labels)),
                "timestamp": datetime.now(timezone.utc).isoformat()
            }
        }
        
        # Registrar no ledger
        ledger_entry = ledger.append(evaluation_data)
        
        # Preparar resposta
        response_data = {
            "decision": {
                "action": gate_result.action,
                "omega_score": gate_result.omega_score,
                "justification": gate_result.justification,
                "normalized_metrics": gate_result.normalized_metrics
            },
            "metrics": {
                "cvar": cvar_result['cvar'],
                "var": cvar_result['var'],
                "decision": cvar_result['decision'],
                "accuracy": float(np.mean(predictions == true_labels)),
                "n_evaluations": cvar_result['statistics']['total_evaluations']
            },
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "evaluation_id": ledger_entry.get('record_hash', 'unknown')[:8]
        }
        
        return SystemEvaluationResponse(**response_data)
    
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro na avaliação: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/ledger/records", tags=["Ledger"])
async def get_ledger_records(limit: int = 100, offset: int = 0):
    """
    Obtém registros do ledger com paginação.
    """
    try:
        records = ledger.get_records(limit=limit, offset=offset)
        return {
            "records": records,
            "total_records": len(records),
            "limit": limit,
            "offset": offset,
            "has_more": len(records) == limit
        }
    
    except Exception as e:
        logger.error(f"Erro ao obter registros: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/ledger/search", tags=["Ledger"])
async def search_ledger(query: LedgerQuery):
    """
    Busca registros no ledger.
    """
    try:
        if query.query:
            records = ledger.search_records(query.query)
        else:
            records = ledger.get_records(limit=query.limit, offset=query.offset)
        
        return {
            "records": records,
            "total_found": len(records),
            "query": query.query,
            "limit": query.limit,
            "offset": query.offset
        }
    
    except Exception as e:
        logger.error(f"Erro na busca: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/ledger/verify", tags=["Ledger"])
async def verify_ledger():
    """
    Verifica integridade do ledger.
    """
    try:
        verification = ledger.verify()
        return verification
    
    except Exception as e:
        logger.error(f"Erro na verificação: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/ledger/stats", tags=["Ledger"])
async def get_ledger_stats():
    """
    Obtém estatísticas do ledger.
    """
    try:
        stats = ledger.get_statistics()
        return stats
    
    except Exception as e:
        logger.error(f"Erro ao obter estatísticas: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/metrics/cvar", tags=["Metrics"])
async def get_cvar_metrics():
    """
    Obtém métricas do monitor CVaR.
    """
    try:
        risk_metrics = cvar_monitor.get_risk_metrics()
        trending = cvar_monitor._analyze_trending()
        anomalies = cvar_monitor.detect_anomalies()
        
        return {
            "risk_metrics": risk_metrics,
            "trending": trending,
            "anomalies": anomalies,
            "history_size": len(cvar_monitor.cvar_history)
        }
    
    except Exception as e:
        logger.error(f"Erro ao obter métricas CVaR: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/metrics/gate", tags=["Metrics"])
async def get_gate_metrics():
    """
    Obtém métricas do Ω-GATE.
    """
    try:
        decision_stats = omega_gate.get_decision_statistics()
        performance = omega_gate.analyze_performance()
        
        return {
            "decision_statistics": decision_stats,
            "performance_analysis": performance,
            "history_size": len(omega_gate.decision_history)
        }
    
    except Exception as e:
        logger.error(f"Erro ao obter métricas Ω-GATE: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/config", tags=["Configuration"])
async def get_configuration():
    """
    Obtém configuração atual do sistema.
    """
    try:
        config_dict = config.to_dict()
        validation = config.validate_config()
        
        return {
            "configuration": config_dict,
            "validation": validation,
            "environment_variables": config.get_environment_variables()
        }
    
    except Exception as e:
        logger.error(f"Erro ao obter configuração: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/config/validate", tags=["Configuration"])
async def validate_configuration(config_data: Dict[str, Any]):
    """
    Valida configuração sem aplicá-la.
    """
    try:
        # Criar configuração temporária para validação
        temp_config = OmegaMinConfig(**config_data)
        validation = temp_config.validate_config()
        
        return validation
    
    except Exception as e:
        logger.error(f"Erro na validação: {e}")
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/export/audit-trail", tags=["Export"])
async def export_audit_trail(background_tasks: BackgroundTasks, format: str = "json"):
    """
    Exporta trilha de auditoria do ledger.
    """
    try:
        # Gerar nome do arquivo
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"audit_trail_{timestamp}.{format}"
        output_path = f"exports/{filename}"
        
        # Criar diretório se não existir
        import os
        os.makedirs("exports", exist_ok=True)
        
        # Exportar (tarefa em background para arquivos grandes)
        background_tasks.add_task(
            ledger.export_audit_trail,
            output_path,
            format
        )
        
        return {
            "message": "Exportação iniciada",
            "output_path": output_path,
            "format": format,
            "status": "processing"
        }
    
    except Exception as e:
        logger.error(f"Erro no export: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/plots/cvar", tags=["Visualization"])
async def plot_cvar_metrics():
    """
    Gera dados para visualização de métricas CVaR.
    """
    try:
        if not cvar_monitor.cvar_history:
            return {"error": "Sem dados para plotar"}
        
        return {
            "cvar_history": cvar_monitor.cvar_history[-100:],  # Últimos 100
            "decision_history": cvar_monitor.decision_history[-100:],
            "thresholds": {
                "allow": cvar_monitor.max_allow,
                "degrade": cvar_monitor.max_degrade
            },
            "statistics": cvar_monitor.get_risk_metrics()
        }
    
    except Exception as e:
        logger.error(f"Erro ao gerar plot CVaR: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/plots/gate", tags=["Visualization"])
async def plot_gate_metrics():
    """
    Gera dados para visualização de métricas Ω-GATE.
    """
    try:
        if not omega_gate.score_history:
            return {"error": "Sem dados para plotar"}
        
        return {
            "omega_scores": omega_gate.score_history[-100:],  # Últimos 100
            "decision_history": [d['action'] for d in omega_gate.decision_history[-100:]],
            "thresholds": omega_gate.thresholds,
            "statistics": omega_gate.get_decision_statistics()
        }
    
    except Exception as e:
        logger.error(f"Erro ao gerar plot Ω-GATE: {e}")
        raise HTTPException(status_code=500, detail=str(e))


# === EXEMPLO DE USO ===

if __name__ == "__main__":
    # Executar servidor de desenvolvimento
    uvicorn.run(
        "api:app",
        host=config.api_host,
        port=config.api_port,
        reload=True,
        log_level=config.log_level.lower()
    )


# === FUNÇÕES DE INICIALIZAÇÃO ===

def initialize_components():
    """Inicializa componentes globais."""
    global ledger, cvar_monitor, omega_gate
    
    # Inicializar ledger
    ledger = AppendOnlyLedger(config.ledger_path, config.hash_alg)
    
    # Inicializar CVaR monitor
    cvar_monitor = CVaRMonitor(
        alpha=config.cvar_alpha,
        max_allow=config.cvar_max_allow,
        max_degrade=config.cvar_max_degrade
    )
    
    # Inicializar Ω-GATE
    omega_gate = OmegaGate(config.omega_weights, config.omega_thresholds)
    
    logger.info("Componentes Omega-Min inicializados")


# Inicializar na importação
initialize_components()