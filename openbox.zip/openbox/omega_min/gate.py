"""
Ω-GATE: Sistema de decisões de governança para IA.

Combina múltiplas métricas (CVaR, testes metamórficos, latência, deriva)
em uma decisão final de ALLOW/DEGRADE/BLOCK para governança operacional.
"""

import numpy as np
from typing import Dict, Any, List, Optional
from datetime import datetime, timezone
import json


class GateResult:
    """
    Resultado de uma decisão do Ω-GATE.
    """
    
    def __init__(self, action: str, omega_score: float, justification: str, 
                 normalized_metrics: Dict[str, float], timestamp: str = None):
        self.action = action
        self.omega_score = omega_score
        self.justification = justification
        self.normalized_metrics = normalized_metrics
        self.timestamp = timestamp or datetime.now(timezone.utc).isoformat()
    
    def to_dict(self) -> Dict[str, Any]:
        """Converte para dicionário."""
        return {
            'action': self.action,
            'omega_score': self.omega_score,
            'justification': self.justification,
            'normalized_metrics': self.normalized_metrics,
            'timestamp': self.timestamp
        }
    
    def __str__(self) -> str:
        return f"Ω-GATE: {self.action} (score: {self.omega_score:.3f})"


class OmegaGate:
    """
    Ω-GATE: Sistema de decisões de governança.
    
    Combina múltiplas métricas em uma decisão final de governança:
    - ALLOW: Sistema funciona normalmente
    - DEGRADE: Sistema funciona com limitações
    - BLOCK: Sistema deve ser bloqueado
    
    O score Ω (omega) representa antifragilidade do sistema.
    """
    
    def __init__(self, weights: Dict[str, float], thresholds: Dict[str, float]):
        """
        Inicializa Ω-GATE.
        
        Args:
            weights: Pesos para cada métrica (devem somar 1.0)
            thresholds: Thresholds para decisão (allow, degrade, block)
        """
        self.weights = weights
        self.thresholds = thresholds
        
        # Validar configuração
        self._validate_config()
        
        # Histórico de decisões
        self.decision_history = []
        self.score_history = []
    
    def _validate_config(self):
        """Valida configuração do Ω-GATE."""
        
        # Validar pesos
        total_weight = sum(self.weights.values())
        if abs(total_weight - 1.0) > 0.001:
            raise ValueError(f"Pesos devem somar 1.0, atual: {total_weight}")
        
        # Validar thresholds
        required_thresholds = ['allow', 'degrade', 'block']
        for threshold in required_thresholds:
            if threshold not in self.thresholds:
                raise ValueError(f"Threshold '{threshold}' é obrigatório")
        
        # Validar ordem dos thresholds
        if not (self.thresholds['allow'] >= self.thresholds['degrade'] >= self.thresholds['block']):
            raise ValueError("Thresholds devem estar em ordem: allow >= degrade >= block")
    
    def normalize_metrics(self, controls: Dict[str, Any]) -> Dict[str, float]:
        """
        Normaliza métricas para [0,1] onde 1 = melhor.
        
        Args:
            controls: Dicionário com controles do sistema
        
        Returns:
            Métricas normalizadas
        """
        normalized = {}
        
        # CVaR: menor é melhor (CVaR alto = risco alto)
        cvar_value = controls.get('cvar', 1.0)
        # Normaliza considerando que CVaR > 0.5 é crítico
        normalized['cvar'] = max(0, 1 - min(cvar_value / 0.5, 1.0))
        
        # Testes metamórficos: menor é melhor (violações altas = sistema instável)
        meta_violations = controls.get('metamorphic_violations', 1.0)
        # Normaliza considerando que violações > 0.2 são críticas
        normalized['metamorphic_violations'] = max(0, 1 - min(meta_violations / 0.2, 1.0))
        
        # Latência: menor é melhor (latência alta = performance ruim)
        latency = controls.get('latency_p95', 500.0)  # ms
        # Normaliza considerando que latência > 500ms é crítica
        normalized['latency_p95'] = max(0, 1 - min(latency / 500.0, 1.0))
        
        # Deriva: menor é melhor (deriva alta = distribuição mudou)
        drift_score = controls.get('drift_score', 1.0)
        # Normaliza considerando que deriva > 0.5 é crítica
        normalized['drift_score'] = max(0, 1 - min(drift_score / 0.5, 1.0))
        
        # Observabilidade: disponibilidade é melhor
        obs_available = controls.get('observability_available', True)
        normalized['observability'] = 1.0 if obs_available else 0.0
        
        return normalized
    
    def calculate_omega_score(self, normalized_metrics: Dict[str, float]) -> float:
        """
        Calcula score Ω (antifragilidade) baseado nas métricas normalizadas.
        
        Args:
            normalized_metrics: Métricas normalizadas [0,1]
        
        Returns:
            Score Ω (0-1, onde 1 = máxima antifragilidade)
        """
        omega_score = 0.0
        
        for metric, weight in self.weights.items():
            if metric in normalized_metrics:
                omega_score += normalized_metrics[metric] * weight
        
        return float(np.clip(omega_score, 0.0, 1.0))
    
    def make_decision(self, omega_score: float) -> str:
        """
        Toma decisão baseada no score Ω.
        
        Args:
            omega_score: Score Ω calculado
        
        Returns:
            Decisão: ALLOW, DEGRADE, ou BLOCK
        """
        if omega_score >= self.thresholds['allow']:
            return "ALLOW"
        elif omega_score >= self.thresholds['degrade']:
            return "DEGRADE"
        else:
            return "BLOCK"
    
    def generate_justification(self, controls: Dict[str, Any], 
                              omega_score: float, decision: str) -> str:
        """
        Gera justificativa textual para a decisão.
        
        Args:
            controls: Controles originais
            omega_score: Score Ω calculado
            decision: Decisão tomada
        
        Returns:
            Justificativa textual
        """
        violations = []
        
        # Verificar violações específicas
        cvar = controls.get('cvar', 0)
        if cvar > 0.25:
            violations.append(f"CVaR crítico: {cvar:.3f}")
        
        meta_violations = controls.get('metamorphic_violations', 0)
        if meta_violations > 0.15:
            violations.append(f"Violações metamórficas altas: {meta_violations:.3f}")
        
        latency = controls.get('latency_p95', 0)
        if latency > 300:
            violations.append(f"Latência alta: {latency:.1f}ms")
        
        drift_score = controls.get('drift_score', 0)
        if drift_score > 0.3:
            violations.append(f"Deriva de dados: {drift_score:.3f}")
        
        # Gerar justificativa
        if violations:
            if decision == "BLOCK":
                justification = f"Sistema BLOQUEADO: " + "; ".join(violations)
            else:
                justification = f"Sistema {decision}: " + "; ".join(violations)
        else:
            justification = f"Sistema {decision}: Funcionando dentro de parâmetros normais (Ω={omega_score:.3f})"
        
        return justification
    
    def decide(self, controls: Dict[str, Any]) -> GateResult:
        """
        Decide governança baseada em controles do sistema.
        
        Args:
            controls: Dicionário com controles e métricas
        
        Returns:
            Resultado da decisão
        """
        # Normalizar métricas
        normalized_metrics = self.normalize_metrics(controls)
        
        # Calcular score Ω
        omega_score = self.calculate_omega_score(normalized_metrics)
        
        # Tomar decisão
        decision = self.make_decision(omega_score)
        
        # Gerar justificativa
        justification = self.generate_justification(controls, omega_score, decision)
        
        # Criar resultado
        result = GateResult(
            action=decision,
            omega_score=omega_score,
            justification=justification,
            normalized_metrics=normalized_metrics
        )
        
        # Armazenar histórico
        self.decision_history.append(result.to_dict())
        self.score_history.append(omega_score)
        
        # Manter apenas últimos 1000 decisões
        if len(self.decision_history) > 1000:
            self.decision_history = self.decision_history[-1000:]
            self.score_history = self.score_history[-1000:]
        
        return result
    
    def get_decision_statistics(self) -> Dict[str, Any]:
        """
        Obtém estatísticas das decisões.
        
        Returns:
            Estatísticas das decisões
        """
        if not self.decision_history:
            return {
                'total_decisions': 0,
                'decision_distribution': {},
                'average_omega_score': 0.0,
                'recent_trend': 'insufficient_data'
            }
        
        # Distribuição de decisões
        decisions = [d['action'] for d in self.decision_history]
        decision_counts = {}
        for decision in decisions:
            decision_counts[decision] = decision_counts.get(decision, 0) + 1
        
        total_decisions = len(decisions)
        decision_distribution = {
            decision: count / total_decisions 
            for decision, count in decision_counts.items()
        }
        
        # Score médio
        avg_omega_score = np.mean(self.score_history)
        
        # Tendência recente
        if len(self.score_history) >= 10:
            recent_scores = np.array(self.score_history[-10:])
            trend_slope = np.polyfit(range(len(recent_scores)), recent_scores, 1)[0]
            
            if trend_slope > 0.01:
                recent_trend = 'improving'
            elif trend_slope < -0.01:
                recent_trend = 'deteriorating'
            else:
                recent_trend = 'stable'
        else:
            recent_trend = 'insufficient_data'
        
        return {
            'total_decisions': total_decisions,
            'decision_distribution': decision_distribution,
            'average_omega_score': avg_omega_score,
            'recent_trend': recent_trend,
            'last_decision': self.decision_history[-1]['action'] if self.decision_history else None,
            'last_omega_score': self.score_history[-1] if self.score_history else None
        }
    
    def analyze_performance(self) -> Dict[str, Any]:
        """
        Analisa performance do sistema de decisões.
        
        Returns:
            Análise de performance
        """
        if len(self.decision_history) < 20:
            return {'status': 'insufficient_data'}
        
        # Análise de estabilidade
        recent_decisions = [d['action'] for d in self.decision_history[-20:]]
        stability_score = 1.0 - (len(set(recent_decisions)) - 1) / 3  # 3 tipos de decisão possíveis
        
        # Análise de severidade
        block_count = recent_decisions.count('BLOCK')
        block_rate = block_count / len(recent_decisions)
        
        # Análise de score
        recent_scores = np.array(self.score_history[-20:])
        score_volatility = np.std(recent_scores)
        
        return {
            'stability_score': stability_score,
            'block_rate_20': block_rate,
            'score_volatility': score_volatility,
            'consistency': 'high' if score_volatility < 0.1 else 'medium' if score_volatility < 0.2 else 'low'
        }
    
    def export_decision_log(self, output_path: str, format: str = "json") -> str:
        """
        Exporta log de decisões.
        
        Args:
            output_path: Caminho do arquivo
            format: Formato ("json", "csv")
        
        Returns:
            Caminho do arquivo
        """
        import os
        import csv
        
        # Criar diretório se necessário
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        if format == "json":
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(self.decision_history, f, indent=2, ensure_ascii=False)
        
        elif format == "csv":
            if self.decision_history:
                fieldnames = set()
                for decision in self.decision_history:
                    fieldnames.update(decision.keys())
                
                with open(output_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.DictWriter(f, fieldnames=sorted(fieldnames))
                    writer.writeheader()
                    writer.writerows(self.decision_history)
        
        else:
            raise ValueError(f"Formato não suportado: {format}")
        
        return output_path
    
    def plot_decision_history(self, save_path: str = None):
        """
        Plota histórico de decisões.
        
        Args:
            save_path: Caminho para salvar
        """
        try:
            import matplotlib.pyplot as plt
            import seaborn as sns
            
            if not self.decision_history:
                print("Sem dados para plotar")
                return
            
            # Configurar estilo
            plt.style.use('seaborn-v0_8')
            sns.set_palette("husl")
            
            fig, axes = plt.subplots(2, 2, figsize=(15, 10))
            
            # Subplot 1: Score Ω ao longo do tempo
            axes[0, 0].plot(self.score_history, 'b-', linewidth=2)
            axes[0, 0].axhline(y=self.thresholds['allow'], color='g', linestyle='--', label='Allow')
            axes[0, 0].axhline(y=self.thresholds['degrade'], color='orange', linestyle='--', label='Degrade')
            axes[0, 0].axhline(y=self.thresholds['block'], color='r', linestyle='--', label='Block')
            axes[0, 0].set_xlabel('Decisão')
            axes[0, 0].set_ylabel('Score Ω')
            axes[0, 0].set_title('Evolução do Score Ω')
            axes[0, 0].legend()
            axes[0, 0].grid(True, alpha=0.3)
            
            # Subplot 2: Distribuição de decisões
            decision_counts = {}
            for decision in self.decision_history:
                action = decision['action']
                decision_counts[action] = decision_counts.get(action, 0) + 1
            
            if decision_counts:
                axes[0, 1].pie(decision_counts.values(), labels=decision_counts.keys(), autopct='%1.1f%%')
                axes[0, 1].set_title('Distribuição de Decisões')
            
            # Subplot 3: Box plot de scores por decisão
            decision_scores = {}
            for decision in self.decision_history:
                action = decision['action']
                score = decision['omega_score']
                if action not in decision_scores:
                    decision_scores[action] = []
                decision_scores[action].append(score)
            
            if decision_scores:
                data_to_plot = list(decision_scores.values())
                labels = list(decision_scores.keys())
                axes[1, 0].boxplot(data_to_plot, labels=labels)
                axes[1, 0].set_ylabel('Score Ω')
                axes[1, 0].set_title('Score Ω por Decisão')
                axes[1, 0].grid(True, alpha=0.3)
            
            # Subplot 4: Histograma de scores
            axes[1, 1].hist(self.score_history, bins=20, alpha=0.7, edgecolor='black')
            axes[1, 1].axvline(x=np.mean(self.score_history), color='r', linestyle='--', label='Média')
            axes[1, 1].set_xlabel('Score Ω')
            axes[1, 1].set_ylabel('Frequência')
            axes[1, 1].set_title('Distribuição do Score Ω')
            axes[1, 1].legend()
            axes[1, 1].grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            if save_path:
                plt.savefig(save_path, dpi=300, bbox_inches='tight')
                print(f"Gráfico salvo em: {save_path}")
            
            plt.show()
            
        except ImportError:
            print("matplotlib e/ou seaborn não estão disponíveis")


# Função de conveniência
def omega_gate(controls: Dict[str, Any], weights: Dict[str, float] = None, 
               thresholds: Dict[str, float] = None) -> GateResult:
    """
    Função de conveniência para decisão Ω-GATE.
    
    Args:
        controls: Controles do sistema
        weights: Pesos (usa padrão se None)
        thresholds: Thresholds (usa padrão se None)
    
    Returns:
        Resultado da decisão
    """
    # Configurações padrão
    default_weights = {
        'cvar': 0.4,
        'metamorphic_violations': 0.3,
        'latency_p95': 0.2,
        'drift_score': 0.1
    }
    
    default_thresholds = {
        'allow': 0.8,
        'degrade': 0.6,
        'block': 0.0
    }
    
    # Usar configurações fornecidas ou padrão
    final_weights = weights or default_weights
    final_thresholds = thresholds or default_thresholds
    
    # Criar gate e decidir
    gate = OmegaGate(final_weights, final_thresholds)
    return gate.decide(controls)