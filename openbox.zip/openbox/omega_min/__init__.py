"""
OpenBox Omega-Min: Núcleo Mínimo Certificável para Governança de IA

Este módulo implementa o núcleo operacional mínimo para governança de sistemas
de IA sem dependência de explicabilidade interna.

Componentes principais:
- OmegaMinConfig: Configuração do sistema
- AppendOnlyLedger: Ledger imutável para evidência
- CVaR: Monitoramento de risco de cauda
- OmegaGate: Sistema de decisões de governança
- API: Interface FastAPI para integração
"""

__version__ = "1.0.0"
__author__ = "MatVerse-U"
__email__ = "contact@matverse.org"

from .config import OmegaMinConfig
from .ledger import AppendOnlyLedger
from .risk import cvar
from .gate import omega_gate
from .api import app

__all__ = [
    "OmegaMinConfig",
    "AppendOnlyLedger", 
    "cvar",
    "omega_gate",
    "app"
]