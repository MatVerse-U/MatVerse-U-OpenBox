"""
Ledger imutável com hash chaining para evidência de auditoria.

Implementa um ledger append-only que garante integridade através de
hash chaining, fornecendo evidência legal para governança de IA.
"""

import json
import os
import hashlib
from datetime import datetime, timezone
from typing import Any, Dict, Optional, List
from pathlib import Path


def _hash_bytes(hash_alg: str, data: bytes) -> str:
    """
    Calcula hash de bytes usando algoritmo especificado.
    
    Args:
        hash_alg: Nome do algoritmo de hash
        data: Bytes para hashing
    
    Returns:
        Hash hex string
    """
    try:
        h = hashlib.new(hash_alg)
    except ValueError as e:
        raise ValueError(f"Algoritmo de hash não suportado: {hash_alg}") from e
    
    h.update(data)
    return h.hexdigest()


def canonical_json(obj: Any) -> bytes:
    """
    Cria representação JSON canônica para hashing.
    
    A canonicalização garante que objetos com mesmo conteúdo
    sempre produzam o mesmo hash, independente da ordem das keys.
    
    Args:
        obj: Objeto para canonicalizar
    
    Returns:
        Bytes JSON canônicos
    """
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


class AppendOnlyLedger:
    """
    Ledger append-only com hash chaining para evidência imutável.
    
    Cada entrada contém:
    - prev_hash: hash da entrada anterior
    - record_hash: hash desta entrada (sem o campo record_hash)
    - timestamp: UTC ISO format
    - data: dados da decisão
    
    Características:
    - Append-only: Apenas novos registros podem ser adicionados
    - Hash chaining: Cada registro referencia o anterior
    - Verificável: Integridade pode ser verificada a qualquer momento
    - Determinístico: Mesmo input sempre produz mesmo hash
    """
    
    def __init__(self, path: str, hash_alg: str = "sha3_256"):
        """
        Inicializa ledger.
        
        Args:
            path: Caminho do arquivo ledger
            hash_alg: Algoritmo de hash para usar
        """
        self.path = path
        self.hash_alg = hash_alg
        
        # Criar diretório se não existir
        os.makedirs(os.path.dirname(path), exist_ok=True)
        
        # Inicializar arquivo se não existir
        if not os.path.exists(path):
            Path(path).touch()
    
    def _get_last_hash(self) -> str:
        """
        Obtém hash da última entrada no ledger.
        
        Returns:
            Hash da última entrada ou "GENESIS" se vazio
        """
        if not os.path.exists(self.path) or os.path.getsize(self.path) == 0:
            return "GENESIS"
        
        with open(self.path, "r", encoding="utf-8") as f:
            for line in f:
                if line.strip():
                    last = line
        
        if last is None:
            return "GENESIS"
        
        try:
            rec = json.loads(last)
            return rec.get("record_hash", "GENESIS")
        except json.JSONDecodeError:
            return "GENESIS"
    
    def append(self, record: Dict[str, Any]) -> Dict[str, Any]:
        """
        Adiciona nova entrada ao ledger.
        
        Args:
            record: Dados a serem registrados
        
        Returns:
            Registro completo com hash e timestamp
        
        Raises:
            ValueError: Se record contém record_hash ou prev_hash
        """
        # Validar entrada
        if "record_hash" in record:
            raise ValueError("Registro não pode conter 'record_hash'")
        
        if "prev_hash" in record:
            raise ValueError("Registro não pode conter 'prev_hash'")
        
        if "timestamp" in record:
            raise ValueError("Registro não pode conter 'timestamp'")
        
        # Criar nova entrada
        rec = dict(record)
        rec["ts_utc"] = rec.get("ts_utc") or datetime.now(timezone.utc).isoformat()
        rec["prev_hash"] = self._get_last_hash()
        
        # Calcular hash sobre forma canônica sem record_hash
        tmp = dict(rec)
        tmp.pop("record_hash", None)
        rec["record_hash"] = _hash_bytes(self.hash_alg, canonical_json(tmp))
        
        # Escrever no arquivo
        with open(self.path, "a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\\n")
        
        return rec
    
    def verify(self) -> Dict[str, Any]:
        """
        Verifica integridade completa do ledger.
        
        Returns:
            Resultado da verificação com detalhes
        """
        if not os.path.exists(self.path):
            return {
                "valid": True,
                "message": "Ledger não existe (considerado vazio)",
                "total_records": 0
            }
        
        if os.path.getsize(self.path) == 0:
            return {
                "valid": True,
                "message": "Ledger vazio",
                "total_records": 0
            }
        
        prev = "GENESIS"
        total_records = 0
        errors = []
        
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f, 1):
                    if not line.strip():
                        continue
                    
                    try:
                        rec = json.loads(line)
                        total_records += 1
                        
                        # Verificar hash anterior
                        if rec.get("prev_hash") != prev:
                            errors.append({
                                "line": line_num,
                                "error": f"Hash anterior incorreto: {rec.get('prev_hash')} != {prev}",
                                "record": rec
                            })
                            break
                        
                        # Verificar hash do registro
                        tmp = dict(rec)
                        expected_hash = tmp.pop("record_hash", None)
                        
                        if expected_hash is None:
                            errors.append({
                                "line": line_num,
                                "error": "Registro sem record_hash",
                                "record": rec
                            })
                            break
                        
                        calculated_hash = _hash_bytes(self.hash_alg, canonical_json(tmp))
                        
                        if calculated_hash != expected_hash:
                            errors.append({
                                "line": line_num,
                                "error": f"Hash incorreto: {expected_hash} != {calculated_hash}",
                                "record": rec
                            })
                            break
                        
                        prev = expected_hash
                    
                    except json.JSONDecodeError as e:
                        errors.append({
                            "line": line_num,
                            "error": f"JSON inválido: {e}",
                            "raw_line": line
                        })
                        break
        
        except Exception as e:
            return {
                "valid": False,
                "error": f"Erro ao ler ledger: {e}",
                "total_records": total_records
            }
        
        if errors:
            return {
                "valid": False,
                "message": f"Ledger inválido: {len(errors)} erro(s)",
                "total_records": total_records,
                "errors": errors[:5]  # Primeiros 5 erros
            }
        else:
            return {
                "valid": True,
                "message": "Ledger íntegro",
                "total_records": total_records,
                "last_hash": prev
            }
    
    def get_record(self, index: int) -> Optional[Dict[str, Any]]:
        """
        Obtém registro específico por índice.
        
        Args:
            index: Índice do registro (0-based)
        
        Returns:
            Registro ou None se não encontrado
        """
        if index < 0:
            return None
        
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                for line_num, line in enumerate(f):
                    if line.strip():
                        if line_num == index:
                            return json.loads(line)
        except (json.JSONDecodeError, IndexError):
            pass
        
        return None
    
    def get_records(self, limit: Optional[int] = None, offset: int = 0) -> List[Dict[str, Any]]:
        """
        Obtém registros do ledger com paginação.
        
        Args:
            limit: Número máximo de registros
            offset: Offset para paginação
        
        Returns:
            Lista de registros
        """
        records = []
        
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                current_offset = 0
                for line in f:
                    if not line.strip():
                        continue
                    
                    if current_offset < offset:
                        current_offset += 1
                        continue
                    
                    if limit and len(records) >= limit:
                        break
                    
                    try:
                        rec = json.loads(line)
                        records.append(rec)
                    except json.JSONDecodeError:
                        continue
        
        except FileNotFoundError:
            pass
        
        return records
    
    def search_records(self, query: Dict[str, Any]) -> List[Dict[str, Any]]:
        """
        Busca registros que contenham os critérios especificados.
        
        Args:
            query: Dicionário com critérios de busca
        
        Returns:
            Lista de registros que atendem aos critérios
        """
        results = []
        
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                for line in f:
                    if not line.strip():
                        continue
                    
                    try:
                        rec = json.loads(line)
                        
                        # Verificar se record atende aos critérios
                        matches = True
                        for key, value in query.items():
                            if key not in rec or rec[key] != value:
                                matches = False
                                break
                        
                        if matches:
                            results.append(rec)
                    
                    except json.JSONDecodeError:
                        continue
        
        except FileNotFoundError:
            pass
        
        return results
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        Obtém estatísticas do ledger.
        
        Returns:
            Dicionário com estatísticas
        """
        if not os.path.exists(self.path):
            return {
                "total_records": 0,
                "file_size_bytes": 0,
                "date_range": None,
                "hash_algorithm": self.hash_alg
            }
        
        # Estatísticas básicas
        total_records = 0
        timestamps = []
        
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        total_records += 1
                        try:
                            rec = json.loads(line)
                            if "ts_utc" in rec:
                                timestamps.append(rec["ts_utc"])
                        except json.JSONDecodeError:
                            continue
        except FileNotFoundError:
            pass
        
        # Range de datas
        date_range = None
        if timestamps:
            date_range = {
                "first": min(timestamps),
                "last": max(timestamps)
            }
        
        # Tamanho do arquivo
        file_size = os.path.getsize(self.path)
        
        return {
            "total_records": total_records,
            "file_size_bytes": file_size,
            "file_size_mb": file_size / (1024 * 1024),
            "date_range": date_range,
            "hash_algorithm": self.hash_alg,
            "last_modified": datetime.fromtimestamp(os.path.getmtime(self.path)).isoformat() if os.path.exists(self.path) else None
        }
    
    def export_audit_trail(self, output_path: str, format: str = "json") -> str:
        """
        Exporta trilha de auditoria para arquivo externo.
        
        Args:
            output_path: Caminho do arquivo de saída
            format: Formato de exportação ("json", "csv", "txt")
        
        Returns:
            Caminho do arquivo exportado
        """
        records = self.get_records()
        
        # Criar diretório de saída
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        if format == "json":
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(records, f, indent=2, ensure_ascii=False)
        
        elif format == "csv":
            import csv
            
            if records:
                fieldnames = set()
                for record in records:
                    fieldnames.update(record.keys())
                
                with open(output_path, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.DictWriter(f, fieldnames=sorted(fieldnames))
                    writer.writeheader()
                    writer.writerows(records)
        
        elif format == "txt":
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write("AUDIT TRAIL - OpenBox Omega-Min\\n")
                f.write("=" * 50 + "\\n\\n")
                f.write(f"Total de registros: {len(records)}\\n")
                f.write(f"Algoritmo de hash: {self.hash_alg}\\n")
                f.write(f"Arquivo origem: {self.path}\\n")
                f.write(f"Exportado em: {datetime.now(timezone.utc).isoformat()}\\n")
                f.write("\\n" + "=" * 50 + "\\n\\n")
                
                for i, record in enumerate(records, 1):
                    f.write(f"REGISTRO {i:\\n")
                    for key, value in record.items():
                        f.write(f"  {key}: {value}\\n")
                    f.write("\\n")
        
        else:
            raise ValueError(f"Formato não suportado: {format}")
        
        return output_path
    
    def clear(self):
        """Limpa o ledger (remove todos os registros)."""
        with open(self.path, "w") as f:
            f.write("")
    
    def backup(self, backup_path: str) -> str:
        """
        Cria backup do ledger.
        
        Args:
            backup_path: Caminho do backup
        
        Returns:
            Caminho do backup criado
        """
        import shutil
        
        os.makedirs(os.path.dirname(backup_path), exist_ok=True)
        shutil.copy2(self.path, backup_path)
        
        return backup_path


# Função de conveniência para criar ledger
def create_ledger(path: str, hash_alg: str = "sha3_256") -> AppendOnlyLedger:
    """
    Cria nova instância de ledger.
    
    Args:
        path: Caminho do arquivo ledger
        hash_alg: Algoritmo de hash
    
    Returns:
        Nova instância de ledger
    """
    return AppendOnlyLedger(path, hash_alg)