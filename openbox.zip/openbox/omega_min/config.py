"""
Configuração do sistema Omega-Min para governança de IA.
"""

from pydantic import BaseModel, Field
from typing import Dict, Any
import os


class OmegaMinConfig(BaseModel):
    """
    Configuração completa do sistema Omega-Min.
    
    Define todos os parâmetros necessários para governança operacional
    de sistemas de IA sem dependência de explicabilidade.
    """
    
    # === CVaR (Conditional Value at Risk) ===
    # CVaR gate - controle de risco de cauda
    cvar_alpha: float = Field(
        default=0.95, 
        ge=0.5, 
        le=0.999,
        description="Nível de confiança para CVaR (Expected Shortfall)"
    )
    
    cvar_max_allow: float = Field(
        default=0.20, 
        ge=0.0, 
        le=1.0,
        description="CVaR máximo permitido (sistema aprovado)"
    )
    
    cvar_max_degrade: float = Field(
        default=0.25, 
        ge=0.0, 
        le=1.0,
        description="CVaR máximo para degradação (acima disso bloqueia)"
    )
    
    # === Testes Metamórficos ===
    # Testes metamórficos - robustez comportamental
    meta_max_violation_rate_allow: float = Field(
        default=0.05, 
        ge=0.0, 
        le=1.0,
        description="Taxa máxima de violação permitida (sistema aprovado)"
    )
    
    meta_max_violation_rate_degrade: float = Field(
        default=0.10, 
        ge=0.0, 
        le=1.0,
        description="Taxa máxima de violação para degradação"
    )
    
    # === Ledger (Evidência) ===
    # Ledger integrity - evidência imutável
    hash_alg: str = Field(
        default="sha3_256",
        description="Algoritmo de hash para ledger"
    )
    
    ledger_path: str = Field(
        default="ledger/decisions.jsonl",
        description="Caminho do arquivo ledger"
    )
    
    # === Performance ===
    # Optional latency SLO (ms) - usado apenas para relatórios
    p95_slo_ms: float = Field(
        default=200.0,
        ge=0.0,
        description="SLO de latência p95 em milissegundos"
    )
    
    # === Ω-GATE (Decisões) ===
    # Pesos para decisão Ω-GATE
    omega_weights: Dict[str, float] = Field(
        default={
            "cvar": 0.4,
            "metamorphic_violations": 0.3,
            "latency_p95": 0.2,
            "drift_score": 0.1
        },
        description="Pesos para cálculo do score Ω"
    )
    
    omega_thresholds: Dict[str, float] = Field(
        default={
            "allow": 0.8,
            "degrade": 0.6,
            "block": 0.0
        },
        description="Thresholds para decisão Ω-GATE"
    )
    
    # === Observabilidade ===
    # Observabilidade - monitoramento em tempo real
    observability_enabled: bool = Field(
        default=True,
        description="Habilitar observabilidade"
    )
    
    monitoring_interval_seconds: int = Field(
        default=60,
        ge=1,
        description="Intervalo de monitoramento em segundos"
    )
    
    # === UMJAM (Controle Dinâmico) ===
    # UMJAM - controle afim externo
    umjam_target: float = Field(
        default=0.05,
        ge=0.0,
        le=1.0,
        description="Target para controle UMJAM"
    )
    
    umjam_convergence_rate: float = Field(
        default=0.1,
        ge=0.01,
        le=0.99,
        description="Taxa de convergência UMJAM (deve ser < 1)"
    )
    
    # === Deriva de Dados ===
    # Detecção de deriva
    drift_threshold: float = Field(
        default=0.1,
        ge=0.0,
        le=1.0,
        description="Threshold para detecção de deriva de dados"
    )
    
    # === Blockchain (Opcional) ===
    # Integração blockchain para evidência externa
    blockchain_enabled: bool = Field(
        default=False,
        description="Habilitar integração com blockchain"
    )
    
    blockchain_network: str = Field(
        default="ethereum",
        description="Rede blockchain para integração"
    )
    
    # === API ===
    # Configurações da API
    api_host: str = Field(
        default="0.0.0.0",
        description="Host para API"
    )
    
    api_port: int = Field(
        default=8000,
        ge=1,
        le=65535,
        description="Porta para API"
    )
    
    api_workers: int = Field(
        default=1,
        ge=1,
        description="Número de workers para API"
    )
    
    # === Logging ===
    # Configurações de logging
    log_level: str = Field(
        default="INFO",
        description="Nível de logging"
    )
    
    log_file: str = Field(
        default="logs/omega_min.log",
        description="Arquivo de log"
    )
    
    class Config:
        env_prefix = "OMEGA_MIN_"
        case_sensitive = False
    
    def __init__(self, **data):
        """Inicializa configuração com valores do ambiente."""
        super().__init__(**data)
        
        # Carregar variáveis de ambiente com fallback
        self._load_env_overrides()
        
        # Criar diretórios necessários
        self._create_directories()
    
    def _load_env_overrides(self):
        """Carrega valores do ambiente se disponíveis."""
        
        # CVaR
        if os.getenv("OMEGA_MIN_CVAR_MAX_ALLOW"):
            self.cvar_max_allow = float(os.getenv("OMEGA_MIN_CVAR_MAX_ALLOW"))
        
        if os.getenv("OMEGA_MIN_CVAR_MAX_DEGRADE"):
            self.cvar_max_degrade = float(os.getenv("OMEGA_MIN_CVAR_MAX_DEGRADE"))
        
        # Ledger
        if os.getenv("OMEGA_MIN_LEDGER_PATH"):
            self.ledger_path = os.getenv("OMEGA_MIN_LEDGER_PATH")
        
        # API
        if os.getenv("OMEGA_MIN_API_HOST"):
            self.api_host = os.getenv("OMEGA_MIN_API_HOST")
        
        if os.getenv("OMEGA_MIN_API_PORT"):
            self.api_port = int(os.getenv("OMEGA_MIN_API_PORT"))
        
        # Logging
        if os.getenv("OMEGA_MIN_LOG_LEVEL"):
            self.log_level = os.getenv("OMEGA_MIN_LOG_LEVEL")
        
        if os.getenv("OMEGA_MIN_LOG_FILE"):
            self.log_file = os.getenv("OMEGA_MIN_LOG_FILE")
    
    def _create_directories(self):
        """Cria diretórios necessários se não existirem."""
        
        import os
        
        directories = [
            os.path.dirname(self.ledger_path),
            os.path.dirname(self.log_file),
            "monitoring",
            "cache"
        ]
        
        for directory in directories:
            if directory:  # Evitar string vazia
                os.makedirs(directory, exist_ok=True)
    
    def validate_config(self) -> Dict[str, Any]:
        """Valida a configuração e retorna erros se houver."""
        
        errors = []
        
        # Validar thresholds
        if self.cvar_max_allow >= self.cvar_max_degrade:
            errors.append("cvar_max_allow deve ser menor que cvar_max_degrade")
        
        # Validar weights
        total_weight = sum(self.omega_weights.values())
        if abs(total_weight - 1.0) > 0.001:
            errors.append(f"Pesos Omega devem somar 1.0, atual: {total_weight}")
        
        # Validar thresholds Omega
        if not (self.omega_thresholds["allow"] >= self.omega_thresholds["degrade"] >= self.omega_thresholds["block"]):
            errors.append("Thresholds Omega devem estar em ordem: allow >= degrade >= block")
        
        # Validar UMJAM
        if self.umjam_convergence_rate >= 1.0:
            errors.append("umjam_convergence_rate deve ser menor que 1.0")
        
        return {
            "valid": len(errors) == 0,
            "errors": errors
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Retorna configuração como dicionário."""
        
        return self.dict()
    
    @classmethod
    def from_file(cls, config_file: str) -> "OmegaMinConfig":
        """Carrega configuração de arquivo YAML/JSON."""
        
        import yaml
        import json
        
        with open(config_file, 'r') as f:
            if config_file.endswith('.yaml') or config_file.endswith('.yml'):
                config_data = yaml.safe_load(f)
            else:
                config_data = json.load(f)
        
        return cls(**config_data)
    
    def save_to_file(self, config_file: str):
        """Salva configuração em arquivo YAML."""
        
        import yaml
        
        with open(config_file, 'w') as f:
            yaml.dump(self.dict(), f, default_flow_style=False)
    
    def get_environment_variables(self) -> Dict[str, str]:
        """Retorna variáveis de ambiente necessárias."""
        
        return {
            "OMEGA_MIN_CVAR_MAX_ALLOW": str(self.cvar_max_allow),
            "OMEGA_MIN_CVAR_MAX_DEGRADE": str(self.cvar_max_degrade),
            "OMEGA_MIN_LEDGER_PATH": self.ledger_path,
            "OMEGA_MIN_API_HOST": self.api_host,
            "OMEGA_MIN_API_PORT": str(self.api_port),
            "OMEGA_MIN_LOG_LEVEL": self.log_level,
            "OMEGA_MIN_LOG_FILE": self.log_file
        }


# Instância global da configuração
DEFAULT_CONFIG = OmegaMinConfig()


def get_config() -> OmegaMinConfig:
    """Retorna a configuração padrão."""
    return DEFAULT_CONFIG


def load_config(config_file: str = None) -> OmegaMinConfig:
    """Carrega configuração de arquivo ou retorna padrão."""
    
    if config_file and os.path.exists(config_file):
        return OmegaMinConfig.from_file(config_file)
    
    return DEFAULT_CONFIG