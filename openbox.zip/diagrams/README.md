# Diagramas OpenBox Omega-Min

Esta pasta contém os diagramas visuais que explicam a arquitetura e funcionamento do sistema de governança OpenBox Omega-Min.

## 📊 Diagramas Disponíveis

### 1. governance_architecture.png
**Arquitetura de Governança Completa**

Mostra a arquitetura em 3 camadas:
- **Observabilidade**: Coleta de métricas (latência, accuracy, deriva)
- **Controle**: CVaR, testes metamórficos, UMJAM
- **Evidência**: Ledger imutável com hash chaining
- **Ω-GATE**: Sistema de decisões
- **API**: Integração e monitoramento

### 2. omega_gate_flow.png
**Fluxo de Decisão Ω-GATE**

Detalha o processo de tomada de decisão:
1. Coleta de métricas
2. Normalização (0 = pior, 1 = melhor)
3. Cálculo do score Ω
4. Decisão baseada em thresholds
5. Registro no ledger
6. Geração de justificativa

### 3. xai_vs_governance.png
**Comparação: XAI vs Governança**

Compara abordagens:
- **XAI**: Explicabilidade pós-hoc (SHAP/LIME)
- **Governança**: Controle operacional (CVaR + testes)

### 4. umjam_control.png
**Fluxo de Controle UMJAM**

Mostra o controle afim externo:
- Inicialização do estado
- Loop de controle iterativo
- Garantias matemáticas de convergência
- Exemplo numérico

## 🎯 Como Usar

### Em Documentação
```markdown
![Arquitetura](../diagrams/governance_architecture.png)
```

### Em Apresentações
Os diagramas estão em alta resolução (1980x1080) e são adequados para:
- Slides de apresentação
- Documentação técnica
- Material educativo
- Propostas comerciais

### Em Code
```mermaid
<!-- Para uso direto em markdown -->
graph TB
    subgraph "Exemplo"
        A[Nó A] --> B[Nó B]
    end
```

## 📐 Especificações

- **Formato**: PNG
- **Resolução**: 1980x1080 (Full HD)
- **Estilo**: Moderno, cores consistentes
- **Compatibilidade**: Markdown, HTML, PowerPoint

## 🎨 Convenções Visuais

### Cores
- **Azul**: Observabilidade
- **Roxo**: Controle
- **Verde**: Evidência
- **Laranja**: Decisões
- **Rosa**: Integração

### Símbolos
- **Setas**: Fluxo de dados
- **Caixas**: Componentes
- **Losangos**: Decisões
- **Círculos**: Início/Fim

## 🔧 Criação e Edição

### Ferramentas Usadas
- **Mermaid**: Para geração dos diagramas
- **Python**: Para automação da renderização
- **Padrão**: Cores e estilos consistentes

### Modificar Diagramas
1. Edite o código Mermaid
2. Execute a renderização:
```python
from render_mermaid import render_mermaid

render_mermaid(
    mermaid_code="seu_código_mermaid",
    output_file_path="diagrams/novo_diagrama.png"
)
```

## 📚 Documentação Relacionada

- [README principal](../README.md) - Visão geral do projeto
- [Tutorial de Governança](../tutorials/03_operational_governance.md) - Implementação detalhada
- [Arquitetura](../GOVERNANCE.md) - Especificação formal
- [API Reference](../openbox/omega_min/api.py) - Interface técnica

## 🎓 Uso Educativo

Estes diagramas são ideais para:
- **Workshops**: Explicação da arquitetura
- **Treinamentos**: Conceitos de governança
- **Onboarding**: Novos desenvolvedores
- **Apresentações**: Stakeholders técnicos

## 📝 Atualizações

Os diagramas devem ser atualizados quando:
- Arquitetura do sistema muda
- Novas funcionalidades são adicionadas
- Feedback indica necessidade de clarificação
- Versões major são lançadas

---

**Nota**: Todos os diagramas são gerados automaticamente para manter consistência visual e facilitar atualizações.